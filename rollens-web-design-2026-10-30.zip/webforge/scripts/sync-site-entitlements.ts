import { stripeClient } from "../src/lib/billing";
import { ensureSiteCatalog, portal, type SiteUser } from "../src/lib/selfserve";
import { SITE_PLANS, type SitePlan } from "../src/lib/site-plans";
const client = stripeClient();
const catalog = [];
for (const key of Object.keys(SITE_PLANS) as SitePlan[]) {
  const plan = SITE_PLANS[key];
  const c = await ensureSiteCatalog(client, key);
  const price = await client.prices.retrieve(c.price);
  if (
    price.unit_amount !== plan.cents ||
    price.currency !== "aud" ||
    price.recurring?.interval !== "month"
  )
    throw new Error("Catalog mismatch");
  await client.products.update(c.product, {
    description: `${plan.sites} hosted website${plan.sites > 1 ? "s" : ""}. ${plan.gallery === null ? "No plan-based image or service-content quotas. Custom SEO and optional footer credit." : "Text focused, 3 service entries, Rollens footer credit."} ${plan.edits ? "Ongoing editing." : "Draft editing only; content locks after first publication."}`,
    metadata: {
      rollens_plan: key,
      sites: String(plan.sites),
      editing: plan.edits ? "ongoing" : "draft_only",
      entitlements_version: "2026-10-26",
    },
  });
  catalog.push({
    plan: key,
    cents: price.unit_amount,
    sites: plan.sites,
    ongoingEdits: plan.edits,
  });
}
// Verify real portal configuration creation without creating customers or opening billing sessions.
client.billingPortal.sessions.create = async () =>
  ({ url: "configuration-verification-only" }) as any;
for (const key of Object.keys(SITE_PLANS) as SitePlan[])
  await portal(
    { customer: "configuration-verification-only", plan: key } as SiteUser,
    client,
  );
console.log(
  JSON.stringify({
    catalog,
    portalConfigurationsVerified: true,
    customersCreated: 0,
    paymentsInitiated: 0,
  }),
);
