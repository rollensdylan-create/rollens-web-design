import { randomBytes, randomUUID } from "node:crypto";
import { stripeClient } from "../src/lib/billing";
import { automationConfig } from "../src/lib/automation-config";
import { ensureSiteCatalog } from "../src/lib/selfserve";
import { SITE_PLANS, type SitePlan } from "../src/lib/site-plans";
const s = stripeClient();
const cfg = automationConfig();
const verified = [];
for (const plan of Object.keys(SITE_PLANS) as SitePlan[]) {
  const catalog = await ensureSiteCatalog(s, plan);
  const p = await s.prices.retrieve(catalog.price);
  if (
    p.unit_amount !== SITE_PLANS[plan].cents ||
    p.currency !== "aud" ||
    p.recurring?.interval !== "month"
  )
    throw new Error("Catalog mismatch");
  const session = await s.checkout.sessions.create({
    mode: "subscription",
    integration_identifier: `rollens_probe_${randomBytes(8).toString("hex").replace(/[0-9]/g, "a")}`,
    line_items: [{ price: p.id, quantity: 1 }],
    success_url: cfg.publicBase + "/account",
    cancel_url: cfg.publicBase + "/account",
    metadata: { setup_probe: "true" },
  });
  if (!session.url) throw new Error("Checkout URL missing");
  await s.checkout.sessions.expire(session.id);
  verified.push({
    plan,
    cents: p.unit_amount,
    checkoutCreatedAndExpired: true,
  });
}
const payload = JSON.stringify({
  id: `rollens_setup_probe_${randomUUID()}`,
  object: "event",
  created: Math.floor(Date.now() / 1000),
  type: "webforge.connection_check",
  data: { object: {} },
  livemode: true,
});
const signature = s.webhooks.generateTestHeaderString({
  payload,
  secret: cfg.stripeWebhook,
});
const url = cfg.publicBase + "/api/stripe/webhook";
const bad = await fetch(url, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: payload,
});
const good = await fetch(url, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "stripe-signature": signature,
  },
  body: payload,
});
if (bad.status !== 400 || good.status !== 200)
  throw new Error(`Webhook verification failed (${bad.status}/${good.status})`);
console.log(
  JSON.stringify({
    catalog: verified,
    unsignedRejected: bad.status,
    signedProbeAccepted: good.status,
    actualPaymentsCharged: 0,
  }),
);
