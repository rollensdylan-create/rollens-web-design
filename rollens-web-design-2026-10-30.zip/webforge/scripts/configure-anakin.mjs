// Run on the private host with the API key supplied through stdin, never argv.
import { writeConnections } from "../src/lib/connections.ts";
import {
  automationConfig,
  connectionStatus,
} from "../src/lib/automation-config.ts";
import { campaigns, saveCampaign } from "../src/lib/automation-store.ts";
let key = "";
for await (const chunk of process.stdin) key += chunk;
key = key.trim();
if (!key || key.length > 300 || /[\r\n]/.test(key))
  throw new Error("A single API key is required on stdin");
if (process.env.ANAKIN_API_KEY && process.env.ANAKIN_API_KEY !== key)
  throw new Error(
    "An existing environment override must be resolved before changing the saved provider key",
  );
writeConnections({ anakinKey: key });
let updated = 0;
for (const c of campaigns()) {
  if (c.discoverySource === "manual") continue;
  c.discoverySource = "primary";
  saveCampaign(c);
  updated++;
}
if (!automationConfig().anakinKey)
  throw new Error("Anakin configuration not available");
console.log(
  JSON.stringify({
    provider: connectionStatus().searchProvider,
    campaignsUpdated: updated,
    sendingSettingsUnchanged: true,
  }),
);
