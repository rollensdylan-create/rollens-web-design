import { readFile } from "node:fs/promises";
import { listMissions, saveMission, createMission } from "../src/lib/db";
import { workspace } from "../src/lib/artifacts";
import { parsePage } from "../src/lib/scanner";
import { sourceProblems } from "../src/lib/source-quality";
import { reconcileProspect } from "../src/lib/automation-store";
const summary = {
  updated: 0,
  invalid: 0,
  emails: 0,
  phones: 0,
  verification: [] as { id: string; name: string }[],
};
for (const m of listMissions().filter((m) => m.mode === "live" && m.scan)) {
  for (let i = 0; i < m.scan!.pages.length; i++) {
    const old = m.scan!.pages[i];
    try {
      const html = await readFile(
        `${workspace(m.id)}/scan/page-${i + 1}.html`,
        "utf8",
      );
      m.scan!.pages[i] = parsePage(html, old.url, old.status, old.responseMs);
    } catch {}
  }
  const problems = sourceProblems(m.scan!);
  if (problems.length) {
    if (m.automation) m.automation.qualified = false;
    m.demo = undefined;
    m.qa = { status: "FAILED", checks: [], issues: problems };
    m.status = "FAILED";
    m.error = `Source quality gate: ${problems.join("; ")}`;
    m.failedAt = new Date().toISOString();
    summary.invalid++;
  } else if (
    m.status === "FAILED" &&
    m.error?.startsWith("Source quality gate:")
  ) {
    m.status = "COMPLETED";
    m.error = null;
    m.failedAt = null;
    m.qa = undefined;
  }
  summary.emails += new Set(m.scan!.pages.flatMap((p) => p.emails)).size;
  summary.phones += new Set(m.scan!.pages.flatMap((p) => p.phones)).size;
  saveMission(m);
  reconcileProspect(m.id);
  summary.updated++;
}
for (const name of []) {
  const old = listMissions().find((m) => m.name === name && m.mode === "live");
  if (old) {
    const m = createMission(old.websiteUrl, old.name, "live");
    summary.verification.push({ id: m.id, name: m.name });
  }
}
console.log(JSON.stringify(summary));

const { buildDemo, qaDemo } = await import("../src/lib/demo");
const { getMission } = await import("../src/lib/db");
const { calculateAudit } = await import("../src/lib/audit");
for (const id of [
  "b6e268a1-6525-4912-bb1d-a217567f2755",
  "36bc9633-cc48-4837-bcf6-4ab253e2d482",
]) {
  const m = getMission(id)!;
  m.audit = calculateAudit(m.scan!);
  await buildDemo(m, () => {});
  m.qa = await qaDemo(m, () => {});
  m.status = m.qa.status === "PASSED" ? "COMPLETED" : "FAILED";
  m.error = m.qa.issues.join("; ") || null;
  m.currentStage = "COMPLETE";
  m.progress = 100;
  m.completedAt = new Date().toISOString();
  saveMission(m);
  console.log(
    JSON.stringify({
      id,
      name: m.name,
      status: m.status,
      qa: m.qa,
      services: m.scan!.pages.flatMap((p) => p.services).slice(0, 8),
    }),
  );
}
