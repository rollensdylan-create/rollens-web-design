import { spawn } from "node:child_process";
import { mkdtemp, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import assert from "node:assert/strict";
const scratch = path.resolve("../../work");
await mkdir(scratch, { recursive: true });
const data = await mkdtemp(path.join(scratch, "webforge-validation-"));
const root = "http://127.0.0.1:4334";
const results = [];
const children = [];
let logs = "";
const env = {
  ...process.env,
  WEBFORGE_DATA_DIR: data,
  AGENT_MODE: "template",
  AI_PROVIDER: "deterministic",
  WEBFORGE_ACCESS_TOKEN: "",
  MAX_PAGES: "1",
  SCAN_TIMEOUT_MS: "10000",
  NEXT_TELEMETRY_DISABLED: "1",
};
function child(args) {
  const p = spawn(process.execPath, args, {
    cwd: process.cwd(),
    env,
    stdio: ["ignore", "pipe", "pipe"],
  });
  p.stdout.on("data", (d) => {
    logs += d.toString();
  });
  p.stderr.on("data", (d) => {
    logs += d.toString();
  });
  children.push(p);
  return p;
}
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
async function api(url, body, expected = 200, headers = {}) {
  const r = await fetch(root + url, {
    method: body ? "POST" : "GET",
    headers: { "Content-Type": "application/json", ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  assert.equal(
    r.status,
    expected,
    `${url}: ${await (r.status !== expected ? r.text() : Promise.resolve(""))}`,
  );
  return r.json();
}
async function waitUntil(fn, timeout = 30000) {
  const until = Date.now() + timeout;
  while (Date.now() < until) {
    const r = await fn();
    if (r) return r;
    await delay(200);
  }
  throw new Error("Integration wait timed out");
}
async function done(id) {
  return waitUntil(async () => {
    const m = await api(`/api/missions/${id}`);
    if (m.status === "FAILED") throw new Error(m.error);
    return m.status === "COMPLETED" ? m : false;
  });
}
function passed(name) {
  results.push({ name, status: "passed" });
  console.log(`PASS ${name}`);
}
try {
  child([
    "node_modules/next/dist/bin/next",
    "start",
    "--hostname",
    "127.0.0.1",
    "--port",
    "4334",
  ]);
  await waitUntil(async () => {
    try {
      return (await fetch(root + "/api/missions")).ok;
    } catch {
      return false;
    }
  });
  await api(
    "/api/missions",
    { name: "Private target", url: "http://127.0.0.1", mode: "live" },
    400,
  );
  await api(
    "/api/missions",
    { name: "Cross-site", url: "https://example.com", mode: "live" },
    403,
    { Origin: "https://evil.test" },
  );
  passed("private target and cross-origin requests rejected");
  const m = await api(
    "/api/missions",
    {
      name: "Integration training fixture",
      url: "https://fixture.example.test",
      mode: "fixture",
    },
    201,
  );
  await api(`/api/missions/${m.id}`, { action: "pause" });
  assert.equal((await api(`/api/missions/${m.id}`)).status, "PAUSED");
  passed("queued pause persisted");
  const cancelled = await api(
    "/api/missions",
    {
      name: "Cancellation test fixture",
      url: "https://fixture.example.test",
      mode: "fixture",
    },
    201,
  );
  await api(`/api/missions/${cancelled.id}`, { action: "cancel" });
  await api(`/api/missions/${cancelled.id}`, { action: "resume" }, 400);
  assert.equal(
    (await api(`/api/missions/${cancelled.id}`)).status,
    "CANCELLED",
  );
  passed("cancellation persisted and invalid transition rejected");
  child(["--import", "tsx", "src/worker/main.ts"]);
  await api(`/api/missions/${m.id}`, { action: "resume" });
  let result = await done(m.id);
  assert.equal(result.qa.status, "PASSED");
  assert.equal(result.qa.checks.length, 3);
  assert.equal(result.scan.warnings.length, 1);
  passed(
    "resumed fixture completes real browser build and QA at three viewports",
  );
  const demo = await fetch(root + result.demo.previewUrl);
  assert(
    demo.headers.get("content-security-policy").includes("default-src 'none'"),
  );
  assert((await demo.text()).includes("Development fixture"));
  assert(
    (await fetch(`${root}/api/artifacts/${m.id}/screenshots/demo-390.png`)).ok,
  );
  passed(
    "preview is labelled, sandboxed, and screenshot artifacts are readable",
  );
  await api(`/api/missions/${m.id}`, { action: "qa" });
  result = await done(m.id);
  assert.equal(
    result.events.filter((e) => e.stage === "QA" && e.type === "START").length,
    2,
  );
  passed("rerun QA executes another browser verification");
  await api(`/api/missions/${m.id}`, { action: "rebuild" });
  result = await done(m.id);
  assert.equal(
    result.events.filter((e) => e.stage === "BUILD" && e.type === "START")
      .length,
    2,
  );
  passed("rebuild resumes from build checkpoint");
  const live = await api(
    "/api/missions",
    {
      name: "Public live validation",
      url: "https://example.com",
      mode: "live",
    },
    201,
  );
  const liveResult = await done(live.id);
  assert.equal(liveResult.scan.screenshots.length, 3);
  assert(liveResult.scan.pages[0].htmlBytes > 0);
  assert.equal(liveResult.qa.status, "PASSED");
  passed(
    "public website scan produces source screenshots, audit, demo and passing QA",
  );
  const failed = await api(
    "/api/missions",
    {
      name: "Expected HTTP failure test",
      url: "https://example.com/webforge-missing-page",
      mode: "live",
    },
    201,
  );
  const failure = await waitUntil(async () => {
    const r = await api(`/api/missions/${failed.id}`);
    return r.status === "FAILED" ? r : false;
  });
  assert(failure.error.includes("HTTP 404"));
  assert(failure.events.some((e) => e.type === "FAILED"));
  await api(`/api/missions/${failed.id}`, { action: "retry" });
  await api(`/api/missions/${failed.id}`, { action: "cancel" });
  passed("HTTP failure preserves error/events and supports retry/cancel");
  const controller = new AbortController();
  const feed = await fetch(root + "/api/events", { signal: controller.signal });
  assert.equal(feed.headers.get("content-type"), "text/event-stream");
  const chunk = await feed.body.getReader().read();
  assert(new TextDecoder().decode(chunk.value).includes("events"));
  controller.abort();
  passed("SSE returns persisted mission events");
  await writeFile(
    "VALIDATION_RESULTS.json",
    JSON.stringify(
      { timestamp: new Date().toISOString(), checks: results },
      null,
      2,
    ),
  );
} catch (e) {
  console.error(e);
  console.error(logs.slice(-6000));
  process.exitCode = 1;
} finally {
  for (const p of children) p.kill("SIGTERM");
  await delay(1000);
  for (const p of children) if (p.exitCode === null) p.kill("SIGKILL");
}
