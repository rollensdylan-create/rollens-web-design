import { spawn } from "node:child_process";
import { mkdtemp, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import assert from "node:assert/strict";
import Stripe from "stripe";
const work = path.resolve("../../work");
await mkdir(work, { recursive: true });
const data = await mkdtemp(path.join(work, "autopilot-check-"));
const root = "http://127.0.0.1:4335";
const checks = [];
const children = [];
let logs = "";
const env = {
  ...process.env,
  WEBFORGE_DATA_DIR: data,
  WEBFORGE_ACCESS_TOKEN: "",
  AGENT_MODE: "template",
  AI_PROVIDER: "deterministic",
  RESEND_API_KEY: "",
  STRIPE_SECRET_KEY: "",
  STRIPE_WEBHOOK_SECRET: "",
  BRAVE_SEARCH_API_KEY: "",
  PUBLIC_BASE_URL: "",
  MAX_PAGES: "1",
  NEXT_TELEMETRY_DISABLED: "1",
};
function child(args) {
  const p = spawn(process.execPath, args, {
    cwd: process.cwd(),
    env,
    stdio: ["ignore", "pipe", "pipe"],
  });
  p.stdout.on("data", (b) => (logs += b));
  p.stderr.on("data", (b) => (logs += b));
  children.push(p);
  return p;
}
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
async function api(route, body, status = 200) {
  const r = await fetch(root + route, {
    method: body ? "POST" : "GET",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  assert.equal(r.status, status, `${route}: unexpected HTTP ${r.status}`);
  return r.json();
}
async function until(fn, max = 40000) {
  const end = Date.now() + max;
  while (Date.now() < end) {
    const r = await fn();
    if (r) return r;
    await delay(200);
  }
  throw new Error("Timed out");
}
function pass(message) {
  checks.push({ name: message, status: "passed" });
  console.log("PASS " + message);
}
try {
  child([
    "node_modules/next/dist/bin/next",
    "start",
    "--hostname",
    "127.0.0.1",
    "--port",
    "4335",
  ]);
  await until(async () => {
    try {
      return (await fetch(root + "/api/automation")).ok;
    } catch {
      return false;
    }
  });
  const filter = await api(
    "/api/automation",
    { name: "High-score filter test", threshold: 1, enabled: true },
    201,
  );
  const qualified = await api(
    "/api/automation",
    { name: "Qualified build test", threshold: 100, enabled: true },
    201,
  );
  await api(`/api/automation/${filter.id}`, {
    action: "import",
    rows: [{ name: "Filtered public source", url: "https://example.com" }],
  });
  await api(`/api/automation/${qualified.id}`, {
    action: "import",
    rows: [
      {
        name: "Qualified public source",
        url: "https://example.com",
        email: "owner@example.test",
      },
    ],
  });
  const duplicate = await api(`/api/automation/${qualified.id}`, {
    action: "import",
    rows: [{ name: "Duplicate", url: "https://www.example.com/contact" }],
  });
  assert.equal(duplicate.created, 0);
  pass("domain import deduplicates before scanning");
  child(["--import", "tsx", "src/worker/main.ts"]);
  let snapshot = await until(async () => {
    const s = await api("/api/automation");
    const done = s.prospects.every((p) =>
      ["FILTERED_OUT", "DEMO_READY", "FAILED"].includes(p.status),
    );
    return done && s.outbox.length ? s : false;
  });
  const high = snapshot.prospects.find((p) => p.campaignId === filter.id);
  const low = snapshot.prospects.find((p) => p.campaignId === qualified.id);
  assert.equal(high.status, "FILTERED_OUT");
  assert.equal(low.status, "DEMO_READY");
  const highMission = await api(`/api/missions/${high.missionId}`);
  assert(!highMission.demo);
  assert(!highMission.events.some((e) => e.stage === "BUILD"));
  pass("source at or above threshold is filtered without a build");
  const lowMission = await api(`/api/missions/${low.missionId}`);
  assert.equal(lowMission.qa.status, "PASSED");
  assert(lowMission.demo);
  pass("qualified source automatically builds and passes three-viewport QA");
  const o = snapshot.outbox.find((o) => o.prospectId === low.id);
  assert.equal(o.state, "DRAFT");
  assert(o.blockers.some((s) => s.includes("permission")));
  assert(o.blockers.some((s) => s.includes("Resend")));
  pass(
    "outreach is prepared automatically but missing permission/keys blocks delivery",
  );
  const preview = await fetch(`${root}/p/${o.token}`);
  assert.equal(preview.status, 200);
  assert((await preview.text()).includes("Subscribe securely with Stripe"));
  assert.equal((await fetch(`${root}/api/public/demo/${o.token}`)).status, 200);
  pass(
    "recipient preview exposes demo and recurring offer without admin access",
  );
  assert.equal(
    (await fetch(`${root}/api/public/checkout/${o.token}`, { method: "POST" }))
      .status,
    503,
  );
  pass("unconfigured Stripe cannot claim checkout succeeded");
  const confirm = await fetch(`${root}/api/public/unsubscribe/${o.token}`);
  assert.equal(confirm.status, 200);
  assert.equal(
    (
      await fetch(`${root}/api/public/unsubscribe/${o.token}`, {
        method: "POST",
      })
    ).status,
    200,
  );
  snapshot = await api("/api/automation");
  assert.equal(snapshot.outbox.find((x) => x.id === o.id).state, "SUPPRESSED");
  pass("unsubscribe suppresses pending outreach immediately");
  const connections = await api("/api/connections", {
    stripeKey: "sk_test_integration_fixture",
    stripeWebhook: "whsec_integration_fixture",
    publicBase: "https://preview.example.test",
  });
  assert.equal(connections.stripe, true);
  assert(!JSON.stringify(connections).includes("sk_test_"));
  pass("connection setup does not return API secrets");
  const payload = JSON.stringify({
    id: "evt_signed_fixture",
    object: "event",
    created: Math.floor(Date.now() / 1000),
    type: "checkout.session.completed",
    data: {
      object: {
        id: "cs_test_fixture",
        client_reference_id: o.id,
        customer: "cus_fixture",
        subscription: "sub_fixture",
      },
    },
  });
  const stripe = new Stripe("sk_test_fixture");
  const signature = stripe.webhooks.generateTestHeaderString({
    payload,
    secret: "whsec_integration_fixture",
  });
  assert.equal(
    (
      await fetch(root + "/api/stripe/webhook", {
        method: "POST",
        headers: { "stripe-signature": signature },
        body: payload,
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await fetch(root + "/api/stripe/webhook", {
        method: "POST",
        headers: { "stripe-signature": signature },
        body: payload,
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await fetch(root + "/api/stripe/webhook", {
        method: "POST",
        headers: { "stripe-signature": "invalid" },
        body: payload,
      })
    ).status,
    400,
  );
  snapshot = await api("/api/automation");
  assert.equal(
    snapshot.outbox.find((x) => x.id === o.id).subscriptionStatus,
    "checkout_completed",
  );
  pass(
    "signed webhook updates subscription record; replay is safe and invalid signatures fail",
  );
  await writeFile(
    "AUTOMATION_VALIDATION.json",
    JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        providerMode:
          "Local tests only: email/checkout providers are mocked or unconfigured; no real outreach or charge",
        checks,
      },
      null,
      2,
    ),
  );
} catch (e) {
  console.error(e);
  console.error(logs.slice(-5000));
  process.exitCode = 1;
} finally {
  for (const p of children) p.kill("SIGTERM");
  await delay(1000);
  for (const p of children) if (p.exitCode === null) p.kill("SIGKILL");
}
