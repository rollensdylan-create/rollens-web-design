import { open, unlink, mkdir } from "node:fs/promises";
import path from "node:path";
import {
  claim,
  event,
  saveMission,
  getMission,
  heartbeat,
  recoverInterrupted,
  stageRun,
  finishStage,
} from "../lib/db";
import { config, ROOT } from "../lib/config";
import { STAGES, Mission } from "../lib/types";
import { artifact, workspace } from "../lib/artifacts";
import { validateUrl } from "../lib/security";
import { sourceProblems } from "../lib/source-quality";
import { scanSite, fixtureScan } from "../lib/scanner";
import { calculateAudit } from "../lib/audit";
import { provider } from "../lib/providers";
import { buildDemo, qaDemo, runAgent } from "../lib/demo";
import { automationTick, recoverEmailHandoffs } from "../lib/automation";
import { reconcileProspect } from "../lib/automation-store";
const lockPath = path.join(ROOT, "worker.lock");
let lock: Awaited<ReturnType<typeof open>>;
try {
  lock = await open(lockPath, "wx");
  await lock.writeFile(String(process.pid));
} catch {
  const { readFile } = await import("node:fs/promises");
  const pid = Number(await readFile(lockPath, "utf8").catch(() => 0));
  let alive = false;
  try {
    if (pid) {
      process.kill(pid, 0);
      alive = true;
    }
  } catch {}
  if (alive) throw new Error("A WebForge worker is already running");
  await unlink(lockPath).catch(() => {});
  lock = await open(lockPath, "wx");
  await lock.writeFile(String(process.pid));
}
let stopping = false;
process.on("SIGTERM", () => {
  stopping = true;
});
process.on("SIGINT", () => {
  stopping = true;
});
recoverInterrupted();
recoverEmailHandoffs();
heartbeat();
const pulse = setInterval(heartbeat, 3000);
console.log("WebForge worker ready · durable queue · one mission at a time");
async function execute(m: Mission) {
  const started = Date.now();
  const accumulated = m.usage.durationMs;
  const emit = (message: string) =>
    event(m.id, m.currentStage, "PROGRESS", "INFO", message);
  try {
    await mkdir(path.join(workspace(m.id), "screenshots"), { recursive: true });
    for (let index = m.nextStage; index < STAGES.length; index++) {
      const fresh = getMission(m.id)!;
      if (fresh.status === "CANCELLED") return;
      if (fresh.pauseRequested || stopping) {
        fresh.status = "PAUSED";
        fresh.pauseRequested = false;
        saveMission(fresh);
        event(
          m.id,
          fresh.currentStage,
          "PAUSED",
          "INFO",
          "Paused safely between stages",
        );
        return;
      }
      if (Date.now() - started > config.maxRuntimeMs)
        throw new Error("Mission exceeded the configured execution time");
      m.currentStage = STAGES[index];
      m.progress = Math.round((index / 9) * 100);
      m.status = "RUNNING";
      saveMission(m);
      const run = stageRun(m.id, m.currentStage);
      event(
        m.id,
        m.currentStage,
        "START",
        "INFO",
        `${m.currentStage.toLowerCase()} started`,
      );
      let filteredOut = false;
      try {
        switch (m.currentStage) {
          case "DISCOVERY":
            if (m.mode === "live") await validateUrl(m.websiteUrl);
            await artifact(m.id, "input/mission.json", {
              name: m.name,
              url: m.websiteUrl,
              mode: m.mode,
              limits: { maxPages: config.maxPages, maxDepth: config.maxDepth },
            });
            break;
          case "SCAN":
            m.scan =
              m.mode === "fixture"
                ? fixtureScan()
                : await scanSite(m.id, m.websiteUrl, emit);
            if (m.mode === "fixture") {
              emit("Simulated source fixture · real audit/build/QA pipeline");
              await artifact(m.id, "scan/site-data.json", m.scan);
            }
            break;
          case "ANALYSIS":
            if (!m.scan?.pages.length) throw new Error("No scan available");
            await artifact(m.id, "scan/metrics.json", {
              pages: m.scan.pages.length,
              viewports: m.scan.viewports,
              brokenLinks: m.scan.brokenLinks,
              warnings: m.scan.warnings,
            });
            emit(
              `${m.scan.pages.length} pages analysed; ${m.scan.pages[0].services.length} service headings extracted`,
            );
            break;
          case "AUDIT":
            {
              const problems = sourceProblems(m.scan!);
              if (problems.length)
                throw new Error(`Source quality gate: ${problems.join("; ")}`);
            }
            m.audit = calculateAudit(m.scan!, config.weights);
            await artifact(m.id, "audit/audit.json", m.audit);
            emit(
              `Weighted score: ${m.audit.overallScore}/100 · ${m.audit.findings.length} findings`,
            );
            if (m.automation) {
              m.automation.qualified =
                m.audit.overallScore < m.automation.threshold;
              if (!m.automation.qualified) {
                filteredOut = true;
                m.status = "COMPLETED";
                m.progress = 100;
                m.completedAt = new Date().toISOString();
                emit(
                  `Score ${m.audit.overallScore} is at or above cutoff ${m.automation.threshold}: skipped strategy, build and outreach`,
                );
              }
            }
            break;
          case "STRATEGY":
            m.strategy = await provider().generateStrategy(m);
            await artifact(m.id, "strategy/strategy.json", m.strategy);
            emit(m.strategy.provider);
            break;
          case "BUILD":
            await buildDemo(m, emit);
            break;
          case "QA":
            m.qa = await qaDemo(m, emit);
            break;
          case "FIX":
            if (m.qa?.status === "FAILED") {
              if (config.agentMode !== "opencode")
                throw new Error(
                  `QA failed: ${m.qa.issues.join("; ")}. Rebuild after fixing the template or configure the OpenCode adapter.`,
                );
              let fixed = false;
              for (
                let attempt = 0;
                attempt < config.maxFixAttempts;
                attempt++
              ) {
                emit(
                  `Bounded fix attempt ${attempt + 1}/${config.maxFixAttempts}`,
                );
                await runAgent(m, true, emit);
                m.qa = await qaDemo(m, emit);
                if (m.qa.status === "PASSED") {
                  fixed = true;
                  break;
                }
              }
              if (!fixed)
                throw new Error(
                  "QA still failing after the configured fix limit",
                );
            } else emit("QA passed · no fix execution needed");
            break;
          case "DEPLOY":
            if (m.qa?.status !== "PASSED")
              throw new Error("Preview cannot be marked ready until QA passes");
            m.demo = {
              ...m.demo!,
              status: "PREVIEW_READY",
              buildStatus: "PASSED",
            };
            await artifact(m.id, "build/build-result.json", m.demo);
            emit("Isolated local preview ready · no public deployment");
            break;
          case "COMPLETE":
            m.status = "COMPLETED";
            m.progress = 100;
            m.completedAt = new Date().toISOString();
            emit(
              "Mission complete. Source evidence, audit, strategy, demo and QA saved.",
            );
            break;
        }
        finishStage(run);
        m.nextStage = filteredOut ? STAGES.length : index + 1;
        m.usage.durationMs = accumulated + Date.now() - started;
        // Controls may have arrived during this stage; never overwrite cancellation or pause requests.
        const latest = getMission(m.id)!;
        if (latest.status === "CANCELLED") {
          m.status = "CANCELLED";
          m.pauseRequested = false;
          saveMission(m);
          return;
        }
        m.pauseRequested = latest.pauseRequested;
        saveMission(m);
        event(
          m.id,
          m.currentStage,
          "COMPLETE",
          "SUCCESS",
          `${m.currentStage.toLowerCase()} completed`,
        );
        if (filteredOut) {
          reconcileProspect(m.id);
          return;
        }
      } catch (err) {
        finishStage(run, err instanceof Error ? err.message : "Stage failed");
        throw err;
      }
    }
  } catch (err) {
    const latest = getMission(m.id)!;
    if (latest.status === "CANCELLED") return;
    m.status = "FAILED";
    m.error = err instanceof Error ? err.message : "Mission failed";
    m.failedAt = new Date().toISOString();
    m.attempts++;
    m.usage.durationMs = accumulated + Date.now() - started;
    saveMission(m);
    event(m.id, m.currentStage, "FAILED", "ERROR", m.error);
  }
}
let lastAutomationTick = 0;
while (!stopping) {
  if (Date.now() - lastAutomationTick > 5000) {
    lastAutomationTick = Date.now();
    try {
      await automationTick();
    } catch (e) {
      console.error(
        "Automation tick failed:",
        e instanceof Error ? e.message : "Unknown error",
      );
    }
  }
  const m = claim();
  if (m) {
    console.log(`Running mission ${m.id} (${m.mode})`);
    await execute(m);
    reconcileProspect(m.id);
  } else await new Promise((r) => setTimeout(r, 1000));
}
clearInterval(pulse);
await lock.close();
await unlink(lockPath).catch(() => {});
console.log("Worker stopped");
