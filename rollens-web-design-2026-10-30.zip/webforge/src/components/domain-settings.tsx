"use client";
import { useState } from "react";
import "./domain-settings.css";
type Domain = {
  id: string;
  hostname: string;
  status: string;
  serving: boolean;
  txtName: string;
  txtValue: string;
  last_error: string | null;
};
export default function DomainSettings({ siteId }: { siteId: string }) {
  const [open, setOpen] = useState(false),
    [domains, setDomains] = useState<Domain[]>([]),
    [hostname, setHostname] = useState(""),
    [ip, setIp] = useState(""),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  async function load() {
    const r = await fetch(`/api/public/domains?site=${siteId}`, {
      cache: "no-store",
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error);
    setDomains(data.domains);
    setIp(data.ipv4);
  }
  async function action(input: object) {
    setBusy(true);
    setMessage("");
    try {
      const r = await fetch("/api/public/domains", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...input, site: siteId }),
      });
      const data = await r.json();
      if (!r.ok) {
        await load();
        throw new Error(data.error);
      }
      setDomains(data.domains);
      setIp(data.ipv4);
      setHostname("");
      if ((input as { action: string }).action === "verify")
        setMessage(
          "DNS verified. A paid, published site can now use this hostname. HTTPS is prepared automatically on the first visit.",
        );
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="domain-settings">
      <button
        className="domain-toggle"
        type="button"
        aria-expanded={open}
        disabled={busy}
        onClick={() => {
          setOpen(!open);
          if (!open) {
            setBusy(true);
            load()
              .catch((e) => setMessage(e.message))
              .finally(() => setBusy(false));
          }
        }}
      >
        Custom domains <span>{open ? "−" : "+"}</span>
      </button>
      {open && (
        <div className="domain-body">
          <p>
            Use a domain you already own on any paid plan. Domain registration
            and renewal stay with your provider. You can connect a root domain
            and www separately (up to five hostnames per website).
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              action({ action: "add", hostname });
            }}
          >
            <label>
              Domain or subdomain
              <input
                required
                maxLength={220}
                value={hostname}
                onChange={(e) => setHostname(e.target.value)}
                placeholder="yourbusiness.com.au"
                autoCapitalize="none"
                autoCorrect="off"
                disabled={busy}
              />
            </label>
            <button type="submit" disabled={busy}>
              Add domain
            </button>
          </form>
          <p className="domain-instructions">
            Add these records where you manage DNS. For a root domain, your
            provider may show the A-record name as @. Remove conflicting A/AAAA
            records for this hostname; leave mail and unrelated records
            unchanged. In Cloudflare use DNS only. Keep the TXT record in place.
            DNS changes can take up to 48 hours.
          </p>
          {message && (
            <p className="domain-message" role="status">
              {message}
            </p>
          )}
          {domains.map((d) => (
            <div className="domain-record" key={d.id}>
              <div className="domain-name">
                <strong>{d.hostname}</strong>
                <span>
                  {d.serving
                    ? "Ready for HTTPS"
                    : d.status === "verified"
                      ? "DNS verified · publish with an active plan"
                      : "Waiting for DNS"}
                </span>
              </div>
              <div className="domain-table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Type</th>
                      <th>Name</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>A</td>
                      <td>
                        <code>{d.hostname}</code>
                      </td>
                      <td>
                        <code>{ip}</code>
                      </td>
                    </tr>
                    <tr>
                      <td>TXT</td>
                      <td>
                        <code>{d.txtName}</code>
                      </td>
                      <td>
                        <code>{d.txtValue}</code>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p>
                Some DNS providers append your domain automatically. Enter the
                relative name they require so the final name matches the table
                exactly. To connect www, add it as a separate hostname and
                follow its records.
              </p>
              {d.last_error && <p className="domain-error">{d.last_error}</p>}
              <div className="domain-actions">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => action({ action: "verify", id: d.id })}
                >
                  {busy ? "Checking…" : "Check DNS"}
                </button>
                {d.serving && (
                  <a
                    href={`https://${d.hostname}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open website ↗
                  </a>
                )}
                <button
                  type="button"
                  className="domain-remove"
                  disabled={busy}
                  onClick={() => {
                    if (
                      window.confirm(
                        `Disconnect ${d.hostname}? Your Rollens website address will keep working. DNS records stay with your provider.`,
                      )
                    )
                      action({ action: "remove", id: d.id });
                  }}
                >
                  Disconnect
                </button>
              </div>
            </div>
          ))}
          {!domains.length && !busy && (
            <p>
              No custom domains connected yet. Your Rollens address keeps
              working.
            </p>
          )}
          <p>
            Only the published website appears on your domain. Your account and
            billing stay at rollenswebdesign.space. If hosting is cancelled or
            the site is unpublished, the custom-domain website becomes
            unavailable. Domains are rechecked periodically.
          </p>
        </div>
      )}
    </section>
  );
}
