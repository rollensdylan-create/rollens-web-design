"use client";
import { useEffect, useId, useRef, useState } from "react";
import "./website-editor.css";
export type SiteDraft = {
  name: string;
  brief: string;
  email: string;
  phone: string;
  area: string;
  services: string[];
  gallery: string[];
  theme: number;
  personal: boolean;
  headline: string;
  tagline: string;
  seoTitle: string;
  seoDescription: string;
  branding: boolean;
};
export const emptyDraft: SiteDraft = {
  name: "",
  brief: "",
  email: "",
  phone: "",
  area: "",
  services: [],
  gallery: [],
  theme: 0,
  personal: false,
  headline: "",
  tagline: "",
  seoTitle: "",
  seoDescription: "",
  branding: true,
};
export function normalizeDraft(value: Partial<SiteDraft>): SiteDraft {
  return {
    ...emptyDraft,
    ...value,
    services: Array.isArray(value.services) ? value.services : [],
    gallery: Array.isArray(value.gallery) ? value.gallery : [],
  };
}
export default function WebsiteEditor({
  value,
  onChange,
  onSave,
  saving = false,
  locked = false,
  advanced = true,
  onRequireAccount,
}: {
  value: SiteDraft;
  onChange: (d: SiteDraft) => void;
  onSave?: () => void;
  saving?: boolean;
  locked?: boolean;
  advanced?: boolean;
  onRequireAccount?: () => void;
}) {
  const [tab, setTab] = useState("content"),
    [html, setHtml] = useState(""),
    [notice, setNotice] = useState(""),
    [view, setView] = useState("responsive"),
    [uploading, setUploading] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const id = useId();
  function field<K extends keyof SiteDraft>(key: K, next: SiteDraft[K]) {
    if (!locked) onChange({ ...value, [key]: next });
  }
  useEffect(() => {
    const abort = new AbortController();
    const timer = setTimeout(() => {
      fetch("/api/public/design-preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: abort.signal,
        body: JSON.stringify({
          ...value,
          services: value.services.filter((s) => s.trim()),
          gallery: value.gallery.filter((s) => s.trim()),
          name: value.name.trim() || "Your business",
          brief:
            value.brief.trim().length >= 10
              ? value.brief
              : "Tell visitors what you do and how they can get in touch.",
        }),
      })
        .then(async (r) => {
          if (!r.ok)
            throw new Error(
              "Complete valid details and HTTPS image links to refresh the preview.",
            );
          let result = await r.text();
          result = result.replace(
            "</body>",
            `<style>[data-edit-field]{cursor:pointer;outline-offset:5px}[data-edit-field]:hover,[data-edit-field]:focus{outline:2px dashed #ff7648}</style><script>function pick(e){var t=e.target.closest('[data-edit-field]');if(t&&${!locked}){e.preventDefault();e.stopPropagation();parent.postMessage({type:'rollens-select',field:t.getAttribute('data-edit-field')},'*')}else{var a=e.target.closest('a');if(a){e.preventDefault();var href=a.getAttribute('href')||'';if(href.startsWith('#')){var section=document.getElementById(href.slice(1));if(section)section.scrollIntoView({behavior:'smooth'})}}}}document.addEventListener('click',pick);document.querySelectorAll('[data-edit-field]').forEach(function(t){t.tabIndex=0});document.addEventListener('keydown',function(e){if(e.key==='Enter')pick(e)})<\/script></body>`,
          );
          setHtml(result);
          setNotice("");
        })
        .catch((e) => {
          if (e.name !== "AbortError") setNotice(e.message);
        });
    }, 400);
    return () => {
      clearTimeout(timer);
      abort.abort();
    };
  }, [value, locked]);
  useEffect(() => {
    function select(event: MessageEvent) {
      if (
        event.source !== frame.current?.contentWindow ||
        event.data?.type !== "rollens-select"
      )
        return;
      let key = String(event.data.field);
      if (
        !/^(name|headline|tagline|brief|phone|email|gallery|services\.\d+)$/.test(
          key,
        )
      )
        return;
      if (key.startsWith("services.")) {
        const indexes = value.services
          .map((s, i) => (s.trim() ? i : -1))
          .filter((i) => i >= 0);
        const index = indexes[Number(key.split(".")[1])];
        if (index === undefined) return;
        key = `services.${index}`;
      }
      setTab(
        key === "gallery"
          ? "photos"
          : key === "phone" || key === "email"
            ? "contact"
            : "content",
      );
      requestAnimationFrame(() =>
        root.current
          ?.querySelector<HTMLElement>(`[data-editor-field="${key}"]`)
          ?.focus(),
      );
    }
    window.addEventListener("message", select);
    return () => window.removeEventListener("message", select);
  }, [value]);
  async function upload(files: FileList | null) {
    if (!files || locked) return;
    setUploading(true);
    setNotice("");
    const next = [...value.gallery];
    try {
      for (const file of Array.from(files)) {
        const body = new FormData();
        body.set("image", file);
        const r = await fetch("/api/public/site-image", {
          method: "POST",
          body,
        });
        const v = await r.json();
        if (!r.ok) {
          if (r.status === 401) {
            setNotice(v.error);
            return;
          }
          throw new Error(v.error);
        }
        next.push(v.url);
      }
      field("gallery", next);
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Upload failed.");
      if (next.length !== value.gallery.length) field("gallery", next);
    } finally {
      setUploading(false);
    }
  }
  function movePhoto(i: number, j: number) {
    const next = [...value.gallery];
    [next[i], next[j]] = [next[j], next[i]];
    field("gallery", next);
  }
  return (
    <div className="we" ref={root}>
      <div className="we-top">
        <div>
          <span className={`we-dot ${locked ? "locked" : ""}`} />
          {locked ? "Published · editing locked" : "Draft workspace"}
          <small>
            {locked
              ? "You can view your site. Pro includes ongoing editing."
              : "Click text or an image in the preview to edit it."}
          </small>
        </div>
        <div className="we-view">
          <button
            type="button"
            aria-pressed={view === "responsive"}
            onClick={() => setView("responsive")}
          >
            Responsive
          </button>
          <button
            type="button"
            aria-pressed={view === "mobile"}
            onClick={() => setView("mobile")}
          >
            Mobile
          </button>
        </div>
        {onSave && (
          <button
            type="button"
            className="we-save"
            disabled={locked || saving || uploading}
            onClick={onSave}
          >
            {saving ? "Saving…" : "Save draft ↗"}
          </button>
        )}
      </div>
      <div className="we-body">
        <aside className="we-panel">
          <nav className="we-tabs" aria-label="Website editor">
            {["content", "photos", "design", "contact", "search"].map((t) => (
              <button
                key={t}
                type="button"
                aria-pressed={tab === t}
                onClick={() => setTab(t)}
              >
                {t}
              </button>
            ))}
          </nav>
          <div className="we-notice" role="status" aria-live="polite">
            {notice}
          </div>
          <fieldset disabled={locked || saving} className="we-fields">
            {tab === "content" && (
              <>
                <div className="we-panel-heading">
                  <span>01 / YOUR WORDS</span>
                  <h3>Make it sound like you.</h3>
                </div>
                <label htmlFor={id + "name"}>
                  Website name
                  <input
                    id={id + "name"}
                    data-editor-field="name"
                    maxLength={100}
                    value={value.name}
                    onChange={(e) => field("name", e.target.value)}
                    placeholder="Your business or name"
                  />
                </label>
                <label>
                  Main headline
                  <textarea
                    data-editor-field="headline"
                    maxLength={150}
                    value={value.headline}
                    onChange={(e) => field("headline", e.target.value)}
                    placeholder="Write your own opening line"
                    rows={2}
                  />
                </label>
                <label>
                  Opening description
                  <textarea
                    data-editor-field="tagline"
                    maxLength={300}
                    value={value.tagline}
                    onChange={(e) => field("tagline", e.target.value)}
                    placeholder="A short welcome for your visitors"
                    rows={3}
                  />
                </label>
                <label>
                  About your business or work
                  <textarea
                    data-editor-field="brief"
                    maxLength={2000}
                    value={value.brief}
                    onChange={(e) => field("brief", e.target.value)}
                    rows={5}
                    placeholder="What you do, who you help and what visitors should know."
                  />
                </label>
                <div className="we-label">
                  {value.personal ? "Work & interests" : "Services"}
                </div>
                {value.services.map((s, i) => (
                  <div className="we-item" key={i}>
                    <input
                      aria-label={`Service ${i + 1}`}
                      data-editor-field={`services.${i}`}
                      value={s}
                      maxLength={150}
                      onChange={(e) =>
                        field(
                          "services",
                          value.services.map((v, j) =>
                            i === j ? e.target.value : v,
                          ),
                        )
                      }
                    />
                    <button
                      type="button"
                      aria-label={`Remove service ${i + 1}`}
                      onClick={() =>
                        field(
                          "services",
                          value.services.filter((_, j) => i !== j),
                        )
                      }
                    >
                      ×
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  className="we-secondary"
                  onClick={() => field("services", [...value.services, ""])}
                >
                  + Add {value.personal ? "work" : "service"}
                </button>
              </>
            )}
            {tab === "photos" && !advanced && (
              <p className="we-help">
                Starter is text focused. Choose Plus or Pro to add photos.
              </p>
            )}
            {tab === "photos" && advanced && (
              <>
                <div className="we-panel-heading">
                  <span>02 / YOUR PHOTOS</span>
                  <h3>Show your world.</h3>
                </div>
                <p className="we-help">
                  The first photo becomes your cover. Add your own photos or
                  paste an HTTPS image link. Plus and Pro have no plan-based
                  image quota.
                </p>
                <label className="we-upload">
                  {uploading ? "Uploading…" : "↑ Upload photos"}
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/webp,image/avif"
                    disabled={uploading}
                    onChange={(e) => upload(e.target.files)}
                  />
                </label>
                {onRequireAccount && (
                  <button
                    type="button"
                    className="we-text-button"
                    onClick={onRequireAccount}
                  >
                    Create an account to upload photos ↗
                  </button>
                )}
                <p className="we-help">
                  Use images you have permission to publish. Uploads become
                  unlisted image links; each file can be up to 10 MB.
                </p>
                {value.gallery.map((url, i) => (
                  <div className="we-photo" key={i}>
                    {url.startsWith("https://") && (
                      <img
                        src={url}
                        alt={`Photo ${i + 1}`}
                        referrerPolicy="no-referrer"
                      />
                    )}
                    <label>
                      {i === 0 ? "Cover photo" : "Photo " + (i + 1)}
                      <input
                        data-editor-field={i === 0 ? "gallery" : undefined}
                        type="url"
                        value={url}
                        onChange={(e) =>
                          field(
                            "gallery",
                            value.gallery.map((v, j) =>
                              i === j ? e.target.value : v,
                            ),
                          )
                        }
                        placeholder="https://…"
                      />
                    </label>
                    <div>
                      {i > 0 && (
                        <button type="button" onClick={() => movePhoto(i, 0)}>
                          Use as cover
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          field(
                            "gallery",
                            value.gallery.filter((_, j) => i !== j),
                          )
                        }
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  className="we-secondary"
                  data-editor-field={
                    !value.gallery.length ? "gallery" : undefined
                  }
                  onClick={() => field("gallery", [...value.gallery, ""])}
                >
                  + Add image link
                </button>
              </>
            )}
            {tab === "design" && (
              <>
                <div className="we-panel-heading">
                  <span>03 / THE LOOK</span>
                  <h3>Find your direction.</h3>
                </div>
                <label>
                  Website type
                  <select
                    value={value.personal ? "personal" : "business"}
                    onChange={(e) =>
                      field("personal", e.target.value === "personal")
                    }
                  >
                    <option value="business">Business website</option>
                    <option value="personal">
                      Personal website / portfolio
                    </option>
                  </select>
                </label>
                <div className="we-themes">
                  {["Studio", "Editorial", "Bold"].map((name, i) => (
                    <button
                      type="button"
                      key={name}
                      className={`we-theme theme-${i}`}
                      aria-pressed={value.theme === i}
                      onClick={() => field("theme", i)}
                    >
                      <span>Aa</span>
                      <strong>{name}</strong>
                      <small>
                        {i === 0
                          ? "Natural & understated"
                          : i === 1
                            ? "Warm & expressive"
                            : "Clear & confident"}
                      </small>
                    </button>
                  ))}
                </div>
                <label className="we-check">
                  <input
                    type="checkbox"
                    checked={value.branding}
                    disabled={!advanced}
                    onChange={(e) => field("branding", e.target.checked)}
                  />
                  Show Rollens footer credit
                </label>
                <p className="we-help">
                  Removing the footer credit is included with Plus and Pro.
                </p>
              </>
            )}
            {tab === "contact" && (
              <>
                <div className="we-panel-heading">
                  <span>04 / GET CONNECTED</span>
                  <h3>Make the next step easy.</h3>
                </div>
                <label>
                  Public email
                  <input
                    type="email"
                    data-editor-field="email"
                    value={value.email}
                    onChange={(e) => field("email", e.target.value)}
                    placeholder="hello@yourbusiness.com"
                  />
                </label>
                <label>
                  Public phone
                  <input
                    type="tel"
                    data-editor-field="phone"
                    value={value.phone}
                    maxLength={40}
                    onChange={(e) => field("phone", e.target.value)}
                    placeholder="Your phone number"
                  />
                </label>
                <label>
                  Location or service area
                  <input
                    maxLength={100}
                    value={value.area}
                    onChange={(e) => field("area", e.target.value)}
                    placeholder="Melbourne, Victoria"
                  />
                </label>
                <p className="we-help">
                  These details are public on your website. Call and email
                  buttons use the details you enter here.
                </p>
              </>
            )}
            {tab === "search" && (
              <>
                <div className="we-panel-heading">
                  <span>05 / GET FOUND</span>
                  <h3>Your search preview.</h3>
                </div>
                <p className="we-help">
                  Every site gets a page title and description. Plus and Pro let
                  you write your own.
                </p>
                <label>
                  Search title
                  <input
                    disabled={!advanced}
                    maxLength={120}
                    value={value.seoTitle}
                    onChange={(e) => field("seoTitle", e.target.value)}
                    placeholder={value.name || "Your website name"}
                  />
                </label>
                <label>
                  Search description
                  <textarea
                    disabled={!advanced}
                    maxLength={300}
                    value={value.seoDescription}
                    onChange={(e) => field("seoDescription", e.target.value)}
                    placeholder={
                      value.brief.slice(0, 160) ||
                      "Introduce your business in a sentence."
                    }
                    rows={4}
                  />
                </label>
                <div className="we-search-preview">
                  <small>rollenswebdesign.space › sites › your-site</small>
                  <strong>
                    {value.seoTitle || value.name || "Your website"}
                  </strong>
                  <p>
                    {value.seoDescription ||
                      value.brief.slice(0, 160) ||
                      "Your website description appears here."}
                  </p>
                </div>
              </>
            )}
          </fieldset>
        </aside>
        <div className="we-stage">
          <div className="we-browser">
            <i />
            <i />
            <i />
            <span>
              {locked
                ? "Published design"
                : "Your draft · changes are not public yet"}
            </span>
          </div>
          <div className={`we-canvas ${view}`}>
            {html ? (
              <iframe
                ref={frame}
                title="Editable website preview"
                sandbox="allow-scripts"
                srcDoc={html}
              />
            ) : (
              <div className="we-loading">Preparing your website…</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
