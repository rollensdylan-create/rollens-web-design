import { liveSite } from "@/lib/selfserve";
import { renderCustomerSite } from "@/lib/customer-site";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;
  const data = liveSite(slug);
  if (!data)
    return new Response("This website is not currently published.", {
      status: 404,
      headers: { "Cache-Control": "no-store, no-transform", "X-Robots-Tag": "noindex" },
    });
  return new Response(renderCustomerSite(data), {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "Content-Security-Policy":
        "default-src 'none'; style-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
    },
  });
}
