import { outreachByToken, campaign } from "@/lib/automation-store";
import { getMission } from "@/lib/db";
import { money } from "@/lib/outreach";
import { notFound } from "next/navigation";
export const dynamic = "force-dynamic";
export const metadata = {
  robots: { index: false, follow: false },
  referrer: "no-referrer",
};
export default async function Preview({
  params,
  searchParams,
}: {
  params: Promise<{ token: string }>;
  searchParams: Promise<{ checkout?: string }>;
}) {
  const { token } = await params;
  const o = outreachByToken(token);
  if (!o) notFound();
  const m = getMission(o.missionId);
  const c = campaign(o.campaignId);
  if (!m?.demo || m.status !== "COMPLETED" || m.qa?.status !== "PASSED" || !c)
    notFound();
  const { checkout } = await searchParams;
  return (
    <main className="public-offer">
      <header>
        <b>WEBFORGE</b>
        <span>Website preview for {m.name}</span>
      </header>
      {checkout === "success" && (
        <div className="notice">
          Thank you. Stripe is confirming your subscription. We’ll contact you
          to arrange launch.
        </div>
      )}
      <section>
        <div>
          <div className="eyebrow">YOUR WEBSITE, REIMAGINED</div>
          <h1>A fresh start for {m.name}.</h1>
          <p>
            Explore this independent website concept. Business details and
            launch requirements will be confirmed with you before publication.
          </p>
        </div>
        <div className="purchase-box" id="subscribe">
          <b>
            {money(o.priceCents)}
            <small> AUD / month</small>
          </b>
          <p>
            Website hosting and basic maintenance. Recurring monthly
            subscription; cancel through the provider contact below. Domain
            arrangements and any additional work are confirmed before launch.
          </p>
          <form action={`/api/public/checkout/${token}`} method="post">
            <button className="primary" type="submit">
              Subscribe securely with Stripe ↗
            </button>
          </form>
          <small>
            {c.senderName} · {c.replyTo || c.senderEmail}
          </small>
        </div>
      </section>
      <iframe
        title={`${m.name} website concept`}
        src={`/api/public/demo/${token}`}
        sandbox="allow-popups"
      />
      <footer>
        Independent concept · Not the current official website ·{" "}
        <a href={`/api/public/unsubscribe/${token}`}>
          Unsubscribe from outreach
        </a>
      </footer>
    </main>
  );
}
