import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "WebForge · Mission Control",
  description: "Website analysis, redesign and production mission control",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-AU">
      <body>{children}</body>
    </html>
  );
}
