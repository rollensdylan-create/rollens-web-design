"use client";
import { useEffect, useState } from "react";
export default function Connections() {
  const [key, setKey] = useState("");
  const [secret, setSecret] = useState("");
  const [status, setStatus] = useState<{
    stripe: boolean;
    webhook: boolean;
    stripeMode: string;
  } | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  async function refresh() {
    const r = await fetch("/api/connections", { cache: "no-store" });
    if (!r.ok)
      throw new Error(
        "Open this page through your private SSH dashboard connection.",
      );
    setStatus(await r.json());
  }
  useEffect(() => {
    refresh().catch((e) => setMessage(e.message));
  }, []);
  return (
    <main
      style={{
        maxWidth: 760,
        margin: "auto",
        padding: "50px 24px",
        fontSize: 15,
      }}
    >
      <a href="/automation">← Back to Autopilot</a>
      <h1 style={{ margin: "25px 0" }}>Stripe payment setup</h1>
      <p>
        This is the private operator setup screen. It is available only through
        your SSH dashboard connection. Saved secrets are encrypted on the VPS
        and are never returned to this page.
      </p>
      <div
        role="status"
        aria-live="polite"
        style={{ margin: "25px 0", color: "#d3f38a" }}
      >
        {message ||
          (status
            ? `API key: ${status.stripe ? "configured" : "missing"} · Webhook: ${status.webhook ? "configured" : "missing"} · Mode: ${status.stripeMode}`
            : "Checking configuration…")}
      </div>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setMessage("");
          try {
            const r = await fetch("/api/connections", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                ...(key ? { stripeKey: key } : {}),
                ...(secret ? { stripeWebhook: secret } : {}),
              }),
            });
            if (!r.ok)
              throw new Error(
                "Settings could not be saved. Check the key formats and private connection.",
              );
            setKey("");
            setSecret("");
            await refresh();
            setMessage(
              "Saved securely. Checkout remains disabled until integration verification is complete.",
            );
          } catch (e) {
            setMessage(e instanceof Error ? e.message : "Save failed.");
          } finally {
            setBusy(false);
          }
        }}
      >
        <label style={{ display: "block", margin: "24px 0" }}>
          Restricted Stripe API key
          <input
            aria-label="Restricted Stripe API key"
            style={{
              display: "block",
              width: "100%",
              padding: 12,
              marginTop: 8,
              color: "#e5e8ed",
              background: "#14171b",
              border: "1px solid #55604a",
              borderRadius: 5,
            }}
            type="password"
            autoComplete="off"
            placeholder="rk_live_… (leave blank to keep existing)"
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />
        </label>
        <p>
          In Stripe Dashboard → Developers → API keys, create a restricted key
          for WebForge. It needs Checkout Sessions, Customers, Products, Prices
          and Billing Portal read/write access, plus Subscriptions and Invoices
          read access. Store the key here, never in chat.
        </p>
        <label style={{ display: "block", margin: "24px 0" }}>
          Webhook signing secret
          <input
            aria-label="Webhook signing secret"
            style={{
              display: "block",
              width: "100%",
              padding: 12,
              marginTop: 8,
              color: "#e5e8ed",
              background: "#14171b",
              border: "1px solid #55604a",
              borderRadius: 5,
            }}
            type="password"
            autoComplete="off"
            placeholder="whsec_… (leave blank to keep existing)"
            value={secret}
            onChange={(e) => setSecret(e.target.value)}
          />
        </label>
        <button
          disabled={busy || (!key && !secret)}
          style={{
            padding: "12px 22px",
            border: 0,
            borderRadius: 5,
            background: "#d3f38a",
            color: "#24372e",
          }}
        >
          {busy ? "Saving…" : "Save Stripe settings"}
        </button>
      </form>
      <section
        style={{
          marginTop: 40,
          borderTop: "1px solid #394035",
          paddingTop: 25,
        }}
      >
        <h2 style={{ fontSize: 22 }}>Webhook connection</h2>
        <p style={{ marginTop: 15 }}>
          Endpoint:{" "}
          <code>https://rollenswebdesign.space/api/stripe/webhook</code>
        </p>
        <p style={{ marginTop: 15 }}>
          The signing secret comes from the Stripe webhook endpoint. If Stripe
          connector write access is reconnected, I can register that endpoint
          and securely install its secret. The API key above is still needed for
          the running server.
        </p>
        <p style={{ marginTop: 15 }}>
          Also set Stripe’s business profile, website and statement descriptor
          to accurately describe Rollens Web Design before enabling customer
          payments.
        </p>
      </section>
    </main>
  );
}
