import type { Metadata } from "next";
import Connections from "./ui";
export const metadata: Metadata = {
  title: "Private payment setup · WebForge",
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Connections />;
}
