import type { Metadata } from "next";
import Account from "./ui";
export const metadata: Metadata = {
  title: "Your websites · Rollens",
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Account />;
}
