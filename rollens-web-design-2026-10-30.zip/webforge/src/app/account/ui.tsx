"use client";
import { useEffect, useState } from "react";
import DomainSettings from "@/components/domain-settings";
import WebsiteEditor, {
  emptyDraft,
  normalizeDraft,
  type SiteDraft,
} from "@/components/website-editor";
import { SITE_PLANS, planFeatures, type SitePlan } from "@/lib/site-plans";
import "../welcome/landing.css";
import "./workspace.css";
type Site = {
  id: string;
  slug: string;
  published: number;
  locked: number;
  data: SiteDraft;
};
type State = {
  user: {
    email: string;
    plan: SitePlan | null;
    enabled: boolean;
    hasSubscription: boolean;
  } | null;
  sites: Site[];
  billingReady: boolean;
};
export default function Account() {
  const [state, setState] = useState<State | null>(null),
    [data, setData] = useState<SiteDraft>(emptyDraft),
    [selected, setSelected] = useState<string>(),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [mode, setMode] = useState("signup"),
    [reset, setReset] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [dirty, setDirty] = useState(false),
    [approved, setApproved] = useState(false),
    [plan, setPlan] = useState<SitePlan>("plus"),
    [editorOpen, setEditorOpen] = useState(true),
    [loaded, setLoaded] = useState(false);
  async function load() {
    const r = await fetch("/api/public/account", { cache: "no-store" });
    if (!r.ok) throw new Error("Your account could not be loaded.");
    const v = await r.json();
    setState(v);
    return v as State;
  }
  async function api(input: object) {
    const r = await fetch("/api/public/account", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    const v = await r.json();
    if (!r.ok) throw new Error(v.error || "Please try again.");
    return v;
  }
  async function run(fn: () => Promise<void>) {
    setBusy(true);
    setMessage("");
    try {
      await fn();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    load()
      .then((v) => {
        if (v.sites.length) {
          setEditorOpen(false);
        }
      })
      .catch((e) => setMessage(e.message));
    const q = new URLSearchParams(location.search);
    if (q.get("reset")) {
      setReset(q.get("reset")!);
      setMode("reset");
    }
    if (q.get("plan") && q.get("plan")! in SITE_PLANS)
      setPlan(q.get("plan") as SitePlan);
    try {
      const stored = sessionStorage.getItem("rollens_draft");
      if (stored) {
        const v = JSON.parse(stored);
        setData(
          normalizeDraft({
            ...v,
            services:
              typeof v.services === "string"
                ? v.services
                    .split(",")
                    .map((x: string) => x.trim())
                    .filter(Boolean)
                : v.services || [],
          }),
        );
        setDirty(true);
      }
    } catch {}
    setLoaded(true);
    if (q.get("payment") === "processing") {
      setMessage(
        "Confirming payment. Your reviewed draft publishes after Stripe verification.",
      );
      const timer = setInterval(
        () =>
          load()
            .then((v) => {
              if (v.user?.enabled) {
                setMessage(
                  "Payment verified. Your website is live—open it below.",
                );
                setEditorOpen(false);
                sessionStorage.removeItem("rollens_draft");
                clearInterval(timer);
              }
            })
            .catch(() => {}),
        3000,
      );
      const stop = setTimeout(() => clearInterval(timer), 90000);
      return () => {
        clearInterval(timer);
        clearTimeout(stop);
      };
    }
  }, []);
  useEffect(() => {
    if (loaded && editorOpen && !selected)
      sessionStorage.setItem("rollens_draft", JSON.stringify(data));
  }, [loaded, data, editorOpen, selected]);
  const current = state?.sites.find((s) => s.id === selected);
  const actual = SITE_PLANS[state?.user?.plan || "starter"];
  const locked = !!(current?.locked && state?.user?.plan && !actual.edits);
  const capacity = state?.user?.plan ? actual.sites : 1;
  function change(next: SiteDraft) {
    setData(next);
    setDirty(true);
    setApproved(false);
  }
  function edit(s: Site) {
    setSelected(s.id);
    setData(normalizeDraft(s.data));
    setDirty(false);
    setApproved(false);
    setEditorOpen(true);
    setTimeout(
      () =>
        document
          .getElementById("workspace-editor")
          ?.scrollIntoView({ behavior: "smooth" }),
      30,
    );
  }
  async function save() {
    if (!data.name.trim())
      throw new Error("Give your website a name before saving.");
    if (data.brief.trim().length < 10)
      throw new Error("Add a short introduction before saving.");
    const clean = {
      ...data,
      name: data.name.trim(),
      brief: data.brief.trim(),
      services: data.services.map((s) => s.trim()).filter(Boolean),
      gallery: data.gallery.map((s) => s.trim()).filter(Boolean),
    };
    const v = await api({ action: "save", id: selected, data: clean });
    setData(clean);
    setSelected(v.id);
    setDirty(false);
    setApproved(false);
    sessionStorage.removeItem("rollens_draft");
    await load();
    setMessage(
      current?.published && state?.user?.enabled
        ? "Changes saved to your live website."
        : "Draft saved. Review it, then choose your plan below.",
    );
  }
  return (
    <main className="landing customer-account">
      <header className="lp-nav">
        <a className="lp-brand" href="/">
          rollens<span className="lp-brand-tag">WEB DESIGN</span>
        </a>
        <nav>
          <a href="/#pricing">Plans</a>
          <a href="/terms">Terms & privacy</a>
        </nav>
        <div>
          {state?.user ? (
            <>
              <span className="ca-email">{state.user.email}</span>
              <button
                className="lp-small-cta"
                disabled={busy}
                onClick={() =>
                  run(async () => {
                    await api({ action: "logout" });
                    await load();
                    setPassword("");
                  })
                }
              >
                Sign out
              </button>
            </>
          ) : (
            <a href="/">← Back home</a>
          )}
        </div>
      </header>
      <div className="ca-wrap">
        <div className="ca-heading">
          <span className="lp-eyebrow">YOUR CORNER OF THE INTERNET</span>
          <h1>
            {state?.user ? "Let’s make it yours." : "A good idea starts here."}
          </h1>
          <p>
            {state?.user
              ? "Your websites, your drafts, your next chapter."
              : "Save your website draft and keep making it your own."}
          </p>
        </div>
        {message && (
          <div className="ca-message" role="status" aria-live="polite">
            {message}
          </div>
        )}
        {!state ? (
          <p>Loading your workspace…</p>
        ) : !state.user ? (
          <section className="ca-auth">
            <div>
              <span className="lp-eyebrow">NO CARD TO START</span>
              <h2>
                {mode === "login"
                  ? "Good to see you."
                  : mode === "forgot"
                    ? "Let’s get you back in."
                    : mode === "reset"
                      ? "A fresh password."
                      : "Make yourself at home."}
              </h2>
              <p>
                Save your draft, edit the details and decide when it’s ready for
                the world.
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  run(async () => {
                    if (mode === "forgot") {
                      await api({ action: "forgot", email });
                      setMessage(
                        "If an account exists, a reset link has been sent. Check your inbox.",
                      );
                      return;
                    }
                    if (mode === "reset") {
                      await api({ action: "reset", token: reset, password });
                      setReset("");
                      setPassword("");
                      setMode("login");
                      history.replaceState(null, "", "/account");
                      setMessage("Password updated. Sign in to continue.");
                      return;
                    }
                    await api({ action: mode, email, password });
                    setPassword("");
                    await load();
                  });
                }}
              >
                {mode !== "reset" && (
                  <label>
                    Email
                    <input
                      type="email"
                      required
                      autoComplete="email"
                      value={email}
                      maxLength={180}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </label>
                )}
                {mode !== "forgot" && (
                  <label>
                    Password · 12 characters or more
                    <input
                      type="password"
                      required
                      minLength={12}
                      maxLength={128}
                      autoComplete={
                        mode === "login" ? "current-password" : "new-password"
                      }
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </label>
                )}
                <button disabled={busy} className="lp-create">
                  {busy
                    ? "Working…"
                    : mode === "signup"
                      ? "Create my account"
                      : mode === "login"
                        ? "Log in"
                        : mode === "reset"
                          ? "Update password"
                          : "Send reset link"}
                  <span>↗</span>
                </button>
              </form>
              <div className="ca-auth-links">
                <button
                  onClick={() => setMode(mode === "login" ? "signup" : "login")}
                >
                  {mode === "login"
                    ? "Create an account"
                    : "Already have an account? Log in"}
                </button>
                <button onClick={() => setMode("forgot")}>
                  Forgot password?
                </button>
              </div>
              <small>
                Your account stores your draft and contact details. Stripe
                handles payments when you choose to publish. See{" "}
                <a href="/terms">privacy & terms</a>.
              </small>
            </div>
            <aside>
              <span>IDEA → DRAFT → YOUR WEBSITE</span>
              <h2>
                Your words.
                <br />
                Your work.
                <br />
                <em>Your space.</em>
              </h2>
              <p>Draft freely. Publish when it feels right.</p>
              <strong>From A$19.99/month</strong>
            </aside>
          </section>
        ) : (
          <>
            <section className="ca-overview">
              <div>
                <h2>Your websites</h2>
                <p>
                  {state.user.enabled
                    ? `${actual.name} · active`
                    : state.user.hasSubscription
                      ? "Subscription needs attention"
                      : "Free draft workspace"}{" "}
                  <span>·</span> {state.sites.length} / {capacity} sites
                </p>
              </div>
              <div>
                {state.user.hasSubscription && (
                  <button
                    disabled={busy}
                    onClick={() =>
                      run(async () => {
                        const v = await api({ action: "portal" });
                        location.assign(v.url);
                      })
                    }
                  >
                    Billing, upgrades & cancellation ↗
                  </button>
                )}
                <button
                  disabled={state.sites.length >= capacity || busy}
                  onClick={() => {
                    setSelected(undefined);
                    setData(emptyDraft);
                    setDirty(false);
                    setApproved(false);
                    setEditorOpen(true);
                  }}
                >
                  + New website
                </button>
              </div>
            </section>
            <div className="ca-sites">
              {state.sites.length === 0 ? (
                <div className="ca-empty">
                  <span>✦</span>
                  <h3>Your first website belongs here.</h3>
                  <p>
                    Make a draft in the editor, then save it to your workspace.
                  </p>
                </div>
              ) : (
                state.sites.map((s) => (
                  <article key={s.id}>
                    <div className={`ca-site-thumb theme-${s.data.theme}`}>
                      <span>
                        {s.data.personal
                          ? "PERSONAL WEBSITE"
                          : "BUSINESS WEBSITE"}
                      </span>
                      <strong>{s.data.name}</strong>
                      <small>
                        {s.locked && !actual.edits
                          ? "Published design · editing locked"
                          : s.published && state.user?.enabled
                            ? "Live on the web"
                            : "A work in progress"}
                      </small>
                    </div>
                    <div className="ca-site-meta">
                      <h3>{s.data.name}</h3>
                      <p>/sites/{s.slug}</p>
                      <div>
                        <button onClick={() => edit(s)}>
                          {s.locked && !actual.edits
                            ? "View design"
                            : "Open editor"}{" "}
                          ↗
                        </button>
                        {state.user?.enabled && (
                          <button
                            disabled={busy}
                            onClick={() =>
                              run(async () => {
                                if (
                                  !s.published &&
                                  !actual.edits &&
                                  !window.confirm(
                                    "Publishing will lock this site’s content. Have you finished editing your draft?",
                                  )
                                )
                                  return;
                                await api({
                                  action: "publish",
                                  id: s.id,
                                  published: !s.published,
                                });
                                await load();
                                setMessage(
                                  s.published
                                    ? "Website unpublished. Its content lock is unchanged."
                                    : "Your website is live.",
                                );
                              })
                            }
                          >
                            {s.published ? "Unpublish" : "Publish"}
                          </button>
                        )}
                        {s.published && state.user?.enabled && (
                          <a
                            href={`/sites/${s.slug}`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            Visit site ↗
                          </a>
                        )}
                      </div>
                      <DomainSettings siteId={s.id} />
                    </div>
                  </article>
                ))
              )}
            </div>
            {editorOpen && (
              <section id="workspace-editor" className="ca-editor">
                <div className="lp-section-heading">
                  <div>
                    <span className="lp-eyebrow">
                      {locked
                        ? "YOUR PUBLISHED DESIGN"
                        : "YOUR DRAFT WORKSPACE"}
                    </span>
                    <h2>
                      {locked
                        ? "Made. Published. Yours."
                        : "A few good finishing touches."}
                    </h2>
                  </div>
                  <p>
                    {locked
                      ? "Starter and Plus lock after first publication. Upgrade to Pro in Billing for ongoing edits."
                      : "Click text or photos in the preview to edit. Save your draft before publishing. Pro edits to published sites go live when saved."}
                  </p>
                </div>
                <WebsiteEditor
                  value={data}
                  onChange={change}
                  locked={locked}
                  advanced={!state.user.plan || actual.seo}
                  saving={busy}
                  onSave={() => run(save)}
                />
                <div className="ca-save-note">
                  {dirty
                    ? "You have unsaved changes. Save your draft before subscribing."
                    : selected
                      ? "Your draft is saved."
                      : "Add your details, then save your first draft."}
                  {state.user.plan &&
                    actual.edits &&
                    current?.published &&
                    " Saving updates your live website immediately."}
                </div>
              </section>
            )}
            {!state.user.hasSubscription && (
              <section className="ca-subscribe" id="subscribe">
                <div className="lp-section-heading">
                  <div>
                    <span className="lp-eyebrow">READY FOR THE WORLD?</span>
                    <h2>Choose its next chapter.</h2>
                  </div>
                  <p>
                    One website on Starter or Plus.
                    <br />
                    Multiple websites and ongoing edits on Pro.
                  </p>
                </div>
                <label className="ca-approval">
                  <input
                    type="checkbox"
                    checked={approved}
                    disabled={dirty || !selected}
                    onChange={(e) => setApproved(e.target.checked)}
                  />
                  <span>
                    I have reviewed and saved my draft. I understand it
                    publishes after verified payment, and{" "}
                    <strong>
                      Starter and Plus lock editing after first publication
                    </strong>
                    . Pro includes ongoing editing. I’ve read the{" "}
                    <a href="/terms">service terms</a>.
                  </span>
                </label>
                <div className="lp-plans">
                  {(Object.keys(SITE_PLANS) as SitePlan[]).map((key) => {
                    const p = SITE_PLANS[key];
                    return (
                      <article
                        className={`lp-plan ${key === plan ? "recommended" : ""}`}
                        key={key}
                      >
                        <div className="lp-plan-name">{p.name}</div>
                        <div className="lp-plan-price">
                          A${p.cents / 100}
                          <small>/ month</small>
                        </div>
                        <ul>
                          {planFeatures(key).map((f) => (
                            <li key={f}>
                              <span>✓</span>
                              {f}
                            </li>
                          ))}
                        </ul>
                        <button
                          disabled={
                            busy ||
                            dirty ||
                            !selected ||
                            !approved ||
                            !state.billingReady
                          }
                          onClick={() => {
                            setPlan(key);
                            run(async () => {
                              const v = await api({
                                action: "checkout",
                                plan: key,
                                draftApproved: approved,
                              });
                              location.assign(v.url);
                            });
                          }}
                        >
                          {state.billingReady
                            ? `Publish with ${p.name}`
                            : "Checkout temporarily unavailable"}
                          <span>↗</span>
                        </button>
                      </article>
                    );
                  })}
                </div>
                <p className="ca-billing-note">
                  Prices in AUD, billed monthly until cancelled. Cancel future
                  renewal through Billing. Hosting continues through your paid
                  period. No plan-based image or service-content quotas on Plus
                  or Pro; normal technical safeguards apply. Starter is
                  text-only. Sites include a Rollens address and support your
                  own domain. Domain registration and ecommerce are not
                  included.
                </p>
              </section>
            )}
          </>
        )}
      </div>
      <footer className="lp-footer">
        <a href="/" className="lp-brand">
          rollens<span className="lp-brand-tag">WEB DESIGN</span>
        </a>
        <p>A little idea. A place of your own.</p>
        <div>
          <a href="/terms">Terms & privacy</a>
          <a href="mailto:rollenswebdesign@gmail.com">Get in touch ↗</a>
        </div>
      </footer>
    </main>
  );
}
