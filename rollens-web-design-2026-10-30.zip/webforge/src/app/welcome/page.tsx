import type { Metadata } from "next";
import Homepage from "./homepage";
export const metadata: Metadata = {
  title: "Rollens Web Design — A little input. A proper website.",
  description:
    "Create a website for your business or yourself. Create and edit a free draft, then publish with self-service monthly plans from A$19.99.",
};
export default function Page() {
  return <Homepage />;
}
