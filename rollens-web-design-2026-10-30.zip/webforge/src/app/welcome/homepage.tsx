"use client";
import { useRef, useState } from "react";
import WebsiteEditor, {
  emptyDraft,
  type SiteDraft,
} from "@/components/website-editor";
import { SITE_PLANS, planFeatures, type SitePlan } from "@/lib/site-plans";
import "./landing.css";
const ideas = [
  {
    label: "A local business",
    icon: "↗",
    prompt:
      "A welcoming website for my local Melbourne service business. I want visitors to explore what we do and get in touch.",
  },
  {
    label: "My creative portfolio",
    icon: "◈",
    prompt:
      "A personal portfolio to introduce my photography and creative work, showcase my projects and help people contact me.",
    personal: true,
  },
  {
    label: "Something green",
    icon: "✳",
    prompt:
      "A thoughtful website for my gardening business, with garden maintenance, lawn mowing and hedge trimming services.",
  },
  {
    label: "My next big thing",
    icon: "✦",
    prompt:
      "A clean, confident personal website to introduce my next project and share what I’m working on.",
    personal: true,
  },
];
export default function Homepage() {
  const [prompt, setPrompt] = useState("");
  const [personal, setPersonal] = useState(false);
  const [draft, setDraft] = useState<SiteDraft>(emptyDraft);
  const [started, setStarted] = useState(false);
  const [message, setMessage] = useState("");
  const editor = useRef<HTMLElement>(null);
  const brief = useRef<HTMLTextAreaElement>(null);
  function create() {
    if (prompt.trim().length < 10) {
      setMessage("Tell us a little more about the website you have in mind.");
      brief.current?.focus();
      return;
    }
    setMessage("");
    setDraft((d) => ({ ...d, brief: prompt.trim(), personal }));
    setStarted(true);
    requestAnimationFrame(() =>
      editor.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  }
  function account(plan: SitePlan = "plus") {
    sessionStorage.setItem(
      "rollens_draft",
      JSON.stringify({
        ...draft,
        brief: draft.brief || prompt,
        personal: started ? draft.personal : personal,
      }),
    );
    location.assign(`/account?plan=${plan}`);
  }
  function tryIdea(i: number) {
    setPrompt(ideas[i].prompt);
    setPersonal(!!ideas[i].personal);
    brief.current?.focus();
  }
  return (
    <main className="landing">
      <header className="lp-nav">
        <a className="lp-brand" href="/" aria-label="Rollens home">
          <span className="lp-symbol">
            r<span>↗</span>
          </span>
          rollens<span className="lp-brand-tag">WEB DESIGN</span>
        </a>
        <nav>
          <a href="#how">How it works</a>
          <a href="#examples">Explore</a>
          <a href="#pricing">Pricing</a>
        </nav>
        <div>
          <a className="lp-login" href="/account">
            Log in
          </a>
          <button
            className="lp-small-cta"
            onClick={() => brief.current?.focus()}
          >
            Start creating ↗
          </button>
        </div>
      </header>
      <section className="lp-hero">
        <div className="lp-release">
          <span /> A LITTLE IDEA CAN GO A LONG WAY <span>↗</span>
        </div>
        <h1>
          Big idea?
          <br />
          Give it a <span>website.</span>
        </h1>
        <p>
          For your business, your work, or whatever’s next.
          <br />
          Start with a few words. Make it yours. Put it out there.
        </p>
        <div className="lp-prompt">
          <label htmlFor="website-idea" className="lp-sr">
            Describe your website
          </label>
          <textarea
            id="website-idea"
            ref={brief}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") create();
            }}
            maxLength={2000}
            placeholder="A website for my business that feels like…"
          />
          <div className="lp-prompt-bottom">
            <div className="lp-type">
              <button
                aria-pressed={!personal}
                onClick={() => setPersonal(false)}
              >
                Business
              </button>
              <button aria-pressed={personal} onClick={() => setPersonal(true)}>
                Personal
              </button>
            </div>
            <button className="lp-create" onClick={create}>
              Create my draft <span>↑</span>
            </button>
          </div>
        </div>
        <div role="status" className="lp-prompt-message">
          {message}
        </div>
        <div className="lp-ideas">
          <span>NEED A STARTING POINT?</span>
          <div>
            {ideas.map((idea, i) => (
              <button key={idea.label} onClick={() => tryIdea(i)}>
                <span>{idea.icon}</span>
                {idea.label}
              </button>
            ))}
          </div>
        </div>
        <div className="lp-under-prompt">
          Explore your draft free <span>·</span> No card to start <span>·</span>{" "}
          Publish from A$19.99/mo
        </div>
        <div className="lp-orbit lp-orbit-one" aria-hidden="true">
          ✳
        </div>
        <div className="lp-orbit lp-orbit-two" aria-hidden="true">
          ↗
        </div>
      </section>
      <section className="lp-examples" id="examples">
        <div className="lp-section-heading">
          <div>
            <span className="lp-eyebrow">A SPACE FOR WHAT YOU DO</span>
            <h2>
              Small business.
              <br />
              Big first impression.
            </h2>
          </div>
          <p>
            A place to be found, a way to show your work,
            <br />
            and an easy next step for the people who need you.
          </p>
        </div>
        <div className="lp-example-grid">
          <button
            onClick={() => {
              tryIdea(2);
              setDraft({
                ...emptyDraft,
                name: "Fieldwork Gardens",
                brief: ideas[2].prompt,
                services: [
                  "Garden maintenance",
                  "Lawn mowing",
                  "Hedge trimming",
                ],
              });
              setStarted(true);
              requestAnimationFrame(() =>
                editor.current?.scrollIntoView({ behavior: "smooth" }),
              );
            }}
            className="lp-example"
          >
            <div className="lp-example-window">
              <i />
              <i />
              <i />
              <span>GARDEN & LOCAL SERVICES</span>
            </div>
            <div className="lp-mini lp-mini-green">
              <header>
                fieldwork<span>GARDENS & OUTDOOR SPACES</span>
              </header>
              <h3>
                A little wild.
                <br />A lot of care.
              </h3>
              <div className="lp-mini-plant">
                <span>✳</span>
              </div>
              <div className="lp-mini-link">Let’s grow something ↗</div>
              <footer>
                MAINTENANCE <span>PLANTING</span>
                <span>GARDEN CARE</span>
              </footer>
            </div>
            <div className="lp-example-caption">
              <strong>Made for your local business</strong>
              <span>Explore idea ↗</span>
            </div>
          </button>
          <button
            className="lp-example"
            onClick={() => {
              tryIdea(1);
              setDraft({
                ...emptyDraft,
                name: "Alex Morgan",
                brief: ideas[1].prompt,
                personal: true,
                services: ["Portraits", "Editorial work", "Creative projects"],
                theme: 1,
              });
              setStarted(true);
              requestAnimationFrame(() =>
                editor.current?.scrollIntoView({ behavior: "smooth" }),
              );
            }}
          >
            <div className="lp-example-window">
              <i />
              <i />
              <i />
              <span>PERSONAL & CREATIVE WORK</span>
            </div>
            <div className="lp-mini lp-mini-pink">
              <header>
                ALEX MORGAN<span>SELECTED WORK / 2026</span>
              </header>
              <h3>
                A different
                <br />
                <em>perspective.</em>
              </h3>
              <div className="lp-mini-poster">
                <b>Aa</b>
              </div>
              <div className="lp-mini-link">
                Meet the person behind the work ↗
              </div>
              <footer>
                PORTRAITS <span>EDITORIAL</span>
                <span>PROJECTS</span>
              </footer>
            </div>
            <div className="lp-example-caption">
              <strong>Made for your point of view</strong>
              <span>Explore idea ↗</span>
            </div>
          </button>
          <button
            className="lp-example"
            onClick={() => {
              tryIdea(0);
              setDraft({
                ...emptyDraft,
                name: "Good Form Studio",
                brief: ideas[0].prompt,
                services: ["Our services", "Our work", "Get in touch"],
                theme: 2,
              });
              setStarted(true);
              requestAnimationFrame(() =>
                editor.current?.scrollIntoView({ behavior: "smooth" }),
              );
            }}
          >
            <div className="lp-example-window">
              <i />
              <i />
              <i />
              <span>IDEAS & FRESH STARTS</span>
            </div>
            <div className="lp-mini lp-mini-blue">
              <header>
                GOOD FORM<span>INDEPENDENT STUDIO</span>
              </header>
              <h3>
                Good things.
                <br />
                Start here.
              </h3>
              <div className="lp-mini-checker" />
              <div className="lp-mini-link">Let’s make your next move ↗</div>
              <footer>
                YOUR IDEA <span>YOUR STORY</span>
                <span>YOUR SPACE</span>
              </footer>
            </div>
            <div className="lp-example-caption">
              <strong>Made for your next chapter</strong>
              <span>Explore idea ↗</span>
            </div>
          </button>
        </div>
        <p className="lp-concept-note">
          Illustrative concepts, ready for your own words and images. These
          aren’t customer testimonials.
        </p>
      </section>
      <section className="lp-how" id="how">
        <div className="lp-section-heading">
          <div>
            <span className="lp-eyebrow">FROM “ONE DAY” TO ONLINE</span>
            <h2>
              Not a designer?
              <br />
              You’re in the right place.
            </h2>
          </div>
          <p>
            No code. No blank canvas panic.
            <br />
            Just your idea and a few good decisions.
          </p>
        </div>
        <div className="lp-steps">
          {[
            [
              "01",
              "Describe it.",
              "Tell us what you do and the website you have in mind. We’ll start a draft with a curated design.",
            ],
            [
              "02",
              "Make it yours.",
              "Click the preview to change your words. Choose a look, add photos and get every detail right.",
            ],
            [
              "03",
              "Put it out there.",
              "Review your finished draft, choose your plan and subscribe securely. Your site goes live after payment verification.",
            ],
          ].map(([n, t, p]) => (
            <article key={n}>
              <span>{n}</span>
              <h3>{t}</h3>
              <p>{p}</p>
            </article>
          ))}
        </div>
      </section>
      {started && (
        <section className="lp-editor-section" id="creator" ref={editor}>
          <div className="lp-section-heading">
            <div>
              <span className="lp-eyebrow">YOUR IDEA, TAKING SHAPE</span>
              <h2>
                A draft you can
                <br />
                make your own.
              </h2>
            </div>
            <p>
              Click the preview to select text or photos.
              <br />
              Nothing here is public until you choose to publish.
            </p>
          </div>
          <WebsiteEditor
            value={draft}
            onChange={setDraft}
            onSave={() => account()}
            onRequireAccount={() => account()}
          />
          <div className="lp-editor-next">
            <span>
              Happy with the direction? Save your draft to your free account.
            </span>
            <button className="lp-create" onClick={() => account()}>
              Save & continue <span>↗</span>
            </button>
          </div>
        </section>
      )}
      <section className="lp-pricing" id="pricing">
        <div className="lp-pricing-heading">
          <span className="lp-eyebrow">
            ONE GOOD WEBSITE. A SIMPLE MONTHLY PLAN.
          </span>
          <h2>
            Small price.
            <br />
            <span>Real possibilities.</span>
          </h2>
          <p>
            Build and refine your draft for free. Pay when you’re ready to
            publish.
            <br />
            Starter and Plus lock after publication. Pro keeps the editing tools
            open.
          </p>
        </div>
        <div className="lp-plans">
          {(Object.keys(SITE_PLANS) as SitePlan[]).map((key) => {
            const p = SITE_PLANS[key];
            return (
              <article
                className={`lp-plan ${key === "plus" ? "recommended" : ""}`}
                key={key}
              >
                {key === "plus" && (
                  <div className="lp-plan-ribbon">
                    ONE SITE. EVERYTHING IT NEEDS.
                  </div>
                )}
                <div className="lp-plan-name">
                  {p.name}
                  <span>
                    {key === "starter"
                      ? "A simple start"
                      : key === "plus"
                        ? "Your complete website"
                        : "Room to keep building"}
                  </span>
                </div>
                <div className="lp-plan-price">
                  A${p.cents / 100}
                  <small>/ month</small>
                </div>
                <p>
                  {key === "starter"
                    ? "A focused, text-first home for your business or yourself."
                    : key === "plus"
                      ? "A complete site, with all the images and service content you need."
                      : "All Plus features, multiple websites and the freedom to keep editing."}
                </p>
                <button onClick={() => account(key)}>
                  Start with {p.name} <span>↗</span>
                </button>
                <ul>
                  {planFeatures(key).map((f) => (
                    <li key={f}>
                      <span>✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
        <div className="lp-pricing-note">
          <strong>
            No setup fee. No generation credits. Monthly billing in AUD.
          </strong>
          <p>
            Starter and Plus include editing before first publication only;
            unpublishing does not unlock edits. Pro includes ongoing editing.
            Uploaded files have a 10 MB per-file limit; normal technical and
            security limits apply across all plans. Sites include a Rollens
            address and support your own domain. Domain registration and
            ecommerce are not included.
          </p>
          <a href="/terms">Service terms & privacy ↗</a>
        </div>
      </section>
      <section className="lp-faq">
        <h2>A few good questions.</h2>
        <div>
          {[
            [
              "Can I change the website after it’s generated?",
              "Yes. The draft editor lets you click and change text, add services, choose a design and arrange photos. Starter and Plus lock editing after first publication. Pro allows ongoing edits.",
            ],
            [
              "Are there image credits or allowances on Plus?",
              "No. Plus and Pro have no plan-based image or service-content quota. Upload photos or use your own image links. A 10 MB per-file upload limit and normal technical safeguards apply.",
            ],
            [
              "When does the website go live?",
              "When your reviewed draft is saved and your subscription payment is verified. Nothing publishes just because you generated a preview.",
            ],
            [
              "Is this an AI app builder?",
              "This is a focused website creator using curated designs and your content. It doesn’t currently use a language model to generate custom apps or rewrite your copy.",
            ],
            [
              "Can I cancel or change my plan?",
              "You can manage billing and cancel future renewal from your account. Hosting continues through the paid period. Pro is the plan for multiple sites and ongoing editing.",
            ],
            [
              "Can I use my own domain?",
              "Yes. All paid plans support domains you own, alongside your Rollens website address. Open Custom domains in your account, add the DNS records shown and verify ownership. HTTPS is automatic once your paid site is published. Registration and renewal stay with your domain provider.",
            ],
          ].map(([q, a]) => (
            <details key={q}>
              <summary>
                {q}
                <span>+</span>
              </summary>
              <p>{a}</p>
            </details>
          ))}
        </div>
      </section>
      <section className="lp-last">
        <span className="lp-eyebrow">YOUR NEXT CHAPTER HAS AN ADDRESS</span>
        <h2>
          Let’s make it
          <br />
          <em>yours.</em>
        </h2>
        <button
          className="lp-create"
          onClick={() => {
            window.scrollTo({ top: 0, behavior: "smooth" });
            brief.current?.focus();
          }}
        >
          Create my website <span>↗</span>
        </button>
      </section>
      <footer className="lp-footer">
        <a href="/" className="lp-brand">
          rollens<span className="lp-brand-tag">WEB DESIGN</span>
        </a>
        <p>For your business. For your work. For what’s next.</p>
        <div>
          <a href="/account">My account</a>
          <a href="/terms">Terms & privacy</a>
          <a href="mailto:rollenswebdesign@gmail.com">Get in touch ↗</a>
        </div>
        <small>
          © {new Date().getFullYear()} Rollens Web Design · Melbourne, Australia
        </small>
      </footer>
    </main>
  );
}
