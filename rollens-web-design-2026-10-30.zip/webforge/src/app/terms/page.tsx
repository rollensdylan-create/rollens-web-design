import type { Metadata } from "next";
import "../welcome/home.css";
export const metadata: Metadata = {
  title: "Service terms & privacy · Rollens Web Design",
};
export default function Page() {
  return (
    <main className="rw">
      <header className="rw-nav">
        <a className="rw-brand" href="/">
          rollens<span className="rw-brand-small">WEB DESIGN</span>
        </a>
        <a href="/account">My account ↗</a>
      </header>
      <article
        style={{ maxWidth: 800, margin: "auto", padding: "60px 24px 90px" }}
      >
        <h1 style={{ fontSize: 48 }}>Service terms & privacy</h1>
        <p>Last updated: 28 October 2026</p>
        <section style={{ marginTop: 35 }}>
          <h2 style={{ fontSize: 27 }}>The service</h2>
          <p>
            Rollens Web Design provides self-service brochure and personal
            websites using curated layouts. Plans include hosting at a
            rollenswebdesign.space/sites address and HTTPS. All plans allow
            editing before first publication; only Pro includes ongoing edits.
            Starter and Plus content locks on first publication, even if you
            later unpublish. Starter includes one website, three service entries
            and no gallery; Plus includes one website, custom search metadata,
            optional footer credit and no plan-based image or service-entry
            quota; Pro includes ten websites and all Plus features. Technical
            upload and request-size limits apply; each photo upload is limited
            to 10 MB. All paid plans can connect domains you own, with automatic
            HTTPS after DNS ownership verification and publication. Domain
            registration, online stores, custom apps and AI generation are not
            included in this release.
          </p>
        </section>
        <section style={{ marginTop: 30 }}>
          <h2 style={{ fontSize: 27 }}>Billing & cancellation</h2>
          <p>
            Starter costs A$19.99/month, Plus A$33/month and Pro A$99/month. The
            total is shown in Stripe Checkout before you pay. Subscriptions
            renew monthly until cancelled. Cancel through Billing in your
            account to stop future renewal; publication remains available
            through the paid period. When the subscription ends, or payment is
            not successfully maintained, sites become unavailable to visitors.
            Custom-domain hosting also stops when your paid hosting ends. Domain
            registration and renewal remain your responsibility with your
            registrar. Drafts remain in your account. The exact draft you
            approve before Checkout publishes automatically after payment
            verification. Plan upgrades are available through Billing; Stripe
            displays any immediate prorated charge before you confirm. No card
            details are stored by Rollens.
          </p>
        </section>
        <section style={{ marginTop: 30 }}>
          <h2 style={{ fontSize: 27 }}>Your content</h2>
          <p>
            You are responsible for the accuracy of your website and for
            permission to publish its text, contact information and images. Do
            not publish unlawful, deceptive or infringing content, or private
            information without permission. Photos can be uploaded or linked
            using HTTPS URLs. Uploaded photos have unlisted public image links,
            including while your website is a draft; do not upload confidential
            images. External images remain dependent on their hosts. Pro
            published site edits take effect immediately. Keep your own copy of
            important content. Contact us if you need help with a billing issue,
            refund request, data export or account deletion.
          </p>
        </section>
        <section style={{ marginTop: 30 }}>
          <h2 style={{ fontSize: 27 }}>Privacy</h2>
          <p>
            We store your account email, a protected password hash, session
            information, website content and Stripe customer/subscription
            identifiers, connected hostnames and DNS verification status to
            provide your account and hosting. Saved unpublished text is visible
            to you and service operators; uploaded image URLs are publicly
            accessible to anyone who has the link. Published text, images and
            contact details are public. Stripe handles payment information.
            Resend delivers password reset emails when you request them.
            External gallery hosts receive visitors’ image requests. We use
            request counts to limit abuse and maintain operational backups. We
            do not add account holders to unsolicited outreach campaigns.
          </p>
        </section>
        <section style={{ marginTop: 30 }}>
          <h2 style={{ fontSize: 27 }}>Contact</h2>
          <p>
            Questions, content reports and privacy requests:{" "}
            <a
              style={{ textDecoration: "underline" }}
              href="mailto:rollenswebdesign@gmail.com"
            >
              rollenswebdesign@gmail.com
            </a>
            .
          </p>
          <p style={{ marginTop: 15 }}>
            These service descriptions do not exclude rights you have under
            applicable consumer law.
          </p>
        </section>
      </article>
    </main>
  );
}
