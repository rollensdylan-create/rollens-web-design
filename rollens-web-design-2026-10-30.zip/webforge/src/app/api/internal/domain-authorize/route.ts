import { domainSite } from "@/lib/custom-domains";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  if (!/^127\.0\.0\.1(?::\d+)?$/.test(request.headers.get("host") || ""))
    return new Response("Forbidden", { status: 403 });
  const domain = new URL(request.url).searchParams.get("domain") || "";
  let allowed;
  try {
    allowed = await domainSite(domain);
  } catch {
    return new Response("DNS verification temporarily unavailable", {
      status: 503,
      headers: { "Cache-Control": "no-store" },
    });
  }
  return new Response(allowed ? "Allowed" : "Domain not active", {
    status: allowed ? 200 : 403,
    headers: { "Cache-Control": "no-store" },
  });
}
