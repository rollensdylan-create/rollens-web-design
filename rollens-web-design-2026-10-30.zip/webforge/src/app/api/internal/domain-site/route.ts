import { domainSite } from "@/lib/custom-domains";
import { renderCustomerSite } from "@/lib/customer-site";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  // Only the custom-host Caddy route sets this header and replaces Host with loopback.
  if (!/^127\.0\.0\.1(?::\d+)?$/.test(request.headers.get("host") || ""))
    return new Response("Not found", { status: 404 });
  const domain = request.headers.get("x-rollens-domain") || "";
  let data;
  try {
    data = await domainSite(domain);
  } catch {
    return new Response(
      "Domain verification is temporarily unavailable. Please try again shortly.",
      {
        status: 503,
        headers: {
          "Retry-After": "60",
          "Cache-Control": "no-store, no-transform",
        },
      },
    );
  }
  if (!data)
    return new Response("This website is not currently published.", {
      status: 404,
      headers: {
        "Cache-Control": "no-store, no-transform",
        "X-Robots-Tag": "noindex",
      },
    });
  return new Response(renderCustomerSite(data), {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "Content-Security-Policy":
        "default-src 'none'; style-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
    },
  });
}
