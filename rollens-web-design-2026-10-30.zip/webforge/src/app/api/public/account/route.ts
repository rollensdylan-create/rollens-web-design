import { z } from "zod";
import {
  authenticate,
  sessionFor,
  userFor,
  logout,
  sitesFor,
  saveSite,
  publish,
  createCheckout,
  portal,
  limit,
  billingReady,
  requestReset,
  resetPassword,
} from "@/lib/selfserve";
import { renderCustomerSite } from "@/lib/customer-site";
import { SITE_PLANS } from "@/lib/site-plans";
import { automationConfig } from "@/lib/automation-config";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store, no-transform" };
export async function GET(request: Request) {
  const u = userFor(request);
  const preview = new URL(request.url).searchParams.get("preview");
  if (preview) {
    const site = u ? sitesFor(u.id).find((s) => s.id === preview) : null;
    if (!site)
      return new Response("Website not found", { status: 404, headers });
    return new Response(renderCustomerSite(site.data), {
      headers: {
        ...headers,
        "Content-Type": "text/html; charset=utf-8",
        "Content-Security-Policy":
          "default-src 'none'; style-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'",
        "Referrer-Policy": "no-referrer",
      },
    });
  }
  return Response.json(
    {
      user: u
        ? {
            email: u.email,
            plan: u.plan,
            enabled: !!u.enabled,
            hasSubscription: !!u.subscription,
          }
        : null,
      sites: u ? sitesFor(u.id) : [],
      billingReady: billingReady(),
      plans: SITE_PLANS,
    },
    { headers },
  );
}
export async function POST(request: Request) {
  try {
    if (request.headers.get("origin") !== automationConfig().publicBase)
      return Response.json(
        { error: "Invalid origin" },
        { status: 403, headers },
      );
    if (Number(request.headers.get("content-length") || 0) > 1000000)
      return new Response("Request too large", { status: 413 });
    const text = await request.text();
    if (text.length > 1000000)
      return new Response("Request too large", { status: 413 });
    const input = JSON.parse(text);
    const ip =
      request.headers.get("cf-connecting-ip") ||
      request.headers.get("x-forwarded-for")?.split(",")[0] ||
      "unknown";
    const action = z
      .enum([
        "signup",
        "login",
        "logout",
        "save",
        "publish",
        "checkout",
        "portal",
        "forgot",
        "reset",
      ])
      .parse(input.action);
    limit(`site-ip:${ip}`, 100, 3600);
    if (action === "signup" || action === "login") {
      limit(`auth:${ip}`, 15, 900);
      const id = authenticate(input.email, input.password, action === "signup");
      const token = sessionFor(id);
      return Response.json(
        { ok: true },
        {
          headers: {
            ...headers,
            "Set-Cookie": `rollens_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=2592000`,
          },
        },
      );
    }
    if (action === "forgot") {
      limit(`reset:${ip}`, 3, 3600);
      await requestReset(z.email().parse(input.email));
      return Response.json({ ok: true }, { headers });
    }
    if (action === "reset") {
      limit(`reset-confirm:${ip}`, 10, 900);
      resetPassword(z.string().max(100).parse(input.token), input.password);
      return Response.json({ ok: true }, { headers });
    }
    if (action === "logout") {
      logout(request);
      return Response.json(
        { ok: true },
        {
          headers: {
            ...headers,
            "Set-Cookie":
              "rollens_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0",
          },
        },
      );
    }
    const u = userFor(request);
    if (!u)
      return Response.json(
        { error: "Sign in to continue." },
        { status: 401, headers },
      );
    limit(`site-user:${u.id}`, 100, 3600);
    if (action === "save")
      return Response.json(
        {
          id: saveSite(
            u,
            input.data,
            input.id ? z.uuid().parse(input.id) : undefined,
          ),
        },
        { headers },
      );
    if (action === "publish") {
      publish(u, z.uuid().parse(input.id), z.boolean().parse(input.published));
      return Response.json({ ok: true }, { headers });
    }
    if (action === "checkout") {
      if (input.draftApproved !== true)
        throw new Error(
          "Please review and approve your draft and publishing conditions before subscribing.",
        );
      limit(`checkout:${u.id}`, 10, 3600);
      if (sitesFor(u.id).length === 0)
        throw new Error("Save your first website before checkout.");
      return Response.json(
        {
          url: await createCheckout(
            u,
            z.enum(["starter", "plus", "pro"]).parse(input.plan),
          ),
        },
        { headers },
      );
    }
    if (action === "portal")
      return Response.json({ url: await portal(u) }, { headers });
    return Response.json({ error: "Unknown action" }, { status: 400, headers });
  } catch (e) {
    return Response.json(
      {
        error:
          e instanceof z.ZodError
            ? "Please check your details. Passwords need at least 12 characters; names, descriptions and contact details must be valid."
            : e instanceof Error &&
                !/stripe|api key|SQLITE|database|permission/i.test(e.message)
              ? e.message
              : "This action is temporarily unavailable. Your saved website is safe; please try again shortly.",
      },
      { status: 400, headers },
    );
  }
}
