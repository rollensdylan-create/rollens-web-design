import { automationConfig } from "@/lib/automation-config";
import { checkout } from "@/lib/billing";
export async function POST(
  request: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  try {
    const origin = request.headers.get("origin");
    if (origin && new URL(origin).origin !== automationConfig().publicBase)
      return new Response("Invalid origin", { status: 403 });
    const { token } = await ctx.params;
    return Response.redirect(await checkout(token), 303);
  } catch {
    return new Response(
      "Checkout is unavailable. Please contact the sender to arrange your website.",
      { status: 503 },
    );
  }
}
