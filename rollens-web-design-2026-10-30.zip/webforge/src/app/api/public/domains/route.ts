import { z } from "zod";
import { userFor, limit } from "@/lib/selfserve";
import {
  addDomain,
  domainsFor,
  domainIpv4,
  removeDomain,
  verifyDomain,
} from "@/lib/custom-domains";
import { automationConfig } from "@/lib/automation-config";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store, no-transform" };
export async function GET(request: Request) {
  const user = userFor(request);
  if (!user)
    return Response.json(
      { error: "Sign in to manage domains." },
      { status: 401, headers },
    );
  try {
    const id = z.uuid().parse(new URL(request.url).searchParams.get("site"));
    return Response.json(
      { domains: domainsFor(user, id), ipv4: domainIpv4() },
      { headers },
    );
  } catch {
    return Response.json(
      { error: "Website not found." },
      { status: 404, headers },
    );
  }
}
export async function POST(request: Request) {
  if (request.headers.get("origin") !== automationConfig().publicBase)
    return Response.json({ error: "Invalid origin" }, { status: 403, headers });
  const user = userFor(request);
  if (!user)
    return Response.json(
      { error: "Sign in to manage domains." },
      { status: 401, headers },
    );
  try {
    limit(`domains:${user.id}`, 30, 600);
    const text = await request.text();
    if (text.length > 2000) throw new Error("Request too large.");
    const input = JSON.parse(text);
    const siteId = z.uuid().parse(input.site);
    if (input.action === "add")
      addDomain(user, siteId, z.string().max(250).parse(input.hostname));
    else if (input.action === "verify")
      await verifyDomain(user, z.uuid().parse(input.id));
    else if (input.action === "remove")
      removeDomain(user, z.uuid().parse(input.id));
    else throw new Error("Unknown domain action.");
    return Response.json(
      { domains: domainsFor(user, siteId), ipv4: domainIpv4() },
      { headers },
    );
  } catch (e) {
    return Response.json(
      {
        error:
          e instanceof z.ZodError
            ? "Enter a valid website and hostname."
            : e instanceof Error && !/SQLITE|database/i.test(e.message)
              ? e.message
              : "Domain setup is temporarily unavailable.",
      },
      { status: 400, headers },
    );
  }
}
