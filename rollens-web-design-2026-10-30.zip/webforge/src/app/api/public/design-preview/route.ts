import { SiteData, limit } from "@/lib/selfserve";
import { renderCustomerSite } from "@/lib/customer-site";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    const text = await request.text();
    if (text.length > 1000000)
      return new Response("Preview too large", { status: 413 });
    const ip = request.headers.get("cf-connecting-ip") || "local";
    limit(`design-preview:${ip}`, 120, 60);
    const data = SiteData.parse(JSON.parse(text));
    return new Response(renderCustomerSite(data, true), {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store, no-transform",
        "Content-Security-Policy":
          "default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'",
      },
    });
  } catch {
    return new Response("Complete your details to update the preview.", {
      status: 400,
    });
  }
}
