import { outreachByToken } from "@/lib/automation-store";
import { getMission } from "@/lib/db";
export async function GET(
  _r: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  const { token } = await ctx.params;
  const o = outreachByToken(token);
  const m = o ? getMission(o.missionId) : null;
  if (!o || !m) return Response.json({ ready: false }, { status: 404 });
  return Response.json(
    {
      ready:
        m.status === "COMPLETED" &&
        m.qa?.status === "PASSED" &&
        !!m.demo &&
        !!m.automation?.qualified,
      outreachId: o.id,
    },
    { headers: { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" } },
  );
}
