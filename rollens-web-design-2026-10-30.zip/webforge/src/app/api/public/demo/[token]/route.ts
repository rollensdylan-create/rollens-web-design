import { outreachByToken } from "@/lib/automation-store";
import { getMission } from "@/lib/db";
import { readArtifact } from "@/lib/artifacts";
export async function GET(
  _request: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  const { token } = await ctx.params;
  const o = outreachByToken(token);
  const m = o ? getMission(o.missionId) : null;
  if (!o || !m?.demo || m.status !== "COMPLETED" || m.qa?.status !== "PASSED")
    return new Response("Preview unavailable", { status: 404 });
  return new Response(await readArtifact(m.id, "build/index.html"), {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Security-Policy":
        "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:; form-action 'none'; base-uri 'none'",
      "X-Robots-Tag": "noindex, nofollow",
      "Referrer-Policy": "no-referrer",
    },
  });
}
