import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/lib/db";
import { ROOT } from "@/lib/config";
import { userFor, limit } from "@/lib/selfserve";
import { automationConfig } from "@/lib/automation-config";
export const runtime = "nodejs";
db.exec(
  "CREATE TABLE IF NOT EXISTS site_images(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,created INTEGER NOT NULL)",
);
export async function POST(request: Request) {
  try {
    if (request.headers.get("origin") !== automationConfig().publicBase)
      return new Response("Invalid origin", { status: 403 });
    const u = userFor(request);
    if (!u)
      return Response.json(
        {
          error:
            "Sign in to upload photos. You can also paste an HTTPS image URL in your draft.",
        },
        { status: 401 },
      );
    limit(`upload:${u.id}`, 60, 600);
    if (Number(request.headers.get("content-length") || 0) > 11000000)
      return Response.json(
        { error: "Choose an image smaller than 10 MB." },
        { status: 413 },
      );
    const reader = request.body?.getReader();
    if (!reader) return new Response("Missing image", { status: 400 });
    let size = 0;
    const chunks: Uint8Array[] = [];
    for (;;) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.byteLength;
      if (size > 11000000) {
        await reader.cancel();
        return new Response("Image too large", { status: 413 });
      }
      chunks.push(part.value);
    }
    const body = await new Response(Buffer.concat(chunks), {
      headers: { "Content-Type": request.headers.get("content-type") || "" },
    }).formData();
    const file = body.get("image");
    if (!(file instanceof File) || file.size > 10000000)
      return Response.json(
        { error: "Choose an image smaller than 10 MB." },
        { status: 400 },
      );
    const sharp = (await import("sharp")).default;
    const data = await sharp(Buffer.from(await file.arrayBuffer()), {
      limitInputPixels: 40000000,
    })
      .rotate()
      .resize({
        width: 2400,
        height: 2400,
        fit: "inside",
        withoutEnlargement: true,
      })
      .jpeg({ quality: 85 })
      .toBuffer();
    const id = randomUUID();
    await mkdir(path.join(ROOT, "customer-uploads"), { recursive: true });
    await writeFile(path.join(ROOT, "customer-uploads", id + ".jpg"), data, {
      mode: 0o600,
      flag: "wx",
    });
    db.prepare("INSERT INTO site_images VALUES(?,?,?)").run(
      id,
      u.id,
      Date.now(),
    );
    return Response.json(
      { url: `${automationConfig().publicBase}/api/public/site-image/${id}` },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json(
      {
        error:
          "That image could not be processed. Try a JPG, PNG or WebP file.",
      },
      { status: 400 },
    );
  }
}
