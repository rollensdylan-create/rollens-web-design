import { workerStatus } from "@/lib/db";
import { campaigns } from "@/lib/automation-store";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET() {
  const worker = workerStatus().online;
  const discovery = !campaigns().some((c) => c.enabled && !!c.lastError);
  return Response.json(
    { status: worker && discovery ? "ok" : "degraded", worker, discovery },
    {
      status: worker && discovery ? 200 : 503,
      headers: { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" },
    },
  );
}
