import { outreachByToken, suppress } from "@/lib/automation-store";
export async function GET(
  _request: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  const { token } = await ctx.params;
  if (!outreachByToken(token))
    return new Response("Not found", { status: 404 });
  return new Response(
    `<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unsubscribe · WebForge</title><body style="font:16px Arial;padding:40px;max-width:500px;margin:auto"><h1>Stop WebForge outreach</h1><p>Confirm below to stop further outreach to this address.</p><form method="post"><button style="padding:12px 20px" type="submit">Unsubscribe</button></form></body></html>`,
    {
      headers: {
        "Content-Type": "text/html",
        "X-Robots-Tag": "noindex",
        "Referrer-Policy": "no-referrer",
      },
    },
  );
}
export async function POST(
  _request: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  const { token } = await ctx.params;
  const o = outreachByToken(token);
  if (!o) return new Response("Not found", { status: 404 });
  suppress(o.recipient);
  return new Response(
    "You have been unsubscribed. No further WebForge outreach will be sent to this address.",
    { headers: { "Content-Type": "text/plain" } },
  );
}
