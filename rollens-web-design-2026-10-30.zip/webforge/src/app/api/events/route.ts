import { events, workerStatus } from "@/lib/db";
import { authorize } from "@/lib/security";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  if (!authorize(request)) return new Response("Forbidden", { status: 403 });
  const url = new URL(request.url);
  const id = url.searchParams.get("mission") || undefined;
  let after = Number(url.searchParams.get("after") || 0);
  let timer: ReturnType<typeof setInterval>;
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      const send = () => {
        try {
          const rows = events(id, after);
          if (rows.length) after = rows[rows.length - 1].id;
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ events: rows, worker: workerStatus() })}\n\n`,
            ),
          );
        } catch {
          clearInterval(timer);
        }
      };
      send();
      timer = setInterval(send, 1500);
      request.signal.addEventListener("abort", () => {
        clearInterval(timer);
        try {
          controller.close();
        } catch {}
      });
    },
    cancel() {
      clearInterval(timer);
    },
  });
  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
