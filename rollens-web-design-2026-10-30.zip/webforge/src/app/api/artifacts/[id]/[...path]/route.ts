import { readArtifact } from "@/lib/artifacts";
import { getMission } from "@/lib/db";
import { authorize } from "@/lib/security";
export const runtime = "nodejs";
export async function GET(
  request: Request,
  ctx: { params: Promise<{ id: string; path: string[] }> },
) {
  if (!authorize(request)) return new Response("Forbidden", { status: 403 });
  const { id, path } = await ctx.params;
  if (!getMission(id)) return new Response("Not found", { status: 404 });
  const name = path.join("/");
  if (
    !/^(input|scan|screenshots|audit|strategy|build|qa|events|outreach)\/[a-zA-Z0-9_.-]+$/.test(
      name,
    )
  )
    return new Response("Invalid artifact", { status: 400 });
  try {
    const bytes = await readArtifact(id, name);
    const type = name.endsWith(".png")
      ? "image/png"
      : name.endsWith(".html")
        ? "text/html; charset=utf-8"
        : name.endsWith(".json")
          ? "application/json"
          : "text/plain";
    return new Response(bytes, {
      headers: {
        "Content-Type": type,
        "Content-Security-Policy":
          "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:; form-action 'none'; base-uri 'none'",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
