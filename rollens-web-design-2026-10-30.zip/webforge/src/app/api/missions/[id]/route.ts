import { NextResponse } from "next/server";
import { z } from "zod";
import { getMission, events, control } from "@/lib/db";
import { listArtifacts } from "@/lib/artifacts";
import { authorize } from "@/lib/security";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, ctx: Context) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  const { id } = await ctx.params;
  const m = getMission(id);
  if (!m) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    ...m,
    events: events(id),
    artifacts: await listArtifacts(id),
  });
}
export async function POST(request: Request, ctx: Context) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    const { id } = await ctx.params;
    const { action } = z
      .object({
        action: z.enum(["pause", "resume", "cancel", "retry", "qa", "rebuild"]),
      })
      .parse(await request.json());
    return NextResponse.json(control(id, action));
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Invalid action" },
      { status: 400 },
    );
  }
}
