import { NextResponse } from "next/server";
import { z } from "zod";
import { createMission, listMissions, workerStatus } from "@/lib/db";
import { authorize, validateUrl } from "@/lib/security";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const schema = z.object({
  url: z.string().max(2000),
  name: z.string().trim().min(1).max(100),
  mode: z.enum(["live", "fixture"]).default("live"),
});
export async function GET(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  return NextResponse.json({
    missions: listMissions(),
    worker: workerStatus(),
  });
}
export async function POST(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    const data = schema.parse(await request.json());
    if (data.mode === "live") await validateUrl(data.url);
    if (
      listMissions().filter((m) => ["QUEUED", "RUNNING"].includes(m.status))
        .length >= 20
    )
      return NextResponse.json(
        { error: "Queue limit reached (20)" },
        { status: 429 },
      );
    return NextResponse.json(
      createMission(
        data.mode === "fixture" ? "https://northline.example.test" : data.url,
        data.name,
        data.mode,
      ),
      { status: 201 },
    );
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Invalid mission" },
      { status: 400 },
    );
  }
}
