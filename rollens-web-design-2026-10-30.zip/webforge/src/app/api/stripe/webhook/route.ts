import { stripeClient, applyStripeEvent } from "@/lib/billing";
import { automationConfig } from "@/lib/automation-config";
import { applySiteBillingEvent } from "@/lib/selfserve";
export const runtime = "nodejs";
export async function POST(request: Request) {
  const secret = automationConfig().stripeWebhook;
  if (!secret) return new Response("Webhook not configured", { status: 503 });
  let event;
  try {
    const raw = await request.text();
    event = stripeClient().webhooks.constructEvent(
      raw,
      request.headers.get("stripe-signature") || "",
      secret,
    );
  } catch {
    return new Response("Invalid webhook signature", { status: 400 });
  }
  try {
    await applySiteBillingEvent(event);
    applyStripeEvent(event);
    return Response.json({ received: true });
  } catch {
    return new Response("Webhook processing failed; retry required", {
      status: 500,
    });
  }
}
