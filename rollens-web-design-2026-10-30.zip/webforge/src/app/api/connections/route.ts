import { NextResponse } from "next/server";
import { authorize } from "@/lib/security";
import { writeConnections } from "@/lib/connections";
import { connectionStatus } from "@/lib/automation-config";
export async function POST(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    writeConnections(await request.json());
    return NextResponse.json(connectionStatus());
  } catch {
    return NextResponse.json(
      {
        error:
          "Invalid connection settings. Use a public HTTPS origin, valid key formats, and single-line values.",
      },
      { status: 400 },
    );
  }
}

export async function GET(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  return NextResponse.json(connectionStatus(), {
    headers: { "Cache-Control": "no-store" },
  });
}
