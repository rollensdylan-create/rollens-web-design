import { NextResponse } from "next/server";
import { z } from "zod";
import { authorize } from "@/lib/security";
import { db } from "@/lib/db";
import {
  prospect,
  saveProspect,
  outbox,
  saveOutreach,
  suppress,
} from "@/lib/automation-store";
export const runtime = "nodejs";
export async function POST(
  request: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    const { id } = await ctx.params;
    const p = prospect(id);
    if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const data = await request.json();
    if (data.action === "suppress") {
      if (!p.email) throw new Error("No recipient address");
      suppress(p.email, "Suppressed by operator");
      return NextResponse.json({ ok: true });
    }
    const input = z
      .object({
        email: z.string().email(),
        permission: z.enum(["UNKNOWN", "EXPRESS", "VERIFIED_BASIS"]),
        permissionEvidence: z.string().max(2000),
      })
      .parse(data);
    if (input.permission !== "UNKNOWN" && !input.permissionEvidence.trim())
      throw new Error("Record the permission basis and source");
    const o = outbox().find((o) => o.prospectId === p.id);
    if (o && o.attempts > 0 && o.recipient !== input.email.toLowerCase())
      throw new Error("A handed-off recipient cannot be changed");
    db.exec("BEGIN IMMEDIATE");
    try {
      p.email = input.email.toLowerCase();
      p.permission = input.permission;
      p.permissionEvidence = input.permissionEvidence;
      saveProspect(p);
      if (o && o.attempts === 0) {
        o.recipient = p.email;
        saveOutreach(o);
      }
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    return NextResponse.json(p);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Invalid contact" },
      { status: 400 },
    );
  }
}
