import { NextResponse } from "next/server";
import { existsSync } from "node:fs";
import { config } from "@/lib/config";
import { authorize } from "@/lib/security";
export async function GET(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return NextResponse.json({
    maxPages: config.maxPages,
    maxDepth: config.maxDepth,
    timeoutMs: config.timeoutMs,
    maxFixAttempts: config.maxFixAttempts,
    maxRuntimeMs: config.maxRuntimeMs,
    weights: config.weights,
    aiProvider: config.aiProvider,
    agentMode: config.agentMode,
    aiConfigured: !!config.aiKey && !!config.aiBaseUrl && !!config.aiModel,
    opencodeAvailable: !!config.opencodePath && existsSync(config.opencodePath),
  });
}
