import { NextResponse } from "next/server";
import { z } from "zod";
import { authorize, validateUrl } from "@/lib/security";
import {
  campaign,
  saveCampaign,
  CampaignSchema,
  importProspect,
  automationLog,
} from "@/lib/automation-store";
export const runtime = "nodejs";
export async function POST(
  request: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    const { id } = await ctx.params;
    const c = campaign(id);
    if (!c)
      return NextResponse.json(
        { error: "Campaign not found" },
        { status: 404 },
      );
    const data = await request.json();
    if (data.action === "import") {
      const rows = z
        .array(
          z.object({
            name: z.string().min(1).max(100),
            url: z.string().url().max(2000),
            email: z.string().email().optional(),
            permission: z
              .enum(["UNKNOWN", "EXPRESS", "VERIFIED_BASIS"])
              .optional(),
            permissionEvidence: z.string().max(2000).optional(),
          }),
        )
        .max(200)
        .parse(data.rows);
      for (const row of rows) await validateUrl(row.url);
      const result = rows.map((row) => importProspect(id, row));
      automationLog(
        c.id,
        `Imported ${result.filter((r) => r.created).length} business domains`,
      );
      return NextResponse.json({
        created: result.filter((r) => r.created).length,
        total: rows.length,
      });
    }
    if (data.action === "run") {
      c.nextRun = new Date().toISOString();
      saveCampaign(c);
      return NextResponse.json(c);
    }
    const input = CampaignSchema.parse({ ...c, ...data });
    const updated = { ...c, ...input };
    if (!c.enabled && updated.enabled)
      updated.nextRun = new Date().toISOString();
    saveCampaign(updated);
    automationLog(
      c.id,
      `Campaign settings updated · ${updated.enabled ? "running" : "paused"} · email ${updated.sendingEnabled ? "enabled" : "off"}`,
    );
    return NextResponse.json(updated);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Invalid request" },
      { status: 400 },
    );
  }
}
