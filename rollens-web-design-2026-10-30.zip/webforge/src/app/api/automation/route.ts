import { NextResponse } from "next/server";
import { authorize } from "@/lib/security";
import {
  campaigns,
  prospects,
  outbox,
  createCampaign,
  automationLogs,
  campaign,
  prospect,
} from "@/lib/automation-store";
import { connectionStatus } from "@/lib/automation-config";
import { deliveryBlockers } from "@/lib/outreach";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export async function GET(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  return NextResponse.json({
    campaigns: campaigns(),
    prospects: prospects(),
    outbox: outbox().map((o) => {
      const c = campaign(o.campaignId),
        p = prospect(o.prospectId);
      return {
        ...o,
        blockers:
          c && p ? deliveryBlockers(c, p, o) : ["Campaign or prospect missing"],
      };
    }),
    connections: connectionStatus(),
    logs: automationLogs(),
  });
}
export async function POST(request: Request) {
  if (!authorize(request))
    return NextResponse.json({ error: "Local access only" }, { status: 403 });
  try {
    return NextResponse.json(createCampaign(await request.json()), {
      status: 201,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Invalid campaign" },
      { status: 400 },
    );
  }
}
