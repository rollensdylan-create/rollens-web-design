"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Box,
  Check,
  CheckCircle2,
  ChevronRight,
  Code2,
  Command,
  ExternalLink,
  FileJson,
  FlaskConical,
  Folder,
  Globe,
  Layers,
  LayoutDashboard,
  Loader2,
  Maximize2,
  Monitor,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Smartphone,
  Square,
  Tablet,
  Terminal,
  TriangleAlert,
  X,
  Zap,
} from "lucide-react";
import type { Mission, Event, Settings, Audit } from "@/lib/types";
import { STAGES } from "@/lib/types";
import AutomationPanel from "./automation-panel";
type Detail = Mission & { artifacts: string[] };
type Worker = { online: boolean; lastSeen: string | null };
const statusLabel = (s: string) => s.toLowerCase().replaceAll("_", " ");
const shortDate = (s: string) =>
  new Date(s).toLocaleString("en-AU", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
const duration = (ms: number) =>
  ms === 0 ? "—" : ms < 1000 ? `${ms}ms` : `${Math.round(ms / 1000)}s`;
const terminalStatuses = ["COMPLETED", "CANCELLED", "FAILED"];
async function json(url: string, options?: RequestInit) {
  const res = await fetch(url, options);
  const body = await res.json();
  if (!res.ok) throw new Error(body.error || "Request failed");
  return body;
}
function Badge({ value }: { value: string }) {
  return (
    <span className={`badge ${value.toLowerCase()}`}>
      <i />
      {statusLabel(value)}
    </span>
  );
}
function Score({ audit }: { audit: Audit }) {
  return (
    <div className="score-summary">
      <div
        className="score-ring"
        style={{ "--score": audit.overallScore } as React.CSSProperties}
      >
        <b>{audit.overallScore}</b>
        <small>/ 100</small>
      </div>
      <div>
        <span className="eyebrow">SOURCE WEBSITE SCORE</span>
        <h3>
          {audit.overallScore >= 80
            ? "A strong foundation"
            : audit.overallScore >= 60
              ? "Room to improve"
              : "A clear opportunity"}
        </h3>
        <p>{audit.findings.length} findings across 7 weighted categories.</p>
      </div>
    </div>
  );
}
export default function MissionControl() {
  const router = useRouter();
  const pathname = usePathname();
  const view = pathname.split("/")[1] || "dashboard";
  const selectedFromPath = pathname.split("/")[2];
  const [missions, setMissions] = useState<Mission[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [worker, setWorker] = useState<Worker>({
    online: false,
    lastSeen: null,
  });
  const [events, setEvents] = useState<Event[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [tab, setTab] = useState("Activity");
  const [width, setWidth] = useState(1440);
  const [previewMode, setPreviewMode] = useState<"demo" | "source">("demo");
  const [modal, setModal] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [refreshPreview, setRefreshPreview] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", mode: "live" });
  const activityEnd = useRef<HTMLDivElement>(null);
  const reload = useCallback(async () => {
    try {
      const r = await json("/api/missions");
      setMissions(r.missions);
      setWorker(r.worker);
      setSelected(
        (current) => selectedFromPath || current || r.missions[0]?.id || null,
      );
      setLoaded(true);
    } catch (e) {
      setError((e as Error).message);
    }
  }, [selectedFromPath]);
  useEffect(() => {
    reload();
    json("/api/settings")
      .then(setSettings)
      .catch(() => {});
    const interval = setInterval(reload, 4000);
    return () => clearInterval(interval);
  }, [reload]);
  useEffect(() => {
    if (selectedFromPath) setSelected(selectedFromPath);
  }, [selectedFromPath]);
  const reloadDetail = useCallback(async () => {
    if (!selected) {
      setDetail(null);
      return;
    }
    try {
      setDetail(await json(`/api/missions/${selected}`));
    } catch (e) {
      setError((e as Error).message);
    }
  }, [selected]);
  useEffect(() => {
    reloadDetail();
    const timer = setInterval(reloadDetail, 3000);
    return () => clearInterval(timer);
  }, [reloadDetail]);
  useEffect(() => {
    const source = new EventSource("/api/events");
    source.onmessage = (e) => {
      const data = JSON.parse(e.data);
      setWorker(data.worker);
      if (data.events.length) {
        setEvents((current) => {
          const ids = new Set(current.map((x) => x.id));
          return [
            ...current,
            ...data.events.filter((x: Event) => !ids.has(x.id)),
          ].slice(-200);
        });
        reload();
        reloadDetail();
      }
    };
    return () => source.close();
  }, [reload, reloadDetail]);
  const select = (id: string) => {
    setSelected(id);
    setDetail(null);
    router.push(`/missions/${id}`);
  };
  async function create(fixture = false) {
    setBusy(true);
    setError("");
    try {
      const m = await json("/api/missions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          fixture
            ? {
                name: "Northline Electrical",
                url: "https://northline.example.test",
                mode: "fixture",
              }
            : form,
        ),
      });
      setModal(false);
      setForm({ name: "", url: "", mode: "live" });
      await reload();
      select(m.id);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function action(command: string) {
    if (!selected) return;
    setBusy(true);
    setError("");
    try {
      await json(`/api/missions/${selected}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: command }),
      });
      await Promise.all([reload(), reloadDetail()]);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const active = missions.filter((m) => m.status === "RUNNING");
  const completed = missions.filter(
    (m) => m.status === "COMPLETED" && m.demo?.status === "PREVIEW_READY",
  );
  const filtered = missions.filter(
    (m) =>
      (filter === "ALL" || m.status === filter) &&
      `${m.name} ${m.websiteUrl}`.toLowerCase().includes(search.toLowerCase()),
  );
  const average = missions.filter((m) => m.audit).length
    ? Math.round(
        missions
          .filter((m) => m.audit)
          .reduce((s, m) => s + m.audit!.overallScore, 0) /
          missions.filter((m) => m.audit).length,
      )
    : null;
  const nav = [
    { key: "automation", label: "Autopilot", icon: Zap },
    { key: "connections", label: "Payment setup", icon: Zap },
    { key: "dashboard", label: "Overview", icon: LayoutDashboard },
    { key: "missions", label: "Mission control", icon: Command },
    { key: "businesses", label: "Businesses", icon: Globe },
    { key: "demos", label: "Demo library", icon: Layers },
    { key: "settings", label: "Configuration", icon: Settings2 },
  ];
  const isMission = view === "missions" && !!selectedFromPath;
  const title =
    view === "automation"
      ? "Business autopilot"
      : view === "dashboard"
        ? "Operations overview"
        : view === "businesses"
          ? "Business directory"
          : view === "demos"
            ? "Demo library"
            : view === "settings"
              ? "System configuration"
              : "Mission control";
  const selectedEvents =
    detail?.events || events.filter((e) => e.missionId === selected);
  const selectedStage = detail ? STAGES.indexOf(detail.currentStage) : 0;
  const preview = detail?.demo?.previewUrl;
  const sourceImage = detail?.scan?.screenshots.find((s) =>
    s.includes(String(width)),
  );
  const demoImage = detail?.artifacts?.find(
    (s) => s === `screenshots/demo-${width}.png`,
  );
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a
          href="/dashboard"
          onClick={(e) => {
            e.preventDefault();
            router.push("/dashboard");
          }}
          className="wordmark"
        >
          <span className="logo">
            <Zap size={20} fill="currentColor" />
          </span>
          WEBFORGE<span className="version">/ 01</span>
        </a>
        <div className="workspace-label">
          WORKSPACE <span>LOCAL</span>
        </div>
        <nav>
          {nav.map((n) => (
            <a
              href={`/${n.key}`}
              key={n.key}
              onClick={(e) => {
                e.preventDefault();
                router.push(`/${n.key}`);
              }}
              className={view === n.key ? "active" : ""}
            >
              <n.icon size={17} />
              <span>{n.label}</span>
              {n.key === "missions" && active.length > 0 && (
                <em>{active.length}</em>
              )}
            </a>
          ))}
        </nav>
        <div className="sidebar-divider" />
        <div className="queue-heading">
          MISSION QUEUE{" "}
          <span>{missions.length.toString().padStart(2, "0")}</span>
        </div>
        <div className="queue-list">
          {missions.slice(0, 12).map((m) => (
            <button
              className={`queue-item ${selected === m.id && view === "missions" ? "selected" : ""}`}
              key={m.id}
              onClick={() => select(m.id)}
            >
              <div>
                <span className={`queue-dot ${m.status.toLowerCase()}`} />
                <b>{m.name}</b>
              </div>
              <small>
                {statusLabel(m.currentStage)} <span>{m.progress}%</span>
              </small>
              <div className="mini-progress">
                <i style={{ width: `${m.progress}%` }} />
              </div>
            </button>
          ))}
          {!missions.length && (
            <div className="queue-empty">
              Your next build starts here.
              <br />
              Create a mission to begin.
            </div>
          )}
        </div>
        <button className="sidebar-new" onClick={() => setModal(true)}>
          <Plus size={15} /> New mission
        </button>
        <div className="sidebar-bottom">
          <div className={`worker-dot ${worker.online ? "online" : ""}`} />
          <div>
            <b>{worker.online ? "Worker connected" : "Worker offline"}</b>
            <small>
              {worker.online
                ? "Local execution engine"
                : "Start the worker to process jobs"}
            </small>
          </div>
          <Radio size={16} />
        </div>
        <div className="operator">
          <span>DM</span>
          <div>
            <b>Local operator</b>
            <small>WebForge workspace</small>
          </div>
          <ShieldCheck size={17} />
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace <ChevronRight size={13} />{" "}
            <span>{view === "missions" ? "Mission control" : title}</span>
            {isMission && (
              <>
                <ChevronRight size={13} />
                <span className="mono">{selectedFromPath?.slice(0, 8)}</span>
              </>
            )}
          </div>
          <div className="topbar-right">
            <span className="local-indicator">
              <i /> LOCAL ENVIRONMENT
            </span>
            <button
              className="icon-btn"
              title="Refresh mission data"
              onClick={() => {
                reload();
                reloadDetail();
              }}
            >
              <RefreshCw size={15} />
            </button>
          </div>
        </header>
        <div className="page-content">
          <div className="page-heading">
            <div>
              <div className="eyebrow">
                WEBSITE PRODUCTION / MISSION CONTROL
              </div>
              <h1>
                {isMission ? detail?.name || "Loading mission…" : title}
                <span className="heading-period">.</span>
              </h1>
              <p>
                {isMission
                  ? detail?.websiteUrl
                  : "From first scan to a better website. Every stage, in view."}
              </p>
            </div>
            <button className="primary" onClick={() => setModal(true)}>
              <Plus size={16} /> New mission <span>↗</span>
            </button>
          </div>
          {error && (
            <div className="error-banner">
              <TriangleAlert size={17} />
              {error}
              <button onClick={() => setError("")} aria-label="Dismiss error">
                <X size={16} />
              </button>
            </div>
          )}
          {!worker.online && loaded && (
            <div className="notice">
              <Terminal size={16} />
              <span>
                The worker is offline. Missions stay safely queued until you run{" "}
                <code>pnpm worker</code>.
              </span>
            </div>
          )}
          {view === "automation" && <AutomationPanel />}
          {view === "dashboard" && (
            <>
              <div className="stats-grid">
                {[
                  {
                    label: "ACTIVE MISSIONS",
                    value: active.length,
                    foot: `${missions.filter((m) => m.status === "QUEUED").length} waiting in queue`,
                    icon: Activity,
                  },
                  {
                    label: "DEMOS COMPLETED",
                    value: completed.length,
                    foot: "Audited, built and QA checked",
                    icon: Layers,
                  },
                  {
                    label: "AVERAGE SOURCE SCORE",
                    value: average ?? "—",
                    foot: "Weighted audit / 100",
                    icon: ShieldCheck,
                  },
                  {
                    label: "NEEDS ATTENTION",
                    value: missions.filter((m) => m.status === "FAILED").length,
                    foot: "Failed missions to review",
                    icon: TriangleAlert,
                  },
                ].map((s) => (
                  <div className="stat" key={s.label}>
                    <div className="stat-label">
                      {s.label}
                      <s.icon size={16} />
                    </div>
                    <b>
                      {s.value}
                      <span>
                        {s.label.includes("SCORE") && average !== null
                          ? "/100"
                          : ""}
                      </span>
                    </b>
                    <small>{s.foot}</small>
                  </div>
                ))}
              </div>
              {missions.some((m) => m.mode === "fixture") && (
                <div className="metrics-note">
                  <FlaskConical size={12} /> Metrics include labelled training
                  fixtures.
                </div>
              )}
              <div className="overview-grid">
                <section className="panel">
                  <div className="panel-heading">
                    <h2>
                      Mission activity{" "}
                      <span className="count">{missions.length}</span>
                    </h2>
                    <button
                      onClick={() => router.push("/missions")}
                      className="text-btn"
                    >
                      View all <ArrowUpRight size={14} />
                    </button>
                  </div>
                  {missions.length ? (
                    <div className="mission-table">
                      <div className="table-head">
                        <span>BUSINESS / WEBSITE</span>
                        <span>CURRENT STAGE</span>
                        <span>STATUS</span>
                        <span>SCORE</span>
                      </div>
                      {missions.slice(0, 7).map((m) => (
                        <button
                          className="table-row"
                          key={m.id}
                          onClick={() => select(m.id)}
                        >
                          <div className="business-cell">
                            <span className="business-avatar">
                              {m.name.slice(0, 1)}
                            </span>
                            <div>
                              <b>{m.name}</b>
                              <small>
                                {new URL(m.websiteUrl).hostname}
                                {m.mode === "fixture"
                                  ? " · TRAINING FIXTURE"
                                  : ""}
                              </small>
                            </div>
                          </div>
                          <span className="stage-text">
                            {statusLabel(m.currentStage)}
                          </span>
                          <Badge value={m.status} />
                          <span className="table-score">
                            {m.audit?.overallScore ?? "—"}{" "}
                            <ChevronRight size={14} />
                          </span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="empty-state">
                      <div className="empty-graphic">
                        <Command size={36} />
                      </div>
                      <h3>A clear view of every build.</h3>
                      <p>
                        Submit a business website. WebForge scans the source,
                        calculates an audit, creates a redesign and tests the
                        result.
                      </p>
                      <button
                        className="primary"
                        onClick={() => setModal(true)}
                      >
                        <Plus size={15} /> Create your first mission
                      </button>
                      <button
                        className="text-btn"
                        disabled={busy}
                        onClick={() => create(true)}
                      >
                        <FlaskConical size={14} /> Or run a labelled training
                        fixture
                      </button>
                    </div>
                  )}
                </section>
                <section className="panel activity-overview">
                  <div className="panel-heading">
                    <h2>
                      <span className="live-dot" /> Live event stream
                    </h2>
                    <span className="eyebrow">LOCAL</span>
                  </div>
                  <EventList events={events.slice(-12)} compact />
                  <div className="panel-foot">
                    <Radio size={13} /> Durable events · live connection
                  </div>
                </section>
              </div>
              <section className="pipeline-intro">
                <div>
                  <span className="eyebrow">THE PRODUCTION PIPELINE</span>
                  <h2>Evidence first. Better websites next.</h2>
                  <p>
                    Every mission keeps its source data, decisions and generated
                    artifacts together.
                  </p>
                </div>
                <div className="pipeline-overview">
                  {[
                    { icon: Search, label: "Scan", sub: "Discover & capture" },
                    {
                      icon: ShieldCheck,
                      label: "Audit",
                      sub: "Measure & prioritise",
                    },
                    {
                      icon: Code2,
                      label: "Build",
                      sub: "Strategy into structure",
                    },
                    {
                      icon: CheckCircle2,
                      label: "Verify",
                      sub: "QA & preview",
                    },
                  ].map((s, i) => (
                    <div key={s.label}>
                      <s.icon size={21} />
                      <b>{s.label}</b>
                      <small>{s.sub}</small>
                      {i < 3 && <ArrowRight className="step-arrow" size={15} />}
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}
          {view === "missions" && !isMission && (
            <section className="panel">
              <div className="panel-heading">
                <h2>All missions</h2>
                <div className="filters">
                  <Search size={15} />
                  <input
                    placeholder="Search businesses…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  <select
                    aria-label="Filter mission status"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                  >
                    {[
                      "ALL",
                      "QUEUED",
                      "RUNNING",
                      "PAUSED",
                      "COMPLETED",
                      "FAILED",
                      "CANCELLED",
                    ].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="mission-table">
                <div className="table-head">
                  <span>BUSINESS / WEBSITE</span>
                  <span>CREATED</span>
                  <span>STATUS</span>
                  <span>PROGRESS</span>
                </div>
                {filtered.map((m) => (
                  <button
                    className="table-row"
                    key={m.id}
                    onClick={() => select(m.id)}
                  >
                    <div className="business-cell">
                      <span className="business-avatar">{m.name[0]}</span>
                      <div>
                        <b>{m.name}</b>
                        <small>
                          {new URL(m.websiteUrl).hostname}
                          {m.mode === "fixture" ? " · TRAINING FIXTURE" : ""}
                        </small>
                      </div>
                    </div>
                    <span className="mono muted">{shortDate(m.createdAt)}</span>
                    <Badge value={m.status} />
                    <span className="table-score">
                      {m.progress}% <ChevronRight size={15} />
                    </span>
                  </button>
                ))}
              </div>
              {!filtered.length && (
                <div className="simple-empty">
                  No matching missions. Create a mission to get started.
                </div>
              )}
            </section>
          )}
          {isMission && detail && (
            <>
              <div className="mission-toolbar">
                <div>
                  <Badge value={detail.status} />
                  <span className="mono muted">{detail.id.slice(0, 8)}</span>
                  {detail.mode === "fixture" && (
                    <span className="fixture-label">
                      <FlaskConical size={12} /> SIMULATED SOURCE
                    </span>
                  )}
                </div>
                <div className="controls">
                  {["QUEUED", "RUNNING"].includes(detail.status) && (
                    <button
                      disabled={busy || detail.pauseRequested}
                      onClick={() => action("pause")}
                    >
                      <Pause size={13} />
                      {detail.pauseRequested ? "Pausing after stage…" : "Pause"}
                    </button>
                  )}
                  {detail.status === "PAUSED" && (
                    <button disabled={busy} onClick={() => action("resume")}>
                      <Play size={13} />
                      Resume
                    </button>
                  )}
                  {detail.status === "FAILED" && (
                    <button disabled={busy} onClick={() => action("retry")}>
                      <RefreshCw size={13} />
                      Retry stage
                    </button>
                  )}
                  {["COMPLETED", "FAILED"].includes(detail.status) &&
                    detail.demo && (
                      <>
                        <button disabled={busy} onClick={() => action("qa")}>
                          <ShieldCheck size={13} />
                          Rerun QA
                        </button>
                        <button
                          disabled={busy}
                          onClick={() => action("rebuild")}
                        >
                          <Code2 size={13} />
                          Rebuild
                        </button>
                      </>
                    )}
                  {!terminalStatuses.includes(detail.status) && (
                    <button disabled={busy} onClick={() => action("cancel")}>
                      <Square size={12} />
                      Cancel
                    </button>
                  )}
                </div>
              </div>
              {detail.error && (
                <div className="error-banner">
                  <TriangleAlert size={16} />
                  {detail.error}
                </div>
              )}
              <section className="pipeline-panel">
                <div className="pipeline-top">
                  <span className="eyebrow">MISSION PROGRESS</span>
                  <b className="mono">
                    {detail.progress}
                    <small>%</small>
                  </b>
                </div>
                <div className="stage-track">
                  {STAGES.map((s, i) => (
                    <div
                      key={s}
                      className={`pipeline-stage ${detail.nextStage > i ? "done" : ""} ${i === selectedStage && detail.status === "RUNNING" ? "working" : ""} ${i === selectedStage && detail.status === "FAILED" ? "failed" : ""}`}
                    >
                      <span>
                        {detail.nextStage > i ? (
                          <Check size={13} />
                        ) : i === selectedStage &&
                          detail.status === "RUNNING" ? (
                          <Loader2 className="spin" size={13} />
                        ) : (
                          String(i + 1).padStart(2, "0")
                        )}
                      </span>
                      <small>
                        {s === "DISCOVERY" ? "Discover" : s.toLowerCase()}
                      </small>
                    </div>
                  ))}
                </div>
              </section>
              <div className="mission-grid">
                <section className="panel mission-details">
                  <div className="tabs">
                    {[
                      "Activity",
                      "Audit",
                      "Strategy",
                      "Source data",
                      "Artifacts",
                    ].map((t) => (
                      <button
                        key={t}
                        className={tab === t ? "active" : ""}
                        onClick={() => setTab(t)}
                      >
                        {t}
                        {t === "Activity" && <span className="live-dot" />}
                      </button>
                    ))}
                  </div>
                  {tab === "Activity" && (
                    <>
                      <div className="log-heading">
                        <span>
                          <Terminal size={14} /> MISSION OUTPUT
                        </span>
                        <span>{selectedEvents.length} EVENTS</span>
                      </div>
                      <div className="events-scroll">
                        <EventList events={selectedEvents} />
                        <div ref={activityEnd} />
                      </div>
                      <div className="execution-bar">
                        <span>
                          <Box size={13} />{" "}
                          {settings?.agentMode === "opencode"
                            ? "OpenCode adapter"
                            : "Deterministic template"}
                        </span>
                        <span>{duration(detail.usage.durationMs)} elapsed</span>
                      </div>
                    </>
                  )}
                  {tab === "Audit" &&
                    (detail.audit ? (
                      <div className="tab-content">
                        <Score audit={detail.audit} />
                        <div className="category-scores">
                          {Object.entries(detail.audit.scores).map(
                            ([key, value]) => (
                              <div key={key}>
                                <span>{key}</span>
                                <div>
                                  <i style={{ width: `${value}%` }} />
                                </div>
                                <b>{value}</b>
                              </div>
                            ),
                          )}
                        </div>
                        <h3>
                          Findings{" "}
                          <span className="count">
                            {detail.audit.findings.length}
                          </span>
                        </h3>
                        {detail.audit.findings.map((f) => (
                          <div className="finding" key={f.id}>
                            <span
                              className={`severity ${f.severity.toLowerCase()}`}
                            >
                              {f.severity}
                            </span>
                            <div>
                              <b>{f.message}</b>
                              <p>{f.recommendation}</p>
                              <small>
                                {f.category} / {f.kind}
                              </small>
                            </div>
                          </div>
                        ))}
                        <h3>Strengths</h3>
                        {detail.audit.strengths.map((s) => (
                          <p className="strength" key={s}>
                            <Check size={14} />
                            {s}
                          </p>
                        ))}
                        <p className="method-note">{detail.audit.method}</p>
                      </div>
                    ) : (
                      <Waiting text="The audit appears after scanning and analysis finish." />
                    ))}
                  {tab === "Strategy" &&
                    (detail.strategy ? (
                      <div className="tab-content">
                        <span className="provider-label">
                          {detail.strategy.provider}
                        </span>
                        <h2>Redesign direction</h2>
                        <p>{detail.strategy.summary}</p>
                        <h3>Page structure</h3>
                        <div className="section-chips">
                          {detail.strategy.sections.map((s, i) => (
                            <span key={s}>
                              <small>{String(i + 1).padStart(2, "0")}</small>
                              {s}
                            </span>
                          ))}
                        </div>
                        <h3>Priorities from the audit</h3>
                        {detail.strategy.priorities.map((s, i) => (
                          <p className="priority-item" key={s}>
                            <span>{i + 1}</span>
                            {s}
                          </p>
                        ))}
                        <p className="method-note">
                          The default template uses extracted service headings
                          and public contact details. It adds no invented
                          testimonials or credentials.
                        </p>
                      </div>
                    ) : (
                      <Waiting text="The strategy appears after the weighted audit." />
                    ))}
                  {tab === "Source data" &&
                    (detail.scan ? (
                      <div className="tab-content">
                        <h2>Collected source evidence</h2>
                        {detail.scan.warnings.map((w) => (
                          <p className="method-note" key={w}>
                            {w}
                          </p>
                        ))}
                        {detail.scan.pages.map((p, i) => (
                          <div className="source-card" key={p.url}>
                            <div className="eyebrow">
                              PAGE {i + 1} / HTTP {p.status}
                            </div>
                            <h3>{p.title || "Untitled page"}</h3>
                            <a href={p.url} target="_blank" rel="noreferrer">
                              {p.url} <ExternalLink size={12} />
                            </a>
                            <p>
                              {p.description || "No meta description found."}
                            </p>
                            <div className="source-metrics">
                              <span>{p.headings.length} headings</span>
                              <span>{p.links.length} links</span>
                              <span>{p.forms} forms</span>
                              <span>{p.responseMs}ms HTML fetch</span>
                            </div>
                            <h4>Service headings</h4>
                            <p>{p.services.join(" · ") || "None detected"}</p>
                            <h4>Public contact details</h4>
                            <p>
                              {[...p.emails, ...p.phones].join(" · ") ||
                                "None detected"}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <Waiting text="Public website data appears after the scan." />
                    ))}
                  {tab === "Artifacts" && (
                    <div className="tab-content">
                      <h2>Mission workspace</h2>
                      <p>
                        Durable records from each stage. Raw source pages open
                        with scripts and network access blocked.
                      </p>
                      <div className="artifact-list">
                        {detail.artifacts?.map((a) => (
                          <a
                            href={`/api/artifacts/${detail.id}/${a}`}
                            key={a}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <FileJson size={16} />
                            <span>{a}</span>
                            <ArrowUpRight size={14} />
                          </a>
                        ))}
                      </div>
                      {!detail.artifacts?.length && (
                        <Waiting text="Artifacts will be saved as the mission runs." />
                      )}
                    </div>
                  )}
                </section>
                <section className="panel preview-panel">
                  <div className="panel-heading">
                    <h2>
                      <span className="live-dot" /> Website preview
                    </h2>
                    {preview && (
                      <a
                        className="icon-btn"
                        href={preview}
                        target="_blank"
                        rel="noreferrer"
                        title="Open preview"
                      >
                        <Maximize2 size={14} />
                      </a>
                    )}
                  </div>
                  <div className="preview-controls">
                    <div>
                      <button
                        className={previewMode === "demo" ? "active" : ""}
                        onClick={() => setPreviewMode("demo")}
                      >
                        Redesign
                      </button>
                      <button
                        className={previewMode === "source" ? "active" : ""}
                        onClick={() => setPreviewMode("source")}
                      >
                        Source
                      </button>
                    </div>
                    <div>
                      {[
                        { w: 1440, I: Monitor },
                        { w: 768, I: Tablet },
                        { w: 390, I: Smartphone },
                      ].map(({ w, I }) => (
                        <button
                          title={`${w}px viewport`}
                          aria-label={`${w}px viewport`}
                          className={width === w ? "active" : ""}
                          key={w}
                          onClick={() => setWidth(w)}
                        >
                          <I size={15} />
                        </button>
                      ))}
                      <button
                        title="Refresh preview"
                        onClick={() => setRefreshPreview((x) => x + 1)}
                      >
                        <RefreshCw size={13} />
                      </button>
                    </div>
                  </div>
                  <div className="preview-address">
                    <i />
                    {previewMode === "demo"
                      ? "webforge / independent concept"
                      : new URL(detail.websiteUrl).hostname}
                    <span>{width}px</span>
                  </div>
                  <div className="preview-canvas">
                    {previewMode === "demo" && demoImage ? (
                      <img
                        key={`${width}-${refreshPreview}-${detail.completedAt}`}
                        src={`/api/artifacts/${detail.id}/${demoImage}?v=${refreshPreview}-${detail.nextStage}`}
                        alt={`Generated demo screenshot at ${width}px`}
                        style={{ width: width === 390 ? 260 : "100%" }}
                      />
                    ) : previewMode === "source" && sourceImage ? (
                      <img
                        src={`/api/artifacts/${detail.id}/${sourceImage}`}
                        alt={`Source website screenshot at ${width}px`}
                      />
                    ) : (
                      <div className="preview-wait">
                        <div className="preview-wire">
                          <span />
                          <span />
                          <i />
                          <i />
                          <i />
                        </div>
                        <b>
                          {previewMode === "source" && detail.mode === "fixture"
                            ? "Simulated source fixture"
                            : detail.demo
                              ? "Capturing the redesign"
                              : "A better website is taking shape."}
                        </b>
                        <p>
                          {previewMode === "source" && detail.mode === "fixture"
                            ? "Source screenshots are not simulated. Run a live mission to capture a real website."
                            : "Your screenshot preview appears after the build and viewport QA."}
                        </p>
                      </div>
                    )}
                  </div>
                  <div className="preview-footer">
                    <span>
                      {detail.qa ? (
                        <>
                          <ShieldCheck size={13} />
                          {detail.qa.status === "PASSED"
                            ? "QA passed at 3 viewports"
                            : "QA requires attention"}
                        </>
                      ) : (
                        <>
                          <Box size={13} /> Awaiting build
                        </>
                      )}
                    </span>
                    {preview && (
                      <a href={preview} target="_blank" rel="noreferrer">
                        Open demo <ArrowUpRight size={13} />
                      </a>
                    )}
                  </div>
                  <div className="resource-card">
                    <span className="eyebrow">EXECUTION & RESOURCES</span>
                    <div>
                      <span>Build engine</span>
                      <b>
                        {settings?.agentMode === "opencode"
                          ? "OpenCode"
                          : "Original template"}
                      </b>
                    </div>
                    <div>
                      <span>Agent executions</span>
                      <b>{detail.usage.agentExecutions}</b>
                    </div>
                    <div>
                      <span>AI tokens (in / out)</span>
                      <b>
                        {detail.usage.inputTokens} / {detail.usage.outputTokens}
                      </b>
                    </div>
                    <div>
                      <span>Model spend</span>
                      <b>
                        {detail.usage.model === "none"
                          ? "$0 · no AI calls"
                          : "Not priced"}
                      </b>
                    </div>
                  </div>
                </section>
              </div>
            </>
          )}
          {isMission && !detail && (
            <div className="simple-empty">
              <Loader2 className="spin" size={20} /> Loading mission workspace…
            </div>
          )}
          {view === "businesses" && (
            <div className="business-grid">
              {[
                ...new Map(missions.map((m) => [m.businessId, m])).values(),
              ].map((m) => (
                <section className="panel business-card" key={m.businessId}>
                  <div className="business-card-head">
                    <span className="business-avatar">{m.name[0]}</span>
                    <Globe size={18} />
                  </div>
                  <h2>{m.name}</h2>
                  <p>{new URL(m.websiteUrl).hostname}</p>
                  <div className="business-card-foot">
                    <span>
                      {
                        missions.filter((x) => x.businessId === m.businessId)
                          .length
                      }{" "}
                      missions
                    </span>
                    <button className="text-btn" onClick={() => select(m.id)}>
                      Open mission <ArrowUpRight size={14} />
                    </button>
                  </div>
                </section>
              ))}
              {!missions.length && (
                <section className="panel simple-empty">
                  Businesses are added when you create a mission.
                </section>
              )}
            </div>
          )}
          {view === "demos" && (
            <div className="demo-grid">
              {missions
                .filter((m) => m.demo)
                .map((m) => (
                  <section className="panel demo-card" key={m.id}>
                    <div className="demo-thumbnail">
                      {m.qa ? (
                        <img
                          src={`/api/artifacts/${m.id}/screenshots/demo-1440.png?v=${m.nextStage}`}
                          alt={`${m.name} generated website`}
                        />
                      ) : (
                        <Code2 size={35} />
                      )}
                    </div>
                    <div className="demo-info">
                      <Badge value={m.status} />
                      <h2>{m.name}</h2>
                      <p>
                        {m.demo?.framework} ·{" "}
                        {m.mode === "fixture"
                          ? "Training fixture"
                          : "Live source"}
                      </p>
                      <div>
                        <button
                          className="text-btn"
                          onClick={() => select(m.id)}
                        >
                          Inspect mission <ArrowRight size={14} />
                        </button>
                        <a
                          href={m.demo?.previewUrl}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Open preview <ExternalLink size={14} />
                        </a>
                      </div>
                    </div>
                  </section>
                ))}
              {!missions.some((m) => m.demo) && (
                <section className="panel simple-empty">
                  Generated demos will appear here after the build stage.
                </section>
              )}
            </div>
          )}
          {view === "settings" && settings && (
            <div className="settings-grid">
              <section className="panel tab-content">
                <span className="eyebrow">ENGINE CONFIGURATION</span>
                <h2>Controlled by your environment.</h2>
                <p>
                  These are the effective worker settings. Update the
                  environment configuration and restart both processes to apply
                  changes.
                </p>
                <div className="settings-rows">
                  {[
                    ["Build engine", settings.agentMode],
                    ["AI provider", settings.aiProvider],
                    [
                      "AI credentials",
                      settings.aiConfigured
                        ? "Configured"
                        : "Not configured · deterministic mode",
                    ],
                    [
                      "OpenCode executable",
                      settings.opencodeAvailable
                        ? "Available"
                        : "Not configured",
                    ],
                    ["Maximum crawl pages", settings.maxPages],
                    ["Maximum crawl depth", settings.maxDepth],
                    ["Request timeout", `${settings.timeoutMs / 1000}s`],
                    ["Maximum runtime", `${settings.maxRuntimeMs / 1000}s`],
                    ["Maximum fix attempts", settings.maxFixAttempts],
                  ].map(([key, value]) => (
                    <div key={key}>
                      <span>{key}</span>
                      <b>{value}</b>
                    </div>
                  ))}
                </div>
                <p className="method-note">
                  Local execution only. Public deployment requires
                  authentication, isolated agent execution and egress controls.
                  No third-party messages or websites are published by this
                  application.
                </p>
              </section>
              <section className="panel tab-content">
                <span className="eyebrow">AUDIT METHODOLOGY</span>
                <h2>Seven categories. Clear weights.</h2>
                <div className="settings-rows">
                  {Object.entries(settings.weights).map(([key, value]) => (
                    <div key={key}>
                      <span className="capitalize">{key}</span>
                      <b>{value}%</b>
                    </div>
                  ))}
                </div>
                <p className="method-note">
                  Scores combine deterministic checks with labelled structural
                  heuristics. They are not a visual design review or a
                  Lighthouse benchmark.
                </p>
                <h3>Privacy & isolation</h3>
                <p>
                  Source and generated HTML are served in a restricted sandbox
                  with scripts, forms and network requests blocked. Secrets stay
                  in the server environment.
                </p>
              </section>
            </div>
          )}
          <footer className="app-footer">
            <span>
              <Zap size={12} /> WEBFORGE MISSION CONTROL
            </span>
            <span>
              LOCAL WORKSPACE <i />{" "}
              {loaded ? `${missions.length} MISSIONS` : "CONNECTING"}
            </span>
          </footer>
        </div>
      </main>
      {modal && (
        <div
          className="modal-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) setModal(false);
          }}
        >
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
          >
            <button
              className="close-modal"
              onClick={() => setModal(false)}
              aria-label="Close new mission"
            >
              <X size={19} />
            </button>
            <span className="modal-icon">
              <Command size={25} />
            </span>
            <div className="eyebrow">NEW WEBSITE MISSION</div>
            <h2 id="modal-title">Start with a website.</h2>
            <p>
              Scan a public business website, understand its weaknesses and
              create an original redesign preview.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                create();
              }}
            >
              <label>
                Business name
                <input
                  required
                  autoFocus
                  maxLength={100}
                  placeholder="e.g. Northline Electrical"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </label>
              <label>
                Website URL
                <input
                  type="url"
                  required
                  placeholder="https://business.com.au"
                  value={form.url}
                  onChange={(e) => setForm({ ...form, url: e.target.value })}
                />
              </label>
              <div className="modal-note">
                <ShieldCheck size={16} />
                <span>
                  Bounded public scan · original template · 3 viewport QA
                  <br />
                  No source code copied. No public deployment.
                </span>
              </div>
              {error && <p className="form-error">{error}</p>}
              <button className="primary" disabled={busy} type="submit">
                {busy ? (
                  <Loader2 className="spin" size={16} />
                ) : (
                  <Play size={15} />
                )}
                Launch mission <ArrowRight size={15} />
              </button>
            </form>
            <div className="fixture-option">
              <span>Want to test the pipeline first?</span>
              <button onClick={() => create(true)} disabled={busy}>
                <FlaskConical size={14} /> Run training fixture
              </button>
              <small>
                Clearly labelled simulated source. Real build and QA.
              </small>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
function Waiting({ text }: { text: string }) {
  return (
    <div className="waiting">
      <Folder size={28} />
      <p>{text}</p>
    </div>
  );
}
function EventList({
  events,
  compact = false,
}: {
  events: Event[];
  compact?: boolean;
}) {
  if (!events.length)
    return (
      <div className="event-empty">
        <Radio size={23} />
        <p>Listening for mission events.</p>
        <small>Actions and results will appear here in real time.</small>
      </div>
    );
  return (
    <div className={`event-list ${compact ? "compact" : ""}`}>
      {events.map((e) => (
        <div className={`event-row ${e.severity.toLowerCase()}`} key={e.id}>
          <time>
            {new Date(e.timestamp).toLocaleTimeString("en-AU", {
              hour12: false,
            })}
          </time>
          <span className="event-symbol">
            {e.severity === "SUCCESS" ? (
              <Check size={13} />
            ) : e.severity === "ERROR" ? (
              <X size={13} />
            ) : e.severity === "WARNING" ? (
              <TriangleAlert size={13} />
            ) : (
              <ChevronRight size={13} />
            )}
          </span>
          <div>
            <small>{e.stage}</small>
            <p>{e.message}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
