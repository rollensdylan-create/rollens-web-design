import MissionControl from "@/app/control";
export default function Page() {
  return <MissionControl />;
}
