"use client";
import { useEffect, useState } from "react";
import {
  Plus,
  Play,
  Pause,
  ShieldCheck,
  ArrowUpRight,
  RefreshCw,
  Save,
  Check,
  X,
  TriangleAlert,
} from "lucide-react";
import type { Campaign, Prospect, Outbox } from "@/lib/automation-store";
type Delivery = Outbox & { blockers: string[] };
type Snapshot = {
  campaigns: Campaign[];
  prospects: Prospect[];
  outbox: Delivery[];
  connections: {
    email: boolean;
    stripe: boolean;
    webhook: boolean;
    search: boolean;
    searchProvider: string;
    publicBaseReady: boolean;
    publicBase: string;
    stripeMode: string;
  };
  logs: { id: number; timestamp: string; message: string; severity: string }[];
};
const defaults = {
  name: "New business campaign",
  niche: "",
  area: "",
  threshold: 60,
  dailyScans: 10,
  dailyEmails: 5,
  intervalHours: 24,
  discoverySource: "primary" as
    "primary" | "anakin" | "brave" | "osm" | "manual",
  priceCents: 3300,
  senderName: "WebForge",
  senderEmail: "",
  replyTo: "",
  senderAddress: "",
  subject: "A website preview for {{business_name}}",
  template:
    "Hi {{business_name}} team,\n\nI reviewed your website and put together an independent redesign preview, focused on {{improvements}}.\n\nTake a look: {{preview_url}}\n\nThe website plan is {{price}} AUD per month, including hosting and basic maintenance. You can review the details and subscribe securely through Stripe on the preview page. Business details and launch arrangements are confirmed before publication.\n\n{{sender_name}}\n{{sender_address}}\n\nUnsubscribe: {{unsubscribe_url}}",
  enabled: false,
  sendingEnabled: false,
};
async function api(url: string, body?: unknown) {
  const r = await fetch(url, {
    method: body ? "POST" : "GET",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || "Request failed");
  return d;
}
export default function AutomationPanel() {
  const [data, setData] = useState<Snapshot | null>(null);
  const [id, setId] = useState("");
  const [form, setForm] = useState(defaults);
  const [tab, setTab] = useState("Pipeline");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [imports, setImports] = useState("");
  const [contact, setContact] = useState<Prospect | null>(null);
  const [contactForm, setContactForm] = useState({
    email: "",
    permission: "UNKNOWN",
    permissionEvidence: "",
  });
  const [connection, setConnection] = useState({
    resendKey: "",
    stripeKey: "",
    stripeWebhook: "",
    anakinKey: "",
    braveKey: "",
    publicBase: "",
  });
  const [email, setEmail] = useState<Delivery | null>(null);
  async function reload() {
    try {
      setData(await api("/api/automation"));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  useEffect(() => {
    reload();
    const t = setInterval(reload, 4000);
    return () => clearInterval(t);
  }, []);
  async function run(fn: () => Promise<void>) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await fn();
      await reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const current = data?.campaigns.find((c) => c.id === id);
  const list = data?.prospects.filter((p) => !id || p.campaignId === id) || [];
  const messages = data?.outbox.filter((o) => !id || o.campaignId === id) || [];
  function choose(c: Campaign) {
    setId(c.id);
    setForm({ ...defaults, ...c });
    setMessage("");
  }
  async function save() {
    await run(async () => {
      const c = await api(
        id ? `/api/automation/${id}` : "/api/automation",
        form,
      );
      setId(c.id);
      setForm({ ...defaults, ...c });
      setMessage("Campaign saved. The worker reads changes automatically.");
    });
  }
  async function toggle(enabled: boolean) {
    if (!id) return;
    await run(async () => {
      const c = await api(`/api/automation/${id}`, { enabled });
      setForm({ ...defaults, ...c });
      setMessage(
        enabled
          ? "Campaign started. The worker will discover/import, scan, filter, build and prepare outreach."
          : "Campaign paused. Already running scan stages finish safely.",
      );
    });
  }
  async function importRows() {
    await run(async () => {
      let rows;
      if (imports.trim().startsWith("[")) rows = JSON.parse(imports);
      else
        rows = imports
          .split("\n")
          .filter((x) => x.trim())
          .map((line) => {
            const [name, url] = line.split(/[\t,]/).map((x) => x.trim());
            return { name, url };
          });
      const result = await api(`/api/automation/${id}`, {
        action: "import",
        rows,
      });
      setImports("");
      setMessage(
        `${result.created} new business domains imported. Duplicates skipped.`,
      );
    });
  }
  return (
    <div className="automation-panel">
      {error && (
        <div className="error-banner">
          <TriangleAlert size={15} />
          {error}
        </div>
      )}
      {message && (
        <div className="notice">
          <Check size={15} />
          {message}
        </div>
      )}
      <section className="automation-flow">
        {[
          "Discover websites",
          "Score & filter",
          "Build & test",
          "Prepare outreach",
          "Email & subscribe",
        ].map((s, i) => (
          <div key={s}>
            <small>0{i + 1}</small>
            <b>{s}</b>
            <span>
              {
                [
                  "Target niche + area",
                  "Below your cutoff",
                  "Demo + 3 viewport QA",
                  "Template + contact basis",
                  "Resend + Stripe Checkout",
                ][i]
              }
            </span>
          </div>
        ))}
      </section>
      <div className="campaign-switch">
        <div>
          <span className="eyebrow">CAMPAIGNS</span>
          <select
            aria-label="Select campaign"
            value={id}
            onChange={(e) => {
              const c = data?.campaigns.find((c) => c.id === e.target.value);
              if (c) choose(c);
              else {
                setId("");
                setForm(defaults);
              }
            }}
          >
            <option value="">Create a campaign</option>
            {data?.campaigns.map((c) => (
              <option value={c.id} key={c.id}>
                {c.name} · {c.enabled ? "Running" : "Paused"}
              </option>
            ))}
          </select>
        </div>
        <div>
          <button
            className="text-btn"
            onClick={() => {
              setId("");
              setForm(defaults);
              setTab("Campaign");
            }}
          >
            <Plus size={15} /> New campaign
          </button>
          {current && (
            <button
              className="primary"
              disabled={busy}
              onClick={() => toggle(!current.enabled)}
            >
              {current.enabled ? <Pause size={14} /> : <Play size={14} />}{" "}
              {current.enabled ? "Pause campaign" : "Start campaign"}
            </button>
          )}
        </div>
      </div>
      <div className="tabs automation-tabs">
        {["Pipeline", "Campaign", "Outreach", "Connections", "Activity"].map(
          (t) => (
            <button
              className={tab === t ? "active" : ""}
              key={t}
              onClick={() => setTab(t)}
            >
              {t}
            </button>
          ),
        )}
      </div>
      {tab === "Pipeline" && (
        <>
          <div className="stats-grid automation-stats">
            {[
              ["PROSPECTS", list.length],
              [
                "FILTERED OUT",
                list.filter((p) => p.status === "FILTERED_OUT").length,
              ],
              [
                "DEMO READY",
                list.filter((p) => p.status === "DEMO_READY").length,
              ],
              [
                "EMAIL ACCEPTED",
                messages.filter((o) => o.state === "SENT").length,
              ],
            ].map(([label, value]) => (
              <div className="stat" key={label}>
                <div className="stat-label">{label}</div>
                <b>{value}</b>
              </div>
            ))}
          </div>
          <section className="panel">
            <div className="panel-heading">
              <h2>Prospect pipeline</h2>
              <button className="text-btn" onClick={reload}>
                <RefreshCw size={14} /> Refresh
              </button>
            </div>
            {current?.discoverySource === "osm" && (
              <p>
                Free Melbourne trade listings, refreshed weekly from a local
                regional dataset. Coverage varies. ©{" "}
                <a
                  href="https://www.openstreetmap.org/copyright"
                  target="_blank"
                  rel="noreferrer"
                >
                  OpenStreetMap contributors · ODbL
                </a>
                . Public contacts are research evidence only.
              </p>
            )}
            <div className="prospect-table">
              {list.map((p) => (
                <div className="prospect-row" key={p.id}>
                  <div>
                    <b>{p.name}</b>
                    <small>{p.domain}</small>
                    {p.discoverySourceUrl && (
                      <small>
                        <a
                          href={p.discoverySourceUrl}
                          target="_blank"
                          rel="noreferrer"
                        >
                          OpenStreetMap source ↗
                        </a>
                      </small>
                    )}
                    {p.error && <p className="form-error">{p.error}</p>}
                  </div>
                  <div>
                    <span className="eyebrow">SOURCE SCORE</span>
                    <b>{p.score === null ? "—" : `${p.score}/100`}</b>
                  </div>
                  <div>
                    <span
                      className={`badge ${p.status === "FAILED" ? "failed" : p.status === "DEMO_READY" ? "completed" : ""}`}
                    >
                      {p.status.replaceAll("_", " ").toLowerCase()}
                    </span>
                    <small>
                      {p.contacts.length} emails · {p.phones?.length || 0} phone
                      numbers found
                    </small>
                  </div>
                  <div>
                    <button
                      className="text-btn"
                      onClick={() => {
                        setContact(p);
                        setContactForm({
                          email: p.email || p.contacts[0]?.email || "",
                          permission: p.permission,
                          permissionEvidence: p.permissionEvidence,
                        });
                      }}
                    >
                      Contact & permission ↗
                    </button>
                    {p.missionId && (
                      <a className="text-btn" href={`/missions/${p.missionId}`}>
                        Inspect mission <ArrowUpRight size={12} />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
            {!list.length && (
              <div className="simple-empty">
                Create a campaign and import business websites, or configure
                search to discover them.
              </div>
            )}
          </section>
          {current && (
            <section className="panel tab-content import-panel">
              <h2>Import business websites</h2>
              <p>
                One business per line: <code>Name,https://website.com.au</code>.
                You can also paste a JSON array with name, url, and optional
                email, permission and permissionEvidence fields. Public contact
                details discovered during scanning stay separate from permission
                to send.
              </p>
              <textarea
                aria-label="Business website import"
                value={imports}
                onChange={(e) => setImports(e.target.value)}
                placeholder={
                  "Northline Electrical,https://example.com.au\nLocal Plumbing,https://example.org.au"
                }
                rows={5}
              />
              <button
                className="primary"
                disabled={busy || !imports.trim()}
                onClick={importRows}
              >
                <Plus size={14} /> Import websites
              </button>
            </section>
          )}
        </>
      )}
      {tab === "Campaign" && (
        <section className="panel tab-content">
          <div className="automation-form">
            <label>
              Campaign name
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </label>
            <label>
              Target business niche
              <input
                placeholder="e.g. electricians"
                value={form.niche}
                onChange={(e) => setForm({ ...form, niche: e.target.value })}
              />
            </label>
            <label>
              Target area
              <input
                placeholder="e.g. Melbourne, Victoria"
                value={form.area}
                onChange={(e) => setForm({ ...form, area: e.target.value })}
              />
            </label>
            <label>
              Website discovery
              <select
                value={form.discoverySource}
                onChange={(e) =>
                  setForm({
                    ...form,
                    discoverySource: e.target.value as
                      "primary" | "anakin" | "brave" | "osm" | "manual",
                  })
                }
              >
                <option value="primary">
                  Primary provider (Anakin when configured)
                </option>
                <option value="anakin">Anakin Search (API key required)</option>
                <option value="osm">
                  OpenStreetMap — Melbourne trades (free)
                </option>
                <option value="manual">Imported websites only (free)</option>
                <option value="brave">Brave Search (API key required)</option>
              </select>
            </label>
            <label>
              Build only when source score is below
              <input
                type="number"
                min={1}
                max={100}
                value={form.threshold}
                onChange={(e) =>
                  setForm({ ...form, threshold: Number(e.target.value) })
                }
              />
            </label>
            <label>
              Maximum scans per day
              <input
                type="number"
                min={1}
                max={100}
                value={form.dailyScans}
                onChange={(e) =>
                  setForm({ ...form, dailyScans: Number(e.target.value) })
                }
              />
            </label>
            <label>
              Maximum emails per day
              <input
                type="number"
                min={1}
                max={50}
                value={form.dailyEmails}
                onChange={(e) =>
                  setForm({ ...form, dailyEmails: Number(e.target.value) })
                }
              />
            </label>
            <label>
              Scan schedule (hours; 0.5 = 30 minutes)
              <input
                type="number"
                min={0.5}
                step={0.5}
                max={168}
                value={form.intervalHours}
                onChange={(e) =>
                  setForm({ ...form, intervalHours: Number(e.target.value) })
                }
              />
            </label>
            <label>
              Monthly plan price (AUD)
              <input
                type="number"
                min={1}
                max={1000}
                step={0.01}
                value={form.priceCents / 100}
                onChange={(e) =>
                  setForm({
                    ...form,
                    priceCents: Math.round(Number(e.target.value) * 100),
                  })
                }
              />
            </label>
            <label>
              Sender name
              <input
                value={form.senderName}
                onChange={(e) =>
                  setForm({ ...form, senderName: e.target.value })
                }
              />
            </label>
            <label>
              Sender email
              <input
                type="email"
                placeholder="hello@yourdomain.com.au"
                value={form.senderEmail}
                onChange={(e) =>
                  setForm({ ...form, senderEmail: e.target.value })
                }
              />
            </label>
            <label>
              Reply-to address
              <input
                type="email"
                value={form.replyTo}
                onChange={(e) => setForm({ ...form, replyTo: e.target.value })}
              />
            </label>
            <label>
              Sender business address
              <input
                value={form.senderAddress}
                onChange={(e) =>
                  setForm({ ...form, senderAddress: e.target.value })
                }
              />
            </label>
          </div>
          <label className="block-label">
            Email subject
            <input
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
            />
          </label>
          <label className="block-label">
            Email template
            <textarea
              rows={13}
              value={form.template}
              onChange={(e) => setForm({ ...form, template: e.target.value })}
            />
          </label>
          <p className="variable-help">
            Variables:{" "}
            {
              "{{business_name}}, {{website_url}}, {{score}}, {{improvements}}, {{preview_url}}, {{checkout_url}}, {{price}}, {{sender_name}}, {{sender_address}}, {{unsubscribe_url}}"
            }
          </p>
          <label className="auto-checkbox">
            <input
              type="checkbox"
              checked={form.sendingEnabled}
              onChange={(e) =>
                setForm({ ...form, sendingEnabled: e.target.checked })
              }
            />{" "}
            Automatically email qualified prospects with recorded contact
            permission
          </label>
          <p className="method-note">
            Sites at or above the cutoff are recorded and skipped before
            strategy/build. Eligible sites proceed automatically. Emails require
            a passing demo, a permitted recipient, configured sender, public
            preview hosting, email provider and Stripe. No per-message approval
            is required once these campaign controls are enabled.
          </p>
          <button className="primary" disabled={busy} onClick={save}>
            <Save size={14} /> Save campaign
          </button>
          {current?.lastError && (
            <p className="form-error">{current.lastError}</p>
          )}
          {current && (
            <p className="method-note">
              Discovery:{" "}
              {current.lastRun
                ? new Date(current.lastRun).toLocaleString("en-AU")
                : "Not run yet"}{" "}
              · Next search: {new Date(current.nextRun).toLocaleString("en-AU")}
            </p>
          )}
        </section>
      )}
      {tab === "Outreach" && (
        <section className="panel">
          <div className="panel-heading">
            <h2>Prepared emails & subscriptions</h2>
            <span className="eyebrow">ACCEPTED ≠ DELIVERED</span>
          </div>
          {messages.map((o) => (
            <div className="outreach-row" key={o.id}>
              <div>
                <b>{o.recipient}</b>
                <p>{o.subject}</p>
                <small>
                  {o.subscriptionStatus
                    ? `Subscription: ${o.subscriptionStatus}`
                    : "No subscription yet"}
                </small>
              </div>
              <div>
                <span
                  className={`badge ${o.state === "SENT" ? "completed" : o.state === "FAILED" || o.state === "UNCERTAIN" ? "failed" : ""}`}
                >
                  {o.state === "SENT"
                    ? "Provider accepted"
                    : o.state.toLowerCase()}
                </span>
                {o.blockers
                  .filter((x) => !x.startsWith("Message is"))
                  .map((b) => (
                    <small key={b}>{b}</small>
                  ))}
                {o.error && <small>{o.error}</small>}
              </div>
              <button className="text-btn" onClick={() => setEmail(o)}>
                View email <ArrowUpRight size={13} />
              </button>
            </div>
          ))}
          {!messages.length && (
            <div className="simple-empty">
              Emails are prepared automatically after a qualified demo has
              passed QA and a recipient is recorded.
            </div>
          )}
        </section>
      )}
      {tab === "Connections" && (
        <section className="panel tab-content">
          <h2>Connect the operating services.</h2>
          <p>
            <a href="/connections" style={{ textDecoration: "underline" }}>
              Open dedicated Stripe payment setup ↗
            </a>
          </p>
          <p>
            API keys stay on the VPS, encrypted at rest. Saved keys are never
            returned to the browser. Leave a secret blank to retain it.
            Environment variables override saved settings.
          </p>
          <div className="connection-statuses">
            {data &&
              [
                ["Resend email", data.connections.email],
                ["Stripe API", data.connections.stripe],
                ["Stripe webhook", data.connections.webhook],
                [
                  `Website discovery (${data.connections.searchProvider})`,
                  data.connections.search,
                ],
                ["Public HTTPS preview", data.connections.publicBaseReady],
              ].map(([label, ready]) => (
                <div key={String(label)}>
                  {ready ? <Check size={14} /> : <X size={14} />}
                  <span>{label}</span>
                  <small>{ready ? "Configured" : "Not configured"}</small>
                </div>
              ))}
          </div>
          <div className="automation-form">
            <label>
              Resend API key
              <input
                type="password"
                autoComplete="off"
                placeholder="re_…"
                value={connection.resendKey}
                onChange={(e) =>
                  setConnection({ ...connection, resendKey: e.target.value })
                }
              />
            </label>
            <label>
              Stripe restricted API key
              <input
                type="password"
                autoComplete="off"
                placeholder="rk_test_… or rk_live_…"
                value={connection.stripeKey}
                onChange={(e) =>
                  setConnection({ ...connection, stripeKey: e.target.value })
                }
              />
            </label>
            <label>
              Stripe webhook signing secret
              <input
                type="password"
                autoComplete="off"
                placeholder="whsec_…"
                value={connection.stripeWebhook}
                onChange={(e) =>
                  setConnection({
                    ...connection,
                    stripeWebhook: e.target.value,
                  })
                }
              />
            </label>
            <label>
              Anakin Search API key (primary provider)
              <input
                type="password"
                autoComplete="off"
                placeholder="ask_…"
                value={connection.anakinKey}
                onChange={(e) =>
                  setConnection({ ...connection, anakinKey: e.target.value })
                }
              />
            </label>
            <label>
              Brave Search API key
              <input
                type="password"
                autoComplete="off"
                placeholder="For scheduled business discovery"
                value={connection.braveKey}
                onChange={(e) =>
                  setConnection({ ...connection, braveKey: e.target.value })
                }
              />
            </label>
            <label>
              Public preview origin
              <input
                placeholder="https://preview.yourdomain.com"
                value={connection.publicBase}
                onChange={(e) =>
                  setConnection({ ...connection, publicBase: e.target.value })
                }
              />
            </label>
          </div>
          <p className="method-note">
            Stripe mode: {data?.connections.stripeMode}. Public routes require
            hosting; localhost links cannot be opened by prospects. Expose only
            /p/*, /api/public/*, /api/stripe/webhook and static assets through
            your public reverse proxy. Keep the operator dashboard private.
          </p>
          <h3>Stripe webhook</h3>
          <p>
            Endpoint:{" "}
            <code>
              {data?.connections.publicBase || "https://preview.yourdomain.com"}
              /api/stripe/webhook
            </code>
            <br />
            Subscribe to checkout.session.completed and
            customer.subscription.created / updated / deleted, invoice.paid,
            invoice.payment_failed, and checkout.session.async_payment_succeeded
            / failed. Payment success is confirmed server-side, never from a
            return URL.
          </p>
          <button
            className="primary"
            disabled={busy}
            onClick={() =>
              run(async () => {
                await api("/api/connections", connection);
                setConnection({
                  resendKey: "",
                  stripeKey: "",
                  stripeWebhook: "",
                  anakinKey: "",
                  braveKey: "",
                  publicBase: "",
                });
                setMessage(
                  "Connection settings saved. No email or payment was sent.",
                );
              })
            }
          >
            <Save size={14} /> Save connections
          </button>
        </section>
      )}
      {tab === "Activity" && (
        <section className="panel">
          <div className="panel-heading">
            <h2>Automation activity</h2>
          </div>
          {data?.logs.map((log) => (
            <div className="automation-log" key={log.id}>
              <span className="mono muted">
                {new Date(log.timestamp).toLocaleString("en-AU")}
              </span>
              <p>{log.message}</p>
              <span className="eyebrow">{log.severity}</span>
            </div>
          ))}
          {!data?.logs.length && (
            <div className="simple-empty">
              Campaign actions will appear here.
            </div>
          )}
        </section>
      )}
      {contact && (
        <div className="modal-overlay">
          <section className="modal" role="dialog" aria-modal="true">
            <button
              className="close-modal"
              onClick={() => setContact(null)}
              aria-label="Close contact editor"
            >
              <X size={17} />
            </button>
            <h2>{contact.name}</h2>
            <p>
              Public contacts are source evidence. Record the recipient and a
              valid permission basis before automated outreach.
            </p>
            {contact.phones?.map((c) => (
              <p key={c.phone}>
                <a href={`tel:${c.phone}`}>{c.phone}</a> ·{" "}
                <a href={c.sourceUrl} target="_blank" rel="noreferrer">
                  Source ↗
                </a>
              </p>
            ))}
            {contact.contacts.map((c) => (
              <p key={c.email} className="contact-source">
                <button
                  className="text-btn"
                  onClick={() =>
                    setContactForm({ ...contactForm, email: c.email })
                  }
                >
                  {c.email}
                </button>
                <a href={c.sourceUrl} target="_blank" rel="noreferrer">
                  Source ↗
                </a>
              </p>
            ))}
            <label>
              Recipient email
              <input
                type="email"
                value={contactForm.email}
                onChange={(e) =>
                  setContactForm({ ...contactForm, email: e.target.value })
                }
              />
            </label>
            <label>
              Permission basis
              <select
                value={contactForm.permission}
                onChange={(e) =>
                  setContactForm({ ...contactForm, permission: e.target.value })
                }
              >
                <option value="UNKNOWN">Unknown · do not send</option>
                <option value="EXPRESS">Express permission recorded</option>
                <option value="VERIFIED_BASIS">
                  Other verified permitted basis
                </option>
              </select>
            </label>
            <label>
              Permission evidence
              <textarea
                rows={4}
                placeholder="Record when and how permission was established, or the verified basis and supporting source."
                value={contactForm.permissionEvidence}
                onChange={(e) =>
                  setContactForm({
                    ...contactForm,
                    permissionEvidence: e.target.value,
                  })
                }
              />
            </label>
            <button
              className="primary"
              disabled={busy}
              onClick={() =>
                run(async () => {
                  await api(`/api/prospects/${contact.id}`, contactForm);
                  setContact(null);
                  setMessage(
                    "Recipient record saved. The worker will re-evaluate outreach eligibility.",
                  );
                })
              }
            >
              <ShieldCheck size={14} /> Save recipient record
            </button>
            {contact.email && (
              <button
                className="text-btn"
                onClick={() =>
                  run(async () => {
                    await api(`/api/prospects/${contact.id}`, {
                      action: "suppress",
                    });
                    setContact(null);
                    setMessage("Recipient suppressed.");
                  })
                }
              >
                Suppress this recipient
              </button>
            )}
          </section>
        </div>
      )}
      {email && (
        <div className="modal-overlay">
          <section className="modal email-modal">
            <button
              className="close-modal"
              onClick={() => setEmail(null)}
              aria-label="Close email preview"
            >
              <X size={17} />
            </button>
            <span className="eyebrow">EMAIL PREVIEW · {email.state}</span>
            <h2>{email.subject}</h2>
            <p>To: {email.recipient}</p>
            <pre>{email.text}</pre>
            <a
              className="primary"
              href={`/p/${email.token}`}
              target="_blank"
              rel="noreferrer"
            >
              Open recipient preview <ArrowUpRight size={14} />
            </a>
          </section>
        </div>
      )}
    </div>
  );
}
