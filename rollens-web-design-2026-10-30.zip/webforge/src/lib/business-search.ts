import { z } from "zod";

type Target = { niche: string; area: string; searchPage: number };
type Keys = { anakinKey: string; braveKey: string };
const Results = z
  .array(z.object({ url: z.string(), title: z.string().optional() }))
  .max(100);
const trades = [
  "electricians",
  "plumbers",
  "landscapers",
  "painters",
  "carpenters",
  "roofers",
  "cleaners",
  "mechanics",
  "builders",
  "air conditioning services",
];

export function businessQuery(c: Target) {
  if (!c.niche.trim() || !c.area.trim())
    throw new Error("Discovery needs a target niche and area");
  const batch = Math.abs(c.searchPage || 0) % 10;
  const niche = /^(trades and services|trades|services)$/i.test(c.niche.trim())
    ? trades[batch]
    : c.niche.trim();
  const focus = [
    "contact",
    "services",
    "local business",
    "about",
    "enquiries",
    "specialists",
    "independent",
    "bookings",
    "business contact",
    "service area",
  ][batch];
  return `${niche} ${c.area.trim()} official business website ${focus}`;
}

export async function searchBusinesses(
  source: "anakin" | "brave",
  c: Target,
  keys: Keys,
) {
  const key = source === "anakin" ? keys.anakinKey : keys.braveKey;
  const label = source === "anakin" ? "Anakin" : "Brave";
  if (!key)
    throw new Error(
      `${label} Search is not configured; add its API key in Connections`,
    );
  const query = businessQuery(c);
  let res: Response;
  try {
    res = await fetch(
      source === "anakin"
        ? "https://api.anakin.io/v1/search"
        : `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=20&offset=${Math.abs(c.searchPage || 0) % 10}&safesearch=strict`,
      {
        ...(source === "anakin"
          ? {
              method: "POST",
              body: JSON.stringify({ prompt: query, limit: 20 }),
            }
          : {}),
        headers:
          source === "anakin"
            ? {
                "X-API-Key": key,
                "Content-Type": "application/json",
                Accept: "application/json",
              }
            : { "X-Subscription-Token": key, Accept: "application/json" },
        redirect: "error",
        signal: AbortSignal.timeout(45000),
      },
    );
  } catch {
    throw new Error(
      `${label} Search could not be reached or timed out; retry on the next scheduled scan`,
    );
  }
  if (!res.ok) {
    await res.body?.cancel();
    const detail =
      res.status === 401 || res.status === 403
        ? "check the configured API key"
        : res.status === 402
          ? "credits or plan access unavailable"
          : res.status === 429
            ? "rate limit reached; retry on the next scheduled scan"
            : "provider request failed";
    throw new Error(`${label} Search returned HTTP ${res.status}: ${detail}`);
  }
  // Bound the upstream response and never include provider response text in logs.
  const reader = res.body?.getReader();
  if (!reader) throw new Error(`${label} Search returned an empty response`);
  const parts: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 2_000_000) {
        await reader.cancel();
        throw new Error("size");
      }
      parts.push(value);
    }
    const body = JSON.parse(Buffer.concat(parts).toString("utf8"));
    return Results.parse(
      source === "anakin" ? body.results : body.web?.results,
    ).slice(0, 20);
  } catch {
    throw new Error(
      `${label} Search returned an invalid or oversized response`,
    );
  }
}
