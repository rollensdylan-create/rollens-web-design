import { randomBytes, randomUUID } from "node:crypto";
import { domainToASCII } from "node:url";
import { isIP } from "node:net";
import { Resolver } from "node:dns/promises";
import { db } from "./db";
import { automationConfig } from "./automation-config";
import { SiteData, type SiteUser } from "./selfserve";
export const domainIpv4 = () => process.env.CUSTOM_DOMAIN_IPV4 || "85.208.48.9";
export type SiteDomain = {
  id: string;
  hostname: string;
  user_id: string;
  site_id: string;
  token: string;
  status: "pending" | "verified";
  checked_at: number | null;
  verified_at: number | null;
  last_error: string | null;
  created_at: number;
};
db.exec(`CREATE TABLE IF NOT EXISTS site_domains(id TEXT PRIMARY KEY,hostname TEXT NOT NULL,user_id TEXT NOT NULL REFERENCES site_users(id),site_id TEXT NOT NULL REFERENCES customer_sites(id),token TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',checked_at INTEGER,verified_at INTEGER,last_error TEXT,created_at INTEGER NOT NULL,UNIQUE(user_id,hostname));
CREATE UNIQUE INDEX IF NOT EXISTS site_domains_verified ON site_domains(hostname) WHERE status='verified';`);
export function normalizeDomain(input: string) {
  if (/[\\/:@?#\s]/.test(input.trim()))
    throw new Error(
      "Enter a hostname only, without https://, ports, paths or spaces.",
    );
  const hostname = domainToASCII(input.trim().replace(/\.$/, "").toLowerCase());
  const labels = hostname.split(".");
  const reserved = [
    "rollenswebdesign.space",
    "offerflow.lol",
    new URL(automationConfig().publicBase).hostname,
  ];
  if (
    !hostname ||
    hostname.length > 220 ||
    labels.length < 2 ||
    isIP(hostname) ||
    labels.some((l) => !/^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)$/.test(l)) ||
    !/[a-z]/.test(labels.at(-1)!) ||
    /\.(local|localhost|internal|invalid|test|example|onion)$/.test(hostname) ||
    reserved.some((h) => hostname === h || hostname.endsWith("." + h))
  )
    throw new Error(
      "Enter your own public domain, without https://, a port or a path. Rollens and Offerflow addresses are reserved.",
    );
  return hostname;
}
export function ownedSite(u: SiteUser, id: string) {
  const site = db
    .prepare("SELECT * FROM customer_sites WHERE id=? AND user_id=?")
    .get(id, u.id) as
    { id: string; slug: string; published: number; data: string } | undefined;
  if (!site) throw new Error("Website not found.");
  return site;
}
export function domainsFor(u: SiteUser, siteId: string) {
  const site = ownedSite(u, siteId);
  return (
    db
      .prepare(
        "SELECT * FROM site_domains WHERE user_id=? AND site_id=? ORDER BY created_at",
      )
      .all(u.id, siteId) as SiteDomain[]
  ).map((row) => ({
    ...row,
    serving: row.status === "verified" && !!site.published && !!u.enabled,
    txtName: `_rollens-verification.${row.hostname}`,
    txtValue: `rollens-verification=${row.token}`,
  }));
}
export function addDomain(u: SiteUser, siteId: string, input: string) {
  ownedSite(u, siteId);
  const hostname = normalizeDomain(input);
  if (
    (
      db
        .prepare(
          "SELECT count(*) n FROM site_domains WHERE user_id=? AND site_id=?",
        )
        .get(u.id, siteId) as { n: number }
    ).n >= 5
  )
    throw new Error(
      "A website can connect up to five hostnames. Remove an unused hostname first.",
    );
  if (
    db
      .prepare("SELECT id FROM site_domains WHERE user_id=? AND hostname=?")
      .get(u.id, hostname)
  )
    throw new Error(
      "This hostname is already in your account. Remove it before moving it to another site.",
    );
  const id = randomUUID();
  db.prepare(
    "INSERT INTO site_domains(id,hostname,user_id,site_id,token,created_at) VALUES(?,?,?,?,?,?)",
  ).run(
    id,
    hostname,
    u.id,
    siteId,
    randomBytes(24).toString("hex"),
    Date.now(),
  );
  return id;
}
export function removeDomain(u: SiteUser, id: string) {
  const result = db
    .prepare("DELETE FROM site_domains WHERE id=? AND user_id=?")
    .run(id, u.id);
  if (!result.changes) throw new Error("Domain not found.");
}
export type DomainDns = {
  resolveTxt: (h: string) => Promise<string[][]>;
  resolve4: (h: string) => Promise<string[]>;
  resolve6: (h: string) => Promise<string[]>;
};
const resolver = new Resolver({ timeout: 3000, tries: 1 });
const defaultDns: DomainDns = {
  resolveTxt: (h) => resolver.resolveTxt(h),
  resolve4: (h) => resolver.resolve4(h),
  resolve6: (h) => resolver.resolve6(h),
};
export class DomainDnsUnavailable extends Error {}
async function noData<T>(request: Promise<T>, empty: T): Promise<T> {
  try {
    return await request;
  } catch (e) {
    if (["ENODATA", "ENOTFOUND"].includes((e as { code: string }).code))
      return empty;
    throw new DomainDnsUnavailable(
      "DNS lookup timed out or is unavailable. Try again shortly.",
    );
  }
}
export async function checkDomainDns(
  row: SiteDomain,
  dns: DomainDns = defaultDns,
) {
  const [txt, ipv4, ipv6] = await Promise.all([
    noData(dns.resolveTxt(`_rollens-verification.${row.hostname}`), []),
    noData(dns.resolve4(row.hostname), []),
    noData(dns.resolve6(row.hostname), []),
  ]);
  if (!txt.some((v) => v.join("") === `rollens-verification=${row.token}`))
    throw new Error(
      "Ownership TXT record not found yet. Copy the exact name and value below, then allow time for DNS propagation.",
    );
  if (ipv4.length === 0 || ipv4.some((v) => v !== domainIpv4()))
    throw new Error(
      `Point this hostname to ${domainIpv4()} using an A record (or a CNAME to a hostname already pointing there). In Cloudflare choose DNS only, not Proxied.`,
    );
  if (ipv6.length)
    throw new Error(
      "Remove the AAAA record for this hostname. This service currently uses IPv4.",
    );
}
export async function verifyDomain(
  u: SiteUser,
  id: string,
  dns: DomainDns = defaultDns,
) {
  const row = db
    .prepare("SELECT * FROM site_domains WHERE id=? AND user_id=?")
    .get(id, u.id) as SiteDomain | undefined;
  if (!row) throw new Error("Domain not found.");
  ownedSite(u, row.site_id);
  try {
    await checkDomainDns(row, dns);
  } catch (e) {
    if (e instanceof DomainDnsUnavailable) {
      db.prepare(
        "UPDATE site_domains SET last_error=? WHERE id=? AND token=?",
      ).run(e.message, id, row.token);
      throw e;
    }
    db.prepare(
      "UPDATE site_domains SET status='pending',verified_at=NULL,checked_at=?,last_error=? WHERE id=? AND token=?",
    ).run(Date.now(), (e as Error).message, id, row.token);
    throw e;
  }
  db.exec("BEGIN IMMEDIATE");
  try {
    if (
      !db
        .prepare(
          "SELECT id FROM site_domains WHERE id=? AND user_id=? AND token=?",
        )
        .get(row.id, u.id, row.token)
    )
      throw new Error("Domain was disconnected while DNS was being checked.");
    // A pending claim cannot reserve a domain; a fresh DNS proof can supersede a previous account's mapping.
    db.prepare(
      "UPDATE site_domains SET status='pending',verified_at=NULL,last_error='Ownership was verified by another account.' WHERE hostname=? AND id<>? AND status='verified'",
    ).run(row.hostname, id);
    db.prepare(
      "UPDATE site_domains SET status='verified',verified_at=?,checked_at=?,last_error=NULL WHERE id=? AND user_id=? AND token=?",
    ).run(Date.now(), Date.now(), id, u.id, row.token);
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
export async function domainSite(
  hostname: string,
  dns: DomainDns = defaultDns,
) {
  let host: string;
  try {
    host = normalizeDomain(hostname);
  } catch {
    return null;
  }
  const row = db
    .prepare(
      "SELECT d.* FROM site_domains d JOIN customer_sites s ON s.id=d.site_id AND s.user_id=d.user_id JOIN site_users u ON u.id=d.user_id WHERE d.hostname=? AND d.status='verified' AND s.published=1 AND u.enabled=1 AND u.plan IS NOT NULL",
    )
    .get(host) as SiteDomain | undefined;
  if (!row) return null;
  if (!row.checked_at || Date.now() - row.checked_at > 3600000) {
    try {
      const user = db
        .prepare("SELECT * FROM site_users WHERE id=?")
        .get(row.user_id) as SiteUser;
      await verifyDomain(user, row.id, dns);
    } catch (e) {
      if (e instanceof DomainDnsUnavailable) throw e;
      return null;
    }
  }
  // Re-read after asynchronous DNS checks to honor removal, ownership transfers or billing changes.
  const current = db
    .prepare(
      "SELECT s.data FROM site_domains d JOIN customer_sites s ON s.id=d.site_id AND s.user_id=d.user_id JOIN site_users u ON u.id=d.user_id WHERE d.id=? AND d.status='verified' AND s.published=1 AND u.enabled=1 AND u.plan IS NOT NULL",
    )
    .get(row.id) as { data: string } | undefined;
  return current ? SiteData.parse(JSON.parse(current.data)) : null;
}
