import { randomUUID, randomBytes } from "node:crypto";
import { db, createMission, saveMission, getMission, event } from "./db";
import { z } from "zod";
export const CampaignSchema = z.object({
  name: z.string().trim().min(1).max(100),
  niche: z.string().max(100).default(""),
  area: z.string().max(100).default(""),
  threshold: z.number().int().min(1).max(100).default(60),
  dailyScans: z.number().int().min(1).max(100).default(10),
  dailyEmails: z.number().int().min(1).max(50).default(5),
  intervalHours: z.number().min(0.5).max(168).default(24),
  discoverySource: z
    .enum(["primary", "anakin", "brave", "osm", "manual"])
    .default("primary"),
  priceCents: z.number().int().min(100).max(100000).default(3300),
  senderName: z.string().max(100).default("WebForge"),
  senderEmail: z.string().email().or(z.literal("")).default(""),
  replyTo: z.string().email().or(z.literal("")).default(""),
  senderAddress: z.string().max(300).default(""),
  subject: z
    .string()
    .min(1)
    .max(200)
    .default("A website preview for {{business_name}}"),
  template: z
    .string()
    .min(30)
    .max(8000)
    .default(
      "Hi {{business_name}} team,\n\nI reviewed your website and put together an independent redesign preview, focused on {{improvements}}.\n\nYou can see it here: {{preview_url}}\n\nIf you like it, the website plan is {{price}} per month. You can review the plan and subscribe securely through Stripe on the preview page.\n\n{{sender_name}}\n{{sender_address}}\n\nNo further emails? {{unsubscribe_url}}",
    ),
  enabled: z.boolean().default(false),
  sendingEnabled: z.boolean().default(false),
});
export type CampaignInput = z.infer<typeof CampaignSchema>;
export type Campaign = CampaignInput & {
  id: string;
  createdAt: string;
  nextRun: string;
  lastRun: string | null;
  lastError: string | null;
  searchPage: number;
};
export type Prospect = {
  id: string;
  campaignId: string;
  name: string;
  url: string;
  domain: string;
  missionId: string | null;
  status: string;
  score: number | null;
  contacts: { email: string; sourceUrl: string }[];
  phones?: { phone: string; sourceUrl: string }[];
  discoverySourceUrl?: string;
  email: string | null;
  permission: "UNKNOWN" | "EXPRESS" | "VERIFIED_BASIS";
  permissionEvidence: string;
  createdAt: string;
  error: string | null;
};
export type Outbox = {
  id: string;
  campaignId: string;
  prospectId: string;
  missionId: string;
  recipient: string;
  token: string;
  subject: string;
  text: string;
  state:
    | "DRAFT"
    | "READY"
    | "SENDING"
    | "SENT"
    | "UNCERTAIN"
    | "FAILED"
    | "SUPPRESSED";
  providerId: string | null;
  attempts: number;
  firstAttemptAt?: string | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
  sentAt: string | null;
  priceCents: number;
  subscriptionStatus: string | null;
  customerId: string | null;
  subscriptionId: string | null;
  lastStripeEventAt: number;
  paymentStatus?: "pending" | "paid" | "failed";
  lastInvoiceEventAt?: number;
};
db.exec(`CREATE TABLE IF NOT EXISTS campaigns(id TEXT PRIMARY KEY,data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS prospects(id TEXT PRIMARY KEY,campaign_id TEXT NOT NULL REFERENCES campaigns(id),domain TEXT NOT NULL,mission_id TEXT,data TEXT NOT NULL,UNIQUE(campaign_id,domain));
CREATE TABLE IF NOT EXISTS outreach(id TEXT PRIMARY KEY,prospect_id TEXT NOT NULL UNIQUE REFERENCES prospects(id),recipient TEXT NOT NULL UNIQUE,token TEXT NOT NULL UNIQUE,state TEXT NOT NULL,updated_at TEXT NOT NULL,data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS suppressions(email TEXT PRIMARY KEY,created_at TEXT NOT NULL,reason TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stripe_events(id TEXT PRIMARY KEY,created INTEGER NOT NULL,type TEXT NOT NULL,processed_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS checkout_attempts(id INTEGER PRIMARY KEY AUTOINCREMENT,outreach_id TEXT NOT NULL,created_at TEXT NOT NULL,session_id TEXT,url TEXT);
CREATE TABLE IF NOT EXISTS automation_log(id INTEGER PRIMARY KEY AUTOINCREMENT,campaign_id TEXT,timestamp TEXT NOT NULL,message TEXT NOT NULL,severity TEXT NOT NULL);
`);
const decode = <T>(rows: any[]): T[] => rows.map((r) => JSON.parse(r.data));
export const campaigns = () =>
  decode<Campaign>(
    db.prepare("SELECT data FROM campaigns ORDER BY rowid DESC").all(),
  );
export const campaign = (id: string) =>
  campaigns().find((c) => c.id === id) || null;
export function saveCampaign(c: Campaign) {
  db.prepare(
    "INSERT INTO campaigns VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data",
  ).run(c.id, JSON.stringify(c));
}
export function createCampaign(input: unknown) {
  const data = CampaignSchema.parse(input);
  const c: Campaign = {
    ...data,
    id: randomUUID(),
    createdAt: new Date().toISOString(),
    nextRun: new Date().toISOString(),
    lastRun: null,
    lastError: null,
    searchPage: 0,
  };
  saveCampaign(c);
  return c;
}
export const prospects = (id?: string) =>
  decode<Prospect>(
    id
      ? db
          .prepare(
            "SELECT data FROM prospects WHERE campaign_id=? ORDER BY rowid DESC",
          )
          .all(id)
      : db.prepare("SELECT data FROM prospects ORDER BY rowid DESC").all(),
  );
export const prospect = (id: string) =>
  prospects().find((p) => p.id === id) || null;
export function saveProspect(p: Prospect) {
  db.prepare("UPDATE prospects SET mission_id=?,data=? WHERE id=?").run(
    p.missionId,
    JSON.stringify(p),
    p.id,
  );
}
export function importProspect(
  campaignId: string,
  input: {
    name: string;
    url: string;
    email?: string;
    permission?: Prospect["permission"];
    permissionEvidence?: string;
    discoverySourceUrl?: string;
  },
) {
  const c = campaign(campaignId);
  if (!c) throw new Error("Campaign not found");
  const url = new URL(input.url);
  url.hash = "";
  const domain = url.hostname.toLowerCase().replace(/^www\./, "");
  const existing = prospects(campaignId).find((p) => p.domain === domain);
  if (existing) return { prospect: existing, created: false };
  if (
    input.permission &&
    input.permission !== "UNKNOWN" &&
    (!input.email || !input.permissionEvidence?.trim())
  )
    throw new Error("Permission needs a recipient email and evidence");
  const p: Prospect = {
    id: randomUUID(),
    campaignId,
    name: input.name,
    url: url.href,
    domain,
    missionId: null,
    status: "PENDING",
    score: null,
    contacts: [],
    discoverySourceUrl: input.discoverySourceUrl,
    email: input.email?.toLowerCase() || null,
    permission: input.permission || "UNKNOWN",
    permissionEvidence: input.permissionEvidence || "",
    createdAt: new Date().toISOString(),
    error: null,
  };
  db.prepare("INSERT INTO prospects VALUES(?,?,?,?,?)").run(
    p.id,
    campaignId,
    domain,
    null,
    JSON.stringify(p),
  );
  return { prospect: p, created: true };
}
export function enqueueProspect(p: Prospect, c: Campaign) {
  const m = createMission(p.url, p.name, "live");
  m.automation = { campaignId: c.id, prospectId: p.id, threshold: c.threshold };
  saveMission(m);
  p.missionId = m.id;
  p.status = "QUEUED";
  saveProspect(p);
  return m;
}
export const outbox = () =>
  decode<Outbox>(
    db.prepare("SELECT data FROM outreach ORDER BY rowid DESC").all(),
  );
export const outreach = (id: string) =>
  outbox().find((o) => o.id === id) || null;
export const outreachByToken = (token: string) =>
  outbox().find((o) => o.token === token) || null;
export function saveOutreach(o: Outbox) {
  o.updatedAt = new Date().toISOString();
  db.prepare("UPDATE outreach SET state=?,updated_at=?,data=? WHERE id=?").run(
    o.state,
    o.updatedAt,
    JSON.stringify(o),
    o.id,
  );
}
export function addOutreach(
  p: Prospect,
  subject: string,
  text: string,
  token: string,
  priceCents: number,
) {
  const existing = outbox().find(
    (o) => o.prospectId === p.id || o.recipient === p.email?.toLowerCase(),
  );
  if (existing) return existing;
  const now = new Date().toISOString();
  const o: Outbox = {
    id: randomUUID(),
    campaignId: p.campaignId,
    prospectId: p.id,
    missionId: p.missionId!,
    recipient: p.email!.toLowerCase(),
    token,
    subject,
    text,
    state: "DRAFT",
    providerId: null,
    attempts: 0,
    firstAttemptAt: null,
    error: null,
    createdAt: now,
    updatedAt: now,
    sentAt: null,
    priceCents,
    subscriptionStatus: null,
    subscriptionId: null,
    customerId: null,
    lastStripeEventAt: 0,
  };
  db.prepare("INSERT INTO outreach VALUES(?,?,?,?,?,?,?)").run(
    o.id,
    o.prospectId,
    o.recipient,
    token,
    o.state,
    now,
    JSON.stringify(o),
  );
  return o;
}
export function suppressed(email: string) {
  return !!db
    .prepare("SELECT email FROM suppressions WHERE email=?")
    .get(email.toLowerCase());
}
export function suppress(email: string, reason = "Unsubscribed") {
  db.prepare("INSERT OR IGNORE INTO suppressions VALUES(?,?,?)").run(
    email.toLowerCase(),
    new Date().toISOString(),
    reason,
  );
  for (const o of outbox().filter(
    (o) => o.recipient === email.toLowerCase() && o.state !== "SENT",
  )) {
    o.state = "SUPPRESSED";
    o.error = reason;
    saveOutreach(o);
  }
}
export function token() {
  return randomBytes(32).toString("hex");
}
export function automationLog(
  campaignId: string | null,
  message: string,
  severity = "INFO",
) {
  db.prepare(
    "INSERT INTO automation_log(campaign_id,timestamp,message,severity) VALUES(?,?,?,?)",
  ).run(campaignId, new Date().toISOString(), message, severity);
}
export function automationLogs() {
  return db
    .prepare("SELECT * FROM automation_log ORDER BY id DESC LIMIT 100")
    .all();
}
export function reconcileProspect(missionId: string) {
  const m = getMission(missionId);
  if (!m?.automation) return;
  const p = prospect(m.automation.prospectId);
  if (!p) return;
  p.score = m.audit?.overallScore ?? null;
  p.contacts = (m.scan?.pages || [])
    .flatMap((page) =>
      page.emails.map((email) => ({
        email: email.toLowerCase(),
        sourceUrl: page.url,
      })),
    )
    .filter((c, i, a) => a.findIndex((x) => x.email === c.email) === i);
  p.phones = (m.scan?.pages || [])
    .flatMap((page) =>
      page.phones.map((phone) => ({ phone, sourceUrl: page.url })),
    )
    .filter((c, i, a) => a.findIndex((x) => x.phone === c.phone) === i);
  const previousStatus = p.status;
  p.status =
    m.status === "FAILED"
      ? "FAILED"
      : m.automation.qualified === false
        ? "FILTERED_OUT"
        : m.status === "COMPLETED"
          ? "DEMO_READY"
          : m.status;
  p.error = m.error;
  saveProspect(p);
  if (m.status === "COMPLETED" && previousStatus !== p.status)
    event(
      m.id,
      "COMPLETE",
      "AUTOMATION",
      "INFO",
      p.status === "FILTERED_OUT"
        ? "Source score above campaign cutoff · build skipped"
        : "Qualified demo ready for outreach preparation",
    );
}
