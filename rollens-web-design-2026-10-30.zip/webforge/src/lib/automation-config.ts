import { readConnections } from "./connections";
export const automationConfig = () => {
  const saved = readConnections();
  return {
    resendKey: process.env.RESEND_API_KEY || saved.resendKey || "",
    stripeKey: process.env.STRIPE_SECRET_KEY || saved.stripeKey || "",
    stripeWebhook:
      process.env.STRIPE_WEBHOOK_SECRET || saved.stripeWebhook || "",
    publicBase: (process.env.PUBLIC_BASE_URL || saved.publicBase || "").replace(
      /\/$/,
      "",
    ),
    anakinKey: process.env.ANAKIN_API_KEY || saved.anakinKey || "",
    braveKey: process.env.BRAVE_SEARCH_API_KEY || saved.braveKey || "",
  };
};
export function publicBaseReady(base: string) {
  try {
    const u = new URL(base);
    return (
      u.protocol === "https:" &&
      !["localhost", "127.0.0.1"].includes(u.hostname) &&
      !u.username &&
      !u.password &&
      !u.search &&
      !u.hash &&
      u.pathname === "/"
    );
  } catch {
    return false;
  }
}
export function connectionStatus() {
  const c = automationConfig();
  return {
    email: !!c.resendKey,
    stripe: !!c.stripeKey,
    webhook: !!c.stripeWebhook,
    search: !!(c.anakinKey || c.braveKey),
    searchProvider: c.anakinKey ? "anakin" : c.braveKey ? "brave" : "osm",
    publicBaseReady: publicBaseReady(c.publicBase),
    publicBase: c.publicBase,
    stripeMode: c.stripeKey.includes("_live_")
      ? "live"
      : c.stripeKey
        ? "test"
        : "not configured",
  };
}
