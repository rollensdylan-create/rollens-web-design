import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import Stripe from "stripe";
import { z } from "zod";
import { db } from "./db";
import { stripeClient } from "./billing";
import { automationConfig } from "./automation-config";
import { SITE_PLANS, type SitePlan } from "./site-plans";
export { SITE_PLANS };
db.exec(`CREATE TABLE IF NOT EXISTS site_content_locks(site_id TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS site_users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,created_at INTEGER NOT NULL,customer TEXT UNIQUE,subscription TEXT UNIQUE,plan TEXT,enabled INTEGER DEFAULT 0,checkout TEXT,checkout_url TEXT);
CREATE TABLE IF NOT EXISTS site_sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES site_users(id),expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS customer_sites(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES site_users(id),slug TEXT UNIQUE NOT NULL,data TEXT NOT NULL,published INTEGER DEFAULT 0,updated INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS site_catalog(plan TEXT PRIMARY KEY,price TEXT NOT NULL,product TEXT NOT NULL,mode TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS site_rate_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS site_billing_events(id TEXT PRIMARY KEY,created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS site_fulfilled_sessions(id TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS site_checkout_drafts(session_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,site_id TEXT NOT NULL,data TEXT NOT NULL,plan TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS site_checkout_locks(user_id TEXT PRIMARY KEY,created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS site_resets(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL);`);
export type SiteUser = {
  id: string;
  email: string;
  password: string;
  customer: string | null;
  subscription: string | null;
  plan: SitePlan | null;
  enabled: number;
  checkout: string | null;
  checkout_url: string | null;
};
db.exec(
  "INSERT OR IGNORE INTO site_content_locks SELECT id FROM customer_sites WHERE published=1",
);
const digest = (s: string) => createHash("sha256").update(s).digest("hex");
export function limit(key: string, max = 20, window = 3600) {
  const now = Date.now();
  db.prepare("DELETE FROM site_rate_limits WHERE expires<?").run(now);
  db.prepare(
    "INSERT INTO site_rate_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1",
  ).run(key, now + window * 1000);
  const r = db
    .prepare("SELECT count FROM site_rate_limits WHERE key=?")
    .get(key) as { count: number };
  if (r.count > max)
    throw new Error("Too many attempts. Please try again later.");
}
function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function authenticate(email: string, password: string, signup = false) {
  email = z.email().max(180).parse(email).toLowerCase();
  z.string().min(12).max(128).parse(password);
  const existing = db
    .prepare("SELECT * FROM site_users WHERE email=?")
    .get(email) as SiteUser | undefined;
  if (signup) {
    if (existing)
      throw new Error(
        "This email is already registered. Sign in or reset your password.",
      );
    const id = randomUUID();
    db.prepare(
      "INSERT INTO site_users(id,email,password,created_at) VALUES(?,?,?,?)",
    ).run(id, email, passwordHash(password), Date.now());
    return id;
  }
  const [salt, hash] = (
    existing?.password || `${"0".repeat(32)}:${"0".repeat(128)}`
  ).split(":");
  if (
    !timingSafeEqual(
      scryptSync(password, salt, 64),
      Buffer.from(hash, "hex"),
    ) ||
    !existing
  )
    throw new Error("Email or password is incorrect.");
  return existing.id;
}
export function sessionFor(id: string) {
  const token = randomBytes(32).toString("hex");
  db.prepare("DELETE FROM site_sessions WHERE expires<?").run(Date.now());
  db.prepare("INSERT INTO site_sessions VALUES(?,?,?)").run(
    digest(token),
    id,
    Date.now() + 30 * 86400000,
  );
  return token;
}
export function userFor(request: Request) {
  const token = request.headers
    .get("cookie")
    ?.split(";")
    .map((s) => s.trim())
    .find((s) => s.startsWith("rollens_session="))
    ?.slice(16);
  if (!token) return null;
  return db
    .prepare(
      "SELECT u.* FROM site_users u JOIN site_sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>?",
    )
    .get(digest(token), Date.now()) as SiteUser | undefined;
}
export function logout(request: Request) {
  const token = request.headers
    .get("cookie")
    ?.match(/(?:^|;\s*)rollens_session=([^;]+)/)?.[1];
  if (token)
    db.prepare("DELETE FROM site_sessions WHERE token=?").run(digest(token));
}
const safeImage = z
  .string()
  .url()
  .max(1000)
  .refine((x) => {
    const u = new URL(x);
    return u.protocol === "https:" && !u.username && !u.password;
  }, "Images must use HTTPS");
export const SiteData = z.object({
  name: z.string().trim().min(1).max(100),
  brief: z.string().trim().min(10).max(2000),
  email: z.union([z.email().max(180), z.literal("")]),
  phone: z.string().max(40),
  area: z.string().max(100),
  services: z.array(z.string().trim().min(1).max(150)),
  theme: z.number().int().min(0).max(2),
  personal: z.boolean(),
  gallery: z.array(safeImage).default([]),
  headline: z.string().max(150).default(""),
  tagline: z.string().max(300).default(""),
  seoTitle: z.string().max(120).default(""),
  seoDescription: z.string().max(300).default(""),
  branding: z.boolean().default(true),
});
type ExtraSiteFields =
  "headline" | "tagline" | "seoTitle" | "seoDescription" | "branding";
export type CustomerSiteData = Omit<z.infer<typeof SiteData>, ExtraSiteFields> &
  Partial<Pick<z.infer<typeof SiteData>, ExtraSiteFields>>;
export function sitesFor(id: string) {
  return (
    db
      .prepare(
        "SELECT *, EXISTS(SELECT 1 FROM site_content_locks l WHERE l.site_id=customer_sites.id) AS locked FROM customer_sites WHERE user_id=? ORDER BY updated DESC",
      )
      .all(id) as {
      id: string;
      slug: string;
      data: string;
      published: number;
      locked: number;
    }[]
  ).map((r) => ({ ...r, data: JSON.parse(r.data) }));
}
export function assertSitePlan(data: CustomerSiteData, key: SitePlan) {
  const p = SITE_PLANS[key];
  if (
    (p.services !== null && data.services.length > p.services) ||
    (p.gallery !== null && data.gallery.length > p.gallery)
  )
    throw new Error(
      `${p.name} is a text-focused plan. Choose Plus or Pro for galleries and unrestricted service content.`,
    );
  if (!p.seo && (data.seoTitle || data.seoDescription))
    throw new Error("Custom search metadata is available on Plus and Pro.");
  if (!p.removeBranding && data.branding === false)
    throw new Error("Removing Rollens branding is available on Plus and Pro.");
}
export function saveSite(u: SiteUser, input: unknown, id?: string) {
  const data = SiteData.parse(input);
  const plan = SITE_PLANS[u.plan || "starter"];
  // Drafts can explore premium features; plan checks happen before checkout and publication.
  if (u.plan) assertSitePlan(data, u.plan);
  const sites = sitesFor(u.id);
  if (id && !sites.find((s) => s.id === id))
    throw new Error("Website not found.");
  if (!id && sites.length >= plan.sites)
    throw new Error("Your plan’s website limit has been reached.");
  if (
    id &&
    !plan.edits &&
    db.prepare("SELECT site_id FROM site_content_locks WHERE site_id=?").get(id)
  )
    throw new Error(
      `${plan.name} includes draft editing only. Editing locks after first publication, including after unpublishing.`,
    );
  const siteId = id || randomUUID();
  const slug = id
    ? sites.find((s) => s.id === id)!.slug
    : `${
        data.name
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .slice(0, 45)
          .replace(/-$/, "") || "website"
      }-${randomBytes(4).toString("hex")}`;
  db.prepare(
    "INSERT INTO customer_sites VALUES(?,?,?,?,0,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,updated=excluded.updated",
  ).run(siteId, u.id, slug, JSON.stringify(data), Date.now());
  return siteId;
}
export function publish(u: SiteUser, id: string, published: boolean) {
  if (published && !u.enabled)
    throw new Error("An active paid subscription is required to publish.");
  const row = db
    .prepare("SELECT id FROM customer_sites WHERE id=? AND user_id=?")
    .get(id, u.id);
  if (!row) throw new Error("Website not found.");
  if (published) {
    const current = sitesFor(u.id).find((s) => s.id === id)!;
    assertSitePlan(SiteData.parse(current.data), u.plan || "starter");
  }
  if (published)
    db.prepare("INSERT OR IGNORE INTO site_content_locks VALUES(?)").run(id);
  db.prepare(
    "UPDATE customer_sites SET published=?,updated=? WHERE id=? AND user_id=?",
  ).run(published ? 1 : 0, Date.now(), id, u.id);
}
export function liveSite(slug: string) {
  const row = db
    .prepare(
      "SELECT s.data FROM customer_sites s JOIN site_users u ON u.id=s.user_id WHERE s.slug=? AND s.published=1 AND u.enabled=1",
    )
    .get(slug) as { data: string } | undefined;
  return row ? SiteData.parse(JSON.parse(row.data)) : null;
}
export function billingReady() {
  const c = automationConfig();
  return (
    process.env.SELF_SERVE_PAYMENTS_ENABLED === "true" &&
    !!(c.stripeKey && c.stripeWebhook && c.publicBase.startsWith("https://"))
  );
}
export async function ensureSiteCatalog(client: Stripe, plan: SitePlan) {
  const mode = automationConfig().stripeKey.includes("_live_")
    ? "live"
    : "test";
  const old = db
    .prepare("SELECT * FROM site_catalog WHERE plan=? AND mode=?")
    .get(plan, mode) as { price: string; product: string } | undefined;
  if (old) {
    const price = await client.prices.retrieve(old.price);
    if (
      price.active &&
      price.unit_amount === SITE_PLANS[plan].cents &&
      price.currency === "aud" &&
      price.recurring?.interval === "month"
    )
      return old;
  }
  const p = SITE_PLANS[plan];
  const product = old
    ? { id: old.product }
    : await client.products.create(
        {
          name: `Rollens ${p.name}`,
          description: `${p.sites} hosted website${p.sites > 1 ? "s" : ""}. ${p.gallery === null ? "No plan-based image or content quotas." : "Text-focused site, 3 service entries."} ${p.edits ? "Ongoing editing." : "Draft editing only; content locks after publication."}`,
          metadata: { rollens_plan: plan },
        },
        { idempotencyKey: `rollens-${mode}-${plan}-product-v1` },
      );
  const price = await client.prices.create(
    {
      product: product.id,
      currency: "aud",
      unit_amount: p.cents,
      recurring: { interval: "month" },
    },
    { idempotencyKey: `rollens-${mode}-${plan}-price-${p.cents}-v1` },
  );
  db.prepare("INSERT OR REPLACE INTO site_catalog VALUES(?,?,?,?)").run(
    plan,
    price.id,
    product.id,
    mode,
  );
  return { price: price.id, product: product.id };
}
export async function createCheckout(
  u: SiteUser,
  plan: SitePlan,
  client = stripeClient(),
) {
  db.prepare("DELETE FROM site_checkout_locks WHERE created<?").run(
    Date.now() - 180000,
  );
  try {
    db.prepare("INSERT INTO site_checkout_locks VALUES(?,?)").run(
      u.id,
      Date.now(),
    );
  } catch {
    throw new Error(
      "Checkout is already being prepared. Please wait a moment.",
    );
  }
  try {
    return await checkoutUnlocked(u, plan, client);
  } finally {
    db.prepare("DELETE FROM site_checkout_locks WHERE user_id=?").run(u.id);
  }
}
async function checkoutUnlocked(u: SiteUser, plan: SitePlan, client: Stripe) {
  u = db.prepare("SELECT * FROM site_users WHERE id=?").get(u.id) as SiteUser;
  if (!billingReady())
    throw new Error(
      "Payments are not enabled yet. Your draft is saved; please return shortly.",
    );
  if (u.enabled || u.subscription) {
    throw new Error(
      "Manage your existing subscription in Billing before starting another.",
    );
  }
  const latest = sitesFor(u.id)[0];
  if (!latest) throw new Error("Save a draft before subscribing.");
  const approved = JSON.stringify(SiteData.parse(latest.data));
  assertSitePlan(JSON.parse(approved), plan);
  if (u.checkout) {
    const old = await client.checkout.sessions.retrieve(u.checkout);
    const snapshot = db
      .prepare("SELECT * FROM site_checkout_drafts WHERE session_id=?")
      .get(old.id) as { site_id: string; data: string } | undefined;
    if (
      old.status === "open" &&
      old.metadata?.plan === plan &&
      old.url &&
      snapshot?.site_id === latest.id &&
      snapshot.data === approved
    )
      return old.url;
    if (old.status === "complete")
      throw new Error(
        "Payment confirmation is processing. Refresh your account shortly.",
      );
    if (old.status === "open") await client.checkout.sessions.expire(old.id);
  }
  const price = await ensureSiteCatalog(client, plan);
  const base = automationConfig().publicBase;
  const session = await client.checkout.sessions.create(
    {
      mode: "subscription",
      integration_identifier: `rollens_${randomBytes(8).toString("hex").replace(/[0-9]/g, "a")}`,
      customer_email: u.customer ? undefined : u.email,
      customer: u.customer || undefined,
      line_items: [{ price: price.price, quantity: 1 }],
      metadata: { site_user_id: u.id, plan, site_id: latest.id },
      subscription_data: { metadata: { site_user_id: u.id, plan } },
      success_url: `${base}/account?payment=processing`,
      cancel_url: `${base}/account?payment=cancelled`,
      billing_address_collection: "auto",
      custom_text: {
        submit: {
          message: SITE_PLANS[plan].edits
            ? "Your reviewed draft publishes after verified payment. Pro includes ongoing editing."
            : "Your reviewed draft publishes after verified payment. Editing locks on first publication; use Pro for ongoing edits.",
        },
      },
    },
    {
      idempotencyKey: `rollens-checkout-v2-${u.id}-${plan}-${digest(approved).slice(0, 20)}-${u.checkout || "initial"}`,
    },
  );
  if (!session.url) throw new Error("Checkout could not be opened.");
  db.prepare(
    "INSERT OR REPLACE INTO site_checkout_drafts VALUES(?,?,?,?,?)",
  ).run(session.id, u.id, latest.id, approved, plan);
  db.prepare("UPDATE site_users SET checkout=?,checkout_url=? WHERE id=?").run(
    session.id,
    session.url,
    u.id,
  );
  return session.url;
}
export async function portal(u: SiteUser, client = stripeClient()) {
  if (!u.customer) throw new Error("No billing account exists yet.");
  const upgrades = Object.entries(SITE_PLANS).filter(
    ([_, p]) => p.cents >= SITE_PLANS[u.plan || "starter"].cents,
  );
  const products = await Promise.all(
    upgrades.map(async ([key]) => {
      const catalog = await ensureSiteCatalog(client, key as SitePlan);
      return { product: catalog.product, prices: [catalog.price] };
    }),
  );
  const config = await client.billingPortal.configurations.create(
    {
      business_profile: {
        headline: "Manage your Rollens Web Design subscription",
      },
      features: {
        subscription_update:
          u.plan === "pro"
            ? { enabled: false }
            : {
                enabled: true,
                default_allowed_updates: ["price"],
                products,
                proration_behavior: "always_invoice",
              },
        customer_update: {
          enabled: true,
          allowed_updates: ["email", "address"],
        },
        invoice_history: { enabled: true },
        payment_method_update: { enabled: true },
        subscription_cancel: {
          enabled: true,
          mode: "at_period_end",
          cancellation_reason: {
            enabled: true,
            options: ["too_expensive", "missing_features", "other"],
          },
        },
      },
    },
    { idempotencyKey: `rollens-portal-config-v2-${u.plan || "starter"}` },
  );
  return (
    await client.billingPortal.sessions.create({
      customer: u.customer,
      configuration: config.id,
      return_url: `${automationConfig().publicBase}/account`,
    })
  ).url;
}
export async function reconcileSubscription(
  subscriptionId: string,
  client = stripeClient(),
) {
  const sub = await client.subscriptions.retrieve(subscriptionId, {
    expand: ["latest_invoice"],
  });
  const u = db
    .prepare("SELECT * FROM site_users WHERE subscription=?")
    .get(sub.id) as SiteUser | undefined;
  if (!u) return;
  const catalogRows = db.prepare("SELECT * FROM site_catalog").all() as {
    price: string;
    plan: SitePlan;
  }[];
  const item = sub.items.data[0];
  const plan = catalogRows.find((p) => p.price === item?.price.id)?.plan;
  if (!plan)
    throw new Error("Subscription price is not in the Rollens catalog.");
  const invoice = sub.latest_invoice as Stripe.Invoice | null;
  const enabled = sub.status === "active" && invoice?.status === "paid";
  db.prepare(
    "UPDATE site_users SET enabled=?,plan=?,subscription=? WHERE id=?",
  ).run(enabled ? 1 : 0, plan, sub.status === "canceled" ? null : sub.id, u.id);
}
let billingQueue: Promise<unknown> = Promise.resolve();
export async function applySiteBillingEvent(
  event: Stripe.Event,
  client = stripeClient(),
) {
  const task = billingQueue
    .catch(() => {})
    .then(() => applySiteBillingEventUnlocked(event, client));
  billingQueue = task;
  return task;
}
async function applySiteBillingEventUnlocked(
  event: Stripe.Event,
  client: Stripe,
) {
  if (db.prepare("SELECT id FROM site_billing_events WHERE id=?").get(event.id))
    return;
  const obj = event.data.object as any;
  const objectId = (v: any) => (typeof v === "string" ? v : v?.id);
  if (
    event.type === "checkout.session.completed" ||
    event.type === "checkout.session.async_payment_succeeded"
  ) {
    const u = db
      .prepare("SELECT * FROM site_users WHERE checkout=?")
      .get(obj.id) as SiteUser | undefined;
    if (u) {
      const s = await client.checkout.sessions.retrieve(obj.id);
      if (
        s.payment_status === "paid" &&
        s.status === "complete" &&
        objectId(s.subscription)
      ) {
        db.prepare(
          "UPDATE site_users SET customer=?,subscription=? WHERE id=?",
        ).run(objectId(s.customer), objectId(s.subscription), u.id);
        await reconcileSubscription(objectId(s.subscription), client);
        const first = !db
          .prepare("SELECT id FROM site_fulfilled_sessions WHERE id=?")
          .get(s.id);
        const count = db
          .prepare(
            "SELECT count(*) AS n FROM customer_sites WHERE user_id=? AND published=1",
          )
          .get(u.id) as { n: number };
        if (first && count.n === 0) {
          const snapshot = db
            .prepare(
              "SELECT * FROM site_checkout_drafts WHERE session_id=? AND user_id=?",
            )
            .get(s.id, u.id) as
            { site_id: string; data: string; plan: SitePlan } | undefined;
          if (!snapshot)
            throw new Error(
              "Approved checkout draft is missing; publication requires review.",
            );
          const current = db
            .prepare("SELECT * FROM site_users WHERE id=?")
            .get(u.id) as SiteUser;
          assertSitePlan(
            SiteData.parse(JSON.parse(snapshot.data)),
            current.plan!,
          );
          db.prepare(
            "UPDATE customer_sites SET data=?,published=1,updated=? WHERE id=? AND user_id=? AND EXISTS(SELECT 1 FROM site_users WHERE id=? AND enabled=1)",
          ).run(snapshot.data, Date.now(), snapshot.site_id, u.id, u.id);
        }
        db.prepare(
          "INSERT OR IGNORE INTO site_content_locks SELECT id FROM customer_sites WHERE user_id=? AND published=1",
        ).run(u.id);
        db.prepare(
          "INSERT OR IGNORE INTO site_fulfilled_sessions VALUES(?)",
        ).run(s.id);
      }
    }
  } else {
    const id = event.type.startsWith("customer.subscription.")
      ? obj.id
      : objectId(
          obj.parent?.subscription_details?.subscription || obj.subscription,
        );
    if (id) await reconcileSubscription(id, client);
  }
  db.prepare("INSERT OR IGNORE INTO site_billing_events VALUES(?,?)").run(
    event.id,
    event.created,
  );
}
export async function requestReset(email: string) {
  const u = db
    .prepare("SELECT id FROM site_users WHERE email=?")
    .get(email.toLowerCase()) as { id: string } | undefined;
  const c = automationConfig();
  if (!c.resendKey) throw new Error("Password reset email is not configured.");
  if (!u) return;
  const token = randomBytes(32).toString("hex");
  db.prepare("DELETE FROM site_resets WHERE expires<? OR user_id=?").run(
    Date.now(),
    u.id,
  );
  db.prepare("INSERT INTO site_resets VALUES(?,?,?)").run(
    digest(token),
    u.id,
    Date.now() + 1800000,
  );
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${c.resendKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "Rollens Web Design <hello@rollenswebdesign.space>",
      to: [email],
      subject: "Reset your Rollens password",
      text: `You requested a password reset. Open this link within 30 minutes:\n${c.publicBase}/account?reset=${token}\n\nIf this wasn't you, ignore this email.`,
    }),
  });
  if (!response.ok)
    throw new Error(
      "Reset email could not be delivered. Please try again later.",
    );
}
export function resetPassword(token: string, password: string) {
  z.string().min(12).max(128).parse(password);
  const r = db
    .prepare("SELECT user_id FROM site_resets WHERE token=? AND expires>?")
    .get(digest(token), Date.now()) as { user_id: string } | undefined;
  if (!r) throw new Error("Reset link has expired.");
  db.exec("BEGIN IMMEDIATE");
  try {
    db.prepare("UPDATE site_users SET password=? WHERE id=?").run(
      passwordHash(password),
      r.user_id,
    );
    db.prepare("DELETE FROM site_sessions WHERE user_id=?").run(r.user_id);
    db.prepare("DELETE FROM site_resets WHERE user_id=?").run(r.user_id);
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
