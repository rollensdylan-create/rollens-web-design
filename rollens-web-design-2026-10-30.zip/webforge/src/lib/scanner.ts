import * as cheerio from "cheerio";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { config } from "./config";
import { safeFetch, readLimited } from "./security";
import { workspace, artifact } from "./artifacts";
import { launchBrowser, publicContext } from "./browser";
import type { PageData, Scan } from "./types";
export function normalizePhone(input: string): string | null {
  let n = input.replace(/[^+\d]/g, "");
  if (n.startsWith("+61")) n = "0" + n.slice(3);
  else if (n.startsWith("61") && n.length === 11) n = "0" + n.slice(2);
  if (/^(?:0[2378]\d{8}|04\d{8}|1[38]00\d{6}|13\d{4}|[2-9]\d{7})$/.test(n))
    return n;
  return null;
}
export function blockedSource(
  html: string,
  status: number,
  text: string,
): string | undefined {
  if (status < 200 || status >= 300) return `HTTP ${status}`;
  if (
    (/sgcaptcha|cf-chl-|challenge-platform/i.test(html) ||
      /verify you are human|checking your browser|just a moment|access denied|complete.{0,20}captcha/i.test(
        text,
      )) &&
    text.length < 1500
  )
    return "Source returned a bot/security challenge";
  if (text.trim().length < 80)
    return "Source is an empty page or JavaScript/consent shell";
  return undefined;
}
export const isServiceLabel = (s: string) =>
  s.length > 3 &&
  s.length < 85 &&
  s.split(/\s+/).length <= 7 &&
  !/^(contact|about|welcome|home|menu|navigation|privacy|cookie|testimonials|reviews|follow|our team|opening|find us|read more|get |make use|see |learn |why |what |how |our services|services$|latest|request|book |call |enquire)/i.test(
    s,
  ) &&
  !/prices?|costs?|quote|newsletter|copyright|customer service|more than|company|years|experience|specialists/i.test(
    s,
  ) &&
  /repair|maintenan|install|electri|switchboard|lighting|plumb|drain|roof|paint|clean|garden|prun|mow|hedg|lawn|tree|landscap|mulch|weeding|pest|removal|carpet|detail|servic|brake|clutch|tyre|tire|wheel|engine|mechanic|inspect|diagnos|battery|batteries|transmission|suspension|exhaust|air.?condition|heating|cooling|solar|concret|fenc|deck|build|renovat|carpent|glaz|window|windscreen|locksmith|security|weld|rubbish|pressure|irrigat|turf|stump|gutter/i.test(
    s,
  );

export function parsePage(
  html: string,
  url: string,
  status = 200,
  responseMs = 0,
): PageData {
  const $ = cheerio.load(html);
  const structuredData: unknown[] = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      structuredData.push(JSON.parse($(el).text()));
    } catch {}
  });
  $("script,style,noscript").remove();
  const text = $("body")
    .clone()
    .find("br,p,div,section,h1,h2,h3,li,a")
    .prepend(" ")
    .append(" ")
    .end()
    .text()
    .replace(/\s+/g, " ");
  const structuredContacts: string[] = [];
  const walk = (v: unknown) => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === "object")
      for (const [k, x] of Object.entries(v)) {
        if ((k === "email" || k === "telephone") && typeof x === "string")
          structuredContacts.push(x);
        else if (typeof x === "object") walk(x);
      }
  };
  structuredData.forEach(walk);
  const localPhones = [
    ...text.matchAll(
      /(?:contact(?: us)?|phone|tel(?:ephone)?|call(?: us)?)\s*[:.]?\s*([2-9]\d{3}[ .-]?\d{4})(?!\d)/gi,
    ),
  ].map((m) => m[1]);
  const tel = $("a[href]")
    .toArray()
    .map((el) => $(el).attr("href") || "")
    .filter((h) => /^tel:/i.test(h))
    .map((h) => {
      try {
        return decodeURIComponent(h.slice(4).split("?")[0]);
      } catch {
        return "";
      }
    });
  const mailto = $("a[href]")
    .toArray()
    .flatMap((el) => {
      const href = $(el).attr("href") || "";
      if (!/^mailto:/i.test(href)) return [];
      try {
        return (
          decodeURIComponent(href.slice(7).split("?")[0]).match(
            /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,
          ) || []
        );
      } catch {
        return [];
      }
    });
  const links: { text: string; url: string }[] = [];
  $("a[href]").each((_, el) => {
    try {
      const u = new URL($(el).attr("href")!, url);
      if (["http:", "https:"].includes(u.protocol)) {
        u.hash = "";
        if (!links.some((l) => l.url === u.href))
          links.push({ text: $(el).text().trim().slice(0, 120), url: u.href });
      }
    } catch {}
  });
  const services = [
    ...new Set(
      [
        ...$("h2,h3,h4,h5,h6,p,li,span")
          .toArray()
          .filter((el) => $(el).find("a,h2,h3,h4,h5,h6,p,li,span").length === 0)
          .map((el) => $(el).text().replace(/\s+/g, " ").trim()),
        ...links
          .filter((l) => {
            try {
              return (
                new URL(l.url).hostname.replace(/^www\./, "") ===
                new URL(url).hostname.replace(/^www\./, "")
              );
            } catch {
              return false;
            }
          })
          .map((l) => l.text),
      ].filter(
        (s) =>
          isServiceLabel(s) &&
          s.toLowerCase().replace(/[^a-z0-9]/g, "") !==
            new URL(url).hostname
              .replace(/^www\./, "")
              .split(".")[0]
              .replace(/[^a-z0-9]/g, "") &&
          s.toLowerCase() !==
            $("title")
              .first()
              .text()
              .split(/\s[|–—-]\s/)[0]
              .trim()
              .toLowerCase(),
      ),
    ),
  ].slice(0, 18);
  return {
    url,
    title: $("title").first().text().trim(),
    description: $('meta[name="description"]').attr("content") || "",
    headings: $("h1,h2,h3")
      .toArray()
      .map((el) => $(el).text().trim())
      .filter(Boolean)
      .slice(0, 40),
    links,
    emails: [
      ...new Set([
        ...(text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []),
        ...mailto,
        ...structuredContacts.filter((s) => s.includes("@")),
      ]),
    ].slice(0, 6),
    phones: [
      ...new Set(
        [
          ...tel,
          ...localPhones,
          ...structuredContacts.filter((s) => !s.includes("@")),
          ...(text.match(
            /(?<![\d])(?:\+61[ .()-]*[23478]|0[23478]|1[38]00|13)(?:[ .()-]*\d){4,9}(?![\d])/g,
          ) || []),
        ]
          .map(normalizePhone)
          .filter((x): x is string => !!x),
      ),
    ].slice(0, 8),
    services,
    forms: $("form").length,
    buttons: $("button,a")
      .toArray()
      .map((el) => $(el).text().trim())
      .filter(
        (s) =>
          /book|contact|call|quote|enquir|get started/i.test(s) &&
          s.length < 100,
      )
      .slice(0, 10),
    imageCount: $("img").length,
    missingAlt: $("img:not([alt])").length,
    hasViewport: !!$('meta[name="viewport"]').length,
    h1Count: $("h1").length,
    htmlBytes: Buffer.byteLength(html),
    responseMs,
    status,
    structuredData,
    summary: $("main p,article p,section p,p")
      .toArray()
      .map((el) => $(el).text().replace(/\s+/g, " ").trim())
      .find(
        (s) =>
          s.length > 60 &&
          s.length < 650 &&
          !/cookie|privacy|copyright|javascript/i.test(s),
      ),
    text: text.trim().slice(0, 16000),
    blocked: blockedSource(html, status, text),
  };
}
export async function scanSite(
  id: string,
  url: string,
  emit: (s: string) => void,
): Promise<Scan> {
  const pages: PageData[] = [];
  const brokenLinks: string[] = [];
  const warnings: string[] = [];
  const pending = [{ url, depth: 0 }];
  const seen = new Set<string>();
  while (pending.length && seen.size < config.maxPages) {
    const target = pending.shift()!;
    if (seen.has(target.url)) continue;
    seen.add(target.url);
    emit(
      `Fetching page ${seen.size}/${config.maxPages}: ${new URL(target.url).pathname}`,
    );
    const start = Date.now();
    try {
      const response = await safeFetch(target.url);
      if (!response.ok) {
        brokenLinks.push(target.url);
        if (!pages.length)
          throw new Error(`Source returned HTTP ${response.status}`);
        continue;
      }
      if (
        !/text\/html|application\/xhtml/.test(
          response.headers.get("content-type") || "",
        )
      )
        continue;
      const html = await readLimited(response);
      await artifact(id, `scan/page-${pages.length + 1}.html`, html);
      let p = parsePage(html, target.url, response.status, Date.now() - start);
      if (
        p.blocked?.includes("JavaScript") ||
        (!p.blocked && !p.emails.length && !p.phones.length)
      ) {
        const browser = await launchBrowser();
        try {
          const ctx = await publicContext(browser);
          const page = await ctx.newPage();
          await page.goto(target.url, {
            waitUntil: "domcontentloaded",
            timeout: config.timeoutMs,
          });
          await page.waitForTimeout(1200);
          const rendered = await page.content();
          p = parsePage(
            rendered,
            target.url,
            response.status,
            Date.now() - start,
          );
          await artifact(
            id,
            `scan/page-${pages.length + 1}-rendered.html`,
            rendered,
          );
          await ctx.close();
        } finally {
          await browser.close();
        }
      }
      if (p.blocked) {
        if (!pages.length) throw new Error(p.blocked);
        warnings.push(`${target.url}: ${p.blocked}`);
        continue;
      }
      pages.push(p);
      if (target.depth < config.maxDepth) {
        for (const l of [...p.links].sort((a, b) => {
          const rank = (url: string) =>
            /contact/i.test(url)
              ? 3
              : /about/i.test(url)
                ? 2
                : /services/i.test(url)
                  ? 1
                  : 0;
          return rank(b.url + " " + b.text) - rank(a.url + " " + a.text);
        })) {
          if (
            new URL(l.url).hostname.replace(/^www\./, "") ===
              new URL(url).hostname.replace(/^www\./, "") &&
            !/\.(pdf|zip|png|jpg|mp4|docx|svg)(\?|$)/i.test(l.url) &&
            !seen.has(l.url)
          )
            pending.push({ url: l.url, depth: target.depth + 1 });
        }
      }
    } catch (e) {
      if (!pages.length) throw e;
      warnings.push(
        `Could not fetch ${target.url}: ${e instanceof Error ? e.message : "Fetch failed"}`,
      );
    }
  }
  if (!pages.length) throw new Error("No HTML pages could be scanned");
  const browser = await launchBrowser();
  const viewports: Scan["viewports"] = [];
  const screenshots: string[] = [];
  await mkdir(path.join(workspace(id), "screenshots"), { recursive: true });
  try {
    const ctx = await publicContext(browser);
    const page = await ctx.newPage();
    for (const width of [1440, 768, 390]) {
      emit(`Capturing ${width}px source screenshot`);
      await page.setViewportSize({ width, height: 1000 });
      const errors: string[] = [];
      const listener = (e: Error) => errors.push(e.message.slice(0, 200));
      page.on("pageerror", listener);
      try {
        await page.goto(url, {
          waitUntil: "domcontentloaded",
          timeout: config.timeoutMs,
        });
        await page.waitForTimeout(600);
        const overflow = await page.evaluate(
          () => document.documentElement.scrollWidth > window.innerWidth + 2,
        );
        const file = `screenshots/source-${width}.png`;
        await page.screenshot({
          path: path.join(workspace(id), file),
          fullPage: false,
          timeout: 10000,
        });
        screenshots.push(file);
        viewports.push({ width, overflow, errors });
      } catch (e) {
        throw new Error(
          `Browser scan failed at ${width}px: ${e instanceof Error ? e.message : "Unknown error"}`,
        );
      } finally {
        page.off("pageerror", listener);
      }
    }
    await ctx.close();
  } finally {
    await browser.close();
  }
  const scan: Scan = {
    pages,
    screenshots,
    viewports,
    brokenLinks,
    warnings,
    name: pages[0].title.split(/\s[|–—-]\s/)[0] || new URL(url).hostname,
  };
  await artifact(id, "scan/site-data.json", scan);
  return scan;
}
export function fixtureScan(): Scan {
  return {
    name: "Northline Electrical",
    pages: [
      parsePage(
        '<html><head><title>Northline Electrical</title></head><body><h1>Northline Electrical</h1><h2>Residential electrical</h2><h2>Switchboard upgrades</h2><h2>Lighting installation</h2><p>Licensed electricians serving Melbourne. Contact hello@example.test or 03 9000 1234.</p><img src="old.jpg"><a href="/contact">Contact us</a></body></html>',
        "https://northline.example.test",
      ),
    ],
    screenshots: [],
    viewports: [
      { width: 1440, overflow: false, errors: [] },
      { width: 768, overflow: false, errors: [] },
      { width: 390, overflow: true, errors: [] },
    ],
    brokenLinks: [],
    warnings: ["Development fixture: source measurements are simulated."],
  };
}
