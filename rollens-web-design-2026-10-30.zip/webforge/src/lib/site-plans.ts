export const SITE_PLANS = {
  starter: {
    name: "Starter",
    cents: 1999,
    sites: 1,
    services: 3,
    gallery: 0,
    edits: false,
    seo: false,
    removeBranding: false,
  },
  plus: {
    name: "Plus",
    cents: 3300,
    sites: 1,
    services: null,
    gallery: null,
    edits: false,
    seo: true,
    removeBranding: true,
  },
  pro: {
    name: "Pro",
    cents: 9900,
    sites: 10,
    services: null,
    gallery: null,
    edits: true,
    seo: true,
    removeBranding: true,
  },
} as const;
export type SitePlan = keyof typeof SITE_PLANS;
export function planFeatures(key: SitePlan) {
  const p = SITE_PLANS[key];
  return [
    p.sites === 1 ? "One hosted website" : `${p.sites} hosted websites`,
    p.gallery === null
      ? "No plan-based image or content quotas"
      : "Text-focused site · 3 service entries",
    p.seo
      ? "Custom search title & description"
      : "Automatic search title & description",
    p.removeBranding ? "Optional Rollens branding" : "Rollens footer credit",
    p.edits
      ? "Ongoing editing after publication"
      : "Draft editing · locks when published",
    "Connect your own domain · automatic HTTPS",
    "Hosting & three design styles",
  ];
}
