import path from "node:path";
import { readFile } from "node:fs/promises";
import { spawn } from "node:child_process";
import { artifact, workspace } from "./artifacts";
import { escapeHtml as e } from "./security";
import { launchBrowser } from "./browser";
import { prepareDemoAssets } from "./demo-assets";
import { config } from "./config";
import type { Mission, QA } from "./types";
export { renderEvidenceDemo as renderDemo } from "./demo-design";
import { renderEvidenceDemo as renderDemo } from "./demo-design";
import { sourceProblems } from "./source-quality";
export async function buildDemo(
  m: Mission,
  emit: (s: string) => void,
  prepare = prepareDemoAssets,
) {
  const assets = await prepare(m);
  if (m.mode === "live" && !assets.photos.length)
    throw new Error(
      "Design quality gate: no suitable source photography was found. Demo withheld for review.",
    );
  await artifact(m.id, "build/index.html", renderDemo(m, assets));
  if (config.agentMode === "opencode") await runAgent(m, false, emit);
  else
    emit(
      "Original static business template generated · no AI or OpenCode execution",
    );
  m.demo = {
    status: "BUILT",
    previewUrl: `/api/artifacts/${m.id}/build/index.html`,
    framework:
      config.agentMode === "opencode"
        ? "OpenCode HTML/CSS"
        : "Original HTML/CSS template",
    buildStatus: "READY_FOR_QA",
  };
  await artifact(m.id, "build/build-result.json", m.demo);
}
export async function runAgent(
  m: Mission,
  fix: boolean,
  emit: (s: string) => void,
) {
  if (!config.opencodePath || !config.opencodeModel)
    throw new Error(
      "OpenCode execution requires OPENCODE_PATH and OPENCODE_MODEL",
    );
  if (process.env.ALLOW_LOCAL_AGENT !== "1")
    throw new Error(
      "Local coding execution is disabled. Configure a sandbox wrapper as OPENCODE_PATH and set ALLOW_LOCAL_AGENT=1 after reviewing README.",
    );
  const task = await readFile(
    path.join(process.cwd(), "prompts", fix ? "fix.txt" : "build.txt"),
    "utf8",
  );
  await artifact(m.id, "build/context.json", {
    name: m.name,
    source: m.websiteUrl,
    scan: m.scan?.pages.map((p) => ({
      title: p.title,
      services: p.services,
      phones: p.phones,
      emails: p.emails,
    })),
    strategy: m.strategy,
    qa: fix ? m.qa : undefined,
  });
  await artifact(
    m.id,
    "build/AGENTS.md",
    "Use only this workspace. Edit index.html only. Do not access parent directories, secrets, external network or other projects. Do not run shell commands. Return when the HTML has been updated.\n",
  );
  emit("Starting configured OpenCode worker");
  m.usage.agentExecutions++;
  await new Promise<void>((resolve, reject) => {
    const child = spawn(
      config.opencodePath,
      [
        "run",
        "--standalone",
        "--format",
        "json",
        "--model",
        config.opencodeModel,
        task,
      ],
      {
        cwd: path.join(workspace(m.id), "build"),
        env: {
          NODE_ENV: "production",
          PATH: process.env.PATH,
          HOME:
            process.env.WEBFORGE_AGENT_HOME ||
            path.join(workspace(m.id), "agent-home"),
          OPENCODE_CONFIG_CONTENT: JSON.stringify({
            permission: {
              "*": "deny",
              read: "allow",
              edit: "allow",
              external_directory: "deny",
              bash: "deny",
              webfetch: "deny",
              websearch: "deny",
            },
          }),
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
    let output = "";
    let done = false;
    const timer = setTimeout(
      () => {
        child.kill("SIGTERM");
        setTimeout(() => child.kill("SIGKILL"), 2000).unref();
      },
      Math.min(config.maxRuntimeMs, 120000),
    );
    const collect = (chunk: Buffer) => {
      if (output.length < 100000) output += chunk.toString();
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.on("error", (err) => {
      clearTimeout(timer);
      if (!done) {
        done = true;
        reject(err);
      }
    });
    child.on("exit", (code) => {
      clearTimeout(timer);
      if (done) return;
      done = true;
      artifact(m.id, "events/agent-result.json", {
        exitCode: code,
        outputBytes: output.length,
        warning:
          "Raw agent output is withheld; it may contain private reasoning.",
      }).catch(() => {});
      if (code === 0) resolve();
      else
        reject(
          new Error(`OpenCode exited with status ${code ?? "terminated"}`),
        );
    });
  });
}
export async function qaDemo(
  m: Mission,
  emit: (s: string) => void,
): Promise<QA> {
  const html = await readFile(
    path.join(workspace(m.id), "build/index.html"),
    "utf8",
  );
  if (!html.includes("<html"))
    throw new Error("Demo is not a valid HTML document");
  const browser = await launchBrowser();
  const checks: QA["checks"] = [];
  const issues: string[] = sourceProblems(m.scan!);
  if(m.mode==="live"&&!html.includes("data:image/"))issues.push("Source photography is missing from the generated design");
  for (const p of m.scan!.pages) {
    for (const c of [...p.phones, ...p.emails])
      if (!html.includes(e(c)))
        issues.push(`Verified contact missing from demo: ${c}`);
  }
  if (/Here to help\.|Explore the services available from our team/.test(html))
    issues.push("Generic placeholder copy detected");
  try {
    const ctx = await browser.newContext({
      serviceWorkers: "block",
      acceptDownloads: false,
    });
    await ctx.routeWebSocket("**/*", (ws) => ws.close());
    await ctx.route("**/*", (route) =>
      route.request().url() === "https://webforge-preview.test/"
        ? route.fulfill({ contentType: "text/html", body: html })
        : route.abort(),
    );
    const page = await ctx.newPage();
    for (const width of [1440, 768, 390]) {
      emit(`Testing demo layout and actions at ${width}px`);
      await page.setViewportSize({ width, height: 1000 });
      const errors: string[] = [];
      const onError = (err: Error) => errors.push(err.message.slice(0, 200));
      page.on("pageerror", onError);
      await page.goto("https://webforge-preview.test/", { waitUntil: "load" });
      const result = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > innerWidth + 2,
        cta: !!document.querySelector(
          'a[href="#contact"],a[href^="tel:"],a[href^="mailto:"]',
        ),
        brokenImages: [...document.images].filter(
          (i) => !i.complete || !i.naturalWidth,
        ).length,
        brokenAnchors: [...document.querySelectorAll('a[href^="#"]')].filter(
          (a) =>
            a.getAttribute("href") !== "#" &&
            !document.getElementById(a.getAttribute("href")!.slice(1)),
        ).length,
      }));
      await page.screenshot({
        path: path.join(workspace(m.id), `screenshots/demo-${width}.png`),
      });
      page.off("pageerror", onError);
      checks.push({
        width,
        overflow: result.overflow,
        cta: result.cta,
        brokenImages: result.brokenImages,
        errors,
      });
      if (result.overflow) issues.push(`Horizontal overflow at ${width}px`);
      if (!result.cta) issues.push(`Missing primary CTA at ${width}px`);
      if (result.brokenImages) issues.push(`Broken images at ${width}px`);
      if (result.brokenAnchors)
        issues.push(`Broken section navigation at ${width}px`);
      if (errors.length) issues.push(`Runtime errors at ${width}px`);
    }
    await ctx.close();
  } finally {
    await browser.close();
  }
  const qa: QA = {
    status: issues.length ? "FAILED" : "PASSED",
    checks,
    issues,
  };
  await artifact(m.id, "qa/qa-results.json", qa);
  return qa;
}
