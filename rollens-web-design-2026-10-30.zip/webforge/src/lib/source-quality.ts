import { isServiceLabel } from "./scanner";
import type { Scan } from "./types";
export function sourceProblems(scan: Scan): string[] {
  const pages = scan.pages.filter((p) => !p.blocked);
  const problems: string[] = [];
  if (!pages.length)
    problems.push("Source is blocked or contains no usable pages");
  const services = [
    ...new Set(pages.flatMap((p) => p.services).filter(isServiceLabel)),
  ];
  const contacts = pages.flatMap((p) => [...p.emails, ...p.phones]);
  if (!services.length)
    problems.push("No verified service headings were found");
  if (!contacts.length)
    problems.push("No verified phone number or email was found");
  if (
    !pages.some(
      (p) => (p.text || p.description || p.headings.join(" ")).length >= 80,
    )
  )
    problems.push("Insufficient business content to build an accurate demo");
  return problems;
}
