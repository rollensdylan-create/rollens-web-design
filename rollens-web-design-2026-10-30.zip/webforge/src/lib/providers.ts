import { readFile } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
import { config } from "./config";
import type { Mission, Strategy } from "./types";
const StrategySchema = z.object({
  summary: z.string().max(2000),
  sections: z.array(z.string().max(100)).min(3).max(12),
  priorities: z.array(z.string().max(300)).max(12),
});
export interface AIProvider {
  generateStrategy(mission: Mission): Promise<Strategy>;
}
class DeterministicProvider implements AIProvider {
  async generateStrategy(m: Mission): Promise<Strategy> {
    return {
      provider: "Deterministic strategy · no AI call",
      summary: `Create a clear, responsive website for ${m.name}, prioritising the source audit findings and public business information.`,
      sections: ["Header", "Hero", "Services", "About", "Contact", "Footer"],
      priorities:
        m.audit?.findings.map((f) => f.recommendation).slice(0, 6) || [],
      generatedAt: new Date().toISOString(),
    };
  }
}
class CompatibleProvider implements AIProvider {
  async generateStrategy(m: Mission): Promise<Strategy> {
    if (!config.aiKey || !config.aiBaseUrl || !config.aiModel)
      throw new Error(
        "AI strategy requires AI_API_KEY, AI_BASE_URL and AI_MODEL",
      );
    const prompt = await readFile(
      path.join(process.cwd(), "prompts/strategy.txt"),
      "utf8",
    );
    const response = await fetch(
      `${config.aiBaseUrl.replace(/\/$/, "")}/chat/completions`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${config.aiKey}`,
          "Content-Type": "application/json",
        },
        signal: AbortSignal.timeout(45000),
        body: JSON.stringify({
          model: config.aiModel,
          max_tokens: 1200,
          messages: [
            { role: "system", content: prompt },
            {
              role: "user",
              content: JSON.stringify({
                name: m.name,
                findings: m.audit?.findings,
                services: m.scan?.pages[0].services,
              }),
            },
          ],
          response_format: { type: "json_object" },
        }),
      },
    );
    if (!response.ok)
      throw new Error(`AI provider returned HTTP ${response.status}`);
    const data = await response.json();
    const parsed = StrategySchema.parse(
      JSON.parse(data.choices?.[0]?.message?.content || ""),
    );
    m.usage.model = config.aiModel;
    m.usage.inputTokens += data.usage?.prompt_tokens || 0;
    m.usage.outputTokens += data.usage?.completion_tokens || 0;
    return {
      ...parsed,
      provider: `AI strategy · ${config.aiModel}`,
      generatedAt: new Date().toISOString(),
    };
  }
}
export function provider(): AIProvider {
  return config.aiProvider === "compatible"
    ? new CompatibleProvider()
    : new DeterministicProvider();
}
