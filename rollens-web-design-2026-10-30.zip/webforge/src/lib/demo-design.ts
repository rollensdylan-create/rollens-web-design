import * as cheerio from "cheerio";
import { isServiceLabel } from "./scanner";
import type { Mission } from "./types";
import type { DemoAssets } from "./demo-assets";
import { escapeHtml as e } from "./security";
import { sourceProblems } from "./source-quality";
function displayPhone(p: string) {
  return p.length === 10
    ? `${p.slice(0, p[1] === "4" ? 4 : 2)} ${p.slice(p[1] === "4" ? 4 : 2, p[1] === "4" ? 7 : 6)} ${p.slice(p[1] === "4" ? 7 : 6)}`
    : p.length === 8
      ? `${p.slice(0, 4)} ${p.slice(4)}`
      : p;
}
const sheet = `*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:#192b24;background:#f7f6f0;font:15px/1.65 Arial,sans-serif}a{color:inherit;text-decoration:none}button{font:inherit;cursor:pointer}img{display:block;width:100%;height:100%;object-fit:cover}h1,h2,h3,p{margin:0}a:focus-visible,summary:focus-visible{outline:3px solid #b8d58c;outline-offset:5px}.preview-note{background:#e8ecdf;color:#304333;padding:7px 20px;text-align:center;font-size:10px;letter-spacing:.4px}.container{max-width:1340px;margin:auto;padding:0 6%}.nav{display:flex;align-items:center;justify-content:space-between;gap:25px;padding:24px 0}.brand{font-weight:800;font-size:22px;letter-spacing:-.8px;line-height:1.15;max-width:40%;overflow-wrap:anywhere}.brand small{display:block;font-size:8px;letter-spacing:2px;margin-top:8px;font-weight:400}.nav nav{display:flex;align-items:center;gap:30px;font-size:12px}.btn{display:inline-flex;align-items:center;justify-content:space-between;gap:25px;padding:15px 23px;background:#233f30;color:white;font-size:12px;font-weight:700;border-radius:2px;white-space:nowrap}.btn.light{background:#fffef7;color:#24392c}.eyebrow{font-size:9px;font-weight:700;letter-spacing:2.2px;text-transform:uppercase}.section-title{font-size:clamp(35px,4vw,56px);font-weight:400;line-height:1.07;letter-spacing:-2px}.section-top{display:flex;justify-content:space-between;align-items:end;gap:30px;margin-bottom:38px}.section-top>p{max-width:320px;font-size:13px;opacity:.7}.section-top .eyebrow{margin-bottom:20px}.arrow-link{font-size:12px;text-decoration:underline;text-underline-offset:5px}.section{padding:85px 0}.contact-links a{display:block;overflow-wrap:anywhere}.contact-links .phone{font-size:clamp(27px,3vw,42px);letter-spacing:-1.5px}.contact-links .mail{font-size:15px;margin-top:10px}.footer{padding:30px 0;display:flex;align-items:center;justify-content:space-between;gap:20px;border-top:1px solid #31453633;font-size:10px}.evidence{font-size:10px;opacity:.6;padding-bottom:24px}.evidence summary{cursor:pointer}.evidence a{display:inline-block;margin:8px 16px 0 0;text-decoration:underline}.photo-caption{position:absolute;bottom:14px;left:18px;font-size:9px;letter-spacing:1px;color:white;z-index:2;text-shadow:0 1px 5px #000}.garden .brand{font:600 27px/1.05 Georgia,serif;letter-spacing:-1px}.garden .nav{padding:27px 0}.garden .hero{position:relative;min-height:640px;display:flex;align-items:center;isolation:isolate;color:white;margin:0 24px;border-radius:5px;overflow:hidden}.garden .hero .hero-photo{position:absolute;inset:0;z-index:-2}.garden .hero:after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#122b20d9 0%,#122b2077 55%,#122b2011);z-index:-1}.garden .hero-content{width:100%;max-width:1340px;margin:auto;padding:65px 6%}.garden h1{font:400 clamp(64px,7.2vw,100px)/.97 Georgia,serif;letter-spacing:-4px;max-width:700px;margin:24px 0}.garden h1 em{font-weight:400;color:#e5e9c7}.garden .hero-content>p{max-width:380px;font-size:15px;color:#f5f5e0d9;margin:25px 0 30px}.garden .hero-foot{position:absolute;bottom:25px;left:6%;right:6%;display:flex;justify-content:space-between;font-size:9px;letter-spacing:1.7px;gap:20px;border-top:1px solid #ffffff55;padding-top:15px}.garden .intro-strip{display:grid;grid-template-columns:180px 1fr;gap:50px;padding:35px 0;border-bottom:1px solid #31453633;align-items:center}.garden .intro-strip p{font:24px/1.35 Georgia,serif;letter-spacing:-.5px}.garden .section-title{font-family:Georgia,serif}.garden .services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.garden .service{background:#e8ebde;padding:26px;min-height:170px;display:flex;flex-direction:column;justify-content:space-between;position:relative;border-radius:3px}.garden .service:nth-child(2n){background:#f0eee3}.garden .service small{font-size:10px;color:#6e7c68}.garden .service h3{font:26px/1.15 Georgia,serif;letter-spacing:-.5px;max-width:85%;overflow-wrap:anywhere;margin-top:20px}.garden .service .arrow{position:absolute;right:22px;bottom:20px;font-size:25px;font-weight:300}.garden .service:hover{background:#dce3cb}.garden .about{display:grid;grid-template-columns:1fr 1fr;gap:85px;align-items:center;border-top:1px solid #31453633;padding-top:80px}.garden .about-photo{height:480px;position:relative;border-radius:180px 180px 3px 3px;overflow:hidden;background:#dce3cb}.garden .about-photo img{object-position:70% center}.garden .about-copy .eyebrow{margin-bottom:25px}.garden .about-copy h2{font:46px/1.08 Georgia,serif;letter-spacing:-1.5px;margin-bottom:25px}.garden .about-copy p{color:#687262;font-size:14px;line-height:1.9;margin-bottom:25px}.garden .contact{background:#203d2e;color:#f7f6ef;padding:65px 6%;margin-top:80px}.garden .contact-inner{max-width:1180px;margin:auto;display:grid;grid-template-columns:1.3fr 1fr;gap:70px;align-items:center}.garden .contact h2{font:50px/1.05 Georgia,serif;letter-spacing:-2px;margin:20px 0}.garden .contact p{font-size:13px;color:#c1d1ba}.garden .contact-links{border-top:1px solid #c1d1ba66;padding-top:25px}.garden .footer{border:0}.auto{background:#101c21;color:#f1f4ee}.auto .preview-note{background:#bfe675;color:#19271d}.auto .brand{font-size:20px;font-weight:900;text-transform:uppercase;letter-spacing:-.6px}.auto .brand small{color:#a4b1b3}.auto .nav{border-bottom:1px solid #ffffff22}.auto .btn{background:#bfe675;color:#14201d}.auto .hero{display:grid;grid-template-columns:1fr 1fr;gap:0;min-height:620px;padding:60px 0 55px;align-items:center;position:relative}.auto .hero-copy{position:relative;z-index:2;padding:20px 20px 35px 0}.auto .hero .eyebrow{color:#bfe675}.auto h1{font-size:clamp(62px,6.2vw,88px);font-weight:900;letter-spacing:-4px;line-height:.98;text-transform:uppercase;max-width:700px;margin:27px 0}.auto h1 em{font-style:italic;color:#bfe675}.auto .hero-copy>p{max-width:400px;color:#aab8b9;font-size:14px;line-height:1.8;margin:25px 0}.auto .hero-actions{display:flex;align-items:center;gap:22px;flex-wrap:wrap;margin-top:30px}.auto .hero-photo{height:100%}.auto .hero-visual{height:520px;position:relative;overflow:hidden;background:#283a3f}.auto .hero-visual img{object-position:60% center}.auto .hero-visual:after{content:'';position:absolute;inset:0;background:linear-gradient(0deg,#101c21b0,transparent 45%)}.auto .photo-label{position:absolute;left:25px;bottom:25px;right:25px;z-index:1;border-top:1px solid #ffffff66;padding-top:18px;display:flex;justify-content:space-between;font-size:10px;letter-spacing:1px}.auto .quick-services{display:flex;justify-content:space-between;gap:20px;padding:22px 0;border-top:1px solid #ffffff22;border-bottom:1px solid #ffffff22;font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase}.auto .quick-services span:before{content:'✳';color:#bfe675;margin-right:15px}.auto .services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:0}.auto .service{padding:27px 25px 30px;border:1px solid #ffffff22;min-height:170px;position:relative;margin:-1px 0 0 -1px}.auto .service small{font-size:10px;color:#94a4a8}.auto .service h3{font-size:20px;font-weight:500;line-height:1.25;margin-top:28px;max-width:85%;overflow-wrap:anywhere;text-transform:capitalize}.auto .service .arrow{position:absolute;right:23px;top:23px;color:#bfe675;font-size:22px}.auto .service:hover{background:#1b3036}.auto .about-band{background:#f1f1e9;color:#14292e;padding:75px 0}.auto .about-inner{display:grid;grid-template-columns:1fr 1fr;gap:70px;align-items:center}.auto .about-photo{height:380px;overflow:hidden;background:#cdd6ca}.auto .about-photo img{object-position:35% center}.auto .about-copy .eyebrow{color:#607568;margin-bottom:22px}.auto .about-copy p{color:#5b6b68;font-size:14px;line-height:1.9;margin:25px 0}.auto .contact{padding:80px 0;display:grid;grid-template-columns:1.2fr 1fr;gap:80px;align-items:center}.auto .contact .eyebrow{color:#bfe675}.auto .contact h2{font-size:58px;font-weight:800;letter-spacing:-3px;line-height:1.02;margin-top:25px}.auto .contact h2 em{color:#bfe675;font-style:normal}.auto .contact-links{border-top:1px solid #ffffff44;padding-top:25px}.auto .contact-links .mail{color:#aab8b9}.auto .footer{border-color:#ffffff22;color:#aab8b9}.no-photo{background:linear-gradient(130deg,#5d7968,#17382a)}.auto .no-photo{background:linear-gradient(130deg,#42555b,#19292f)}@media(min-width:1500px){.garden .hero-content{padding-left:80px}}@media(max-width:950px){.nav nav{gap:18px}.garden h1{font-size:80px}.garden .about{gap:40px}.garden .hero{min-height:600px}.auto h1{font-size:66px}.auto .hero{min-height:570px}.auto .hero-visual{height:470px}.auto .about-inner{gap:40px}}@media(max-width:700px){.container{padding:0 6%}.nav{padding:22px 0}.nav nav>a:not(.btn){display:none}.nav nav{gap:0}.brand{max-width:55%;font-size:18px!important}.brand small{font-size:7px!important;letter-spacing:1px}.nav .btn{padding:12px 15px;font-size:10px;gap:12px}.preview-note{font-size:8px;padding:7px 12px}.garden .hero{margin:0 10px;min-height:650px;align-items:flex-start}.garden .hero-content{padding:60px 6% 95px}.garden h1{font-size:66px;letter-spacing:-3px;line-height:1}.garden .hero:after{background:linear-gradient(90deg,#122b20e0,#122b2066)}.garden .hero-content>p{font-size:14px;max-width:300px}.garden .hero-photo img{object-position:65% center}.garden .hero-foot{font-size:7px;letter-spacing:.7px}.garden .intro-strip{grid-template-columns:1fr;gap:15px;padding:30px 0}.garden .intro-strip p{font-size:24px}.section{padding:55px 0}.section-top{display:block;margin-bottom:28px}.section-title{font-size:38px;letter-spacing:-1.5px}.section-top>p{margin-top:20px}.garden .services-grid,.auto .services-grid{grid-template-columns:repeat(2,1fr)}.garden .service{padding:20px;min-height:160px}.garden .service h3{font-size:22px;max-width:95%}.garden .service .arrow{font-size:18px;right:15px;bottom:10px}.garden .about{grid-template-columns:1fr;gap:35px;padding-top:50px}.garden .about-photo{height:330px}.garden .about-copy h2{font-size:39px}.garden .contact{margin-top:55px;padding:50px 6%}.garden .contact-inner{grid-template-columns:1fr;gap:25px}.garden .contact h2{font-size:43px}.auto .hero{grid-template-columns:1fr;padding:35px 0 0;gap:15px}.auto .hero-copy{padding:10px 0 20px}.auto h1{font-size:65px;letter-spacing:-3.5px}.auto .hero-copy>p{font-size:14px}.auto .hero-visual{height:330px;margin:0 -6.82%;width:auto}.auto .hero-visual img{object-position:center 45%}.auto .quick-services{flex-wrap:wrap;font-size:8px;gap:13px;margin-top:0;padding:22px 0}.auto .quick-services span:before{margin-right:7px}.auto .service{padding:23px 17px;min-height:160px}.auto .service h3{font-size:17px;max-width:95%;margin-top:35px}.auto .service .arrow{right:14px;top:15px}.auto .about-band{padding:50px 0}.auto .about-inner{grid-template-columns:1fr;gap:35px}.auto .about-photo{height:300px}.auto .about-copy .section-title{font-size:39px}.auto .contact{padding:55px 0;grid-template-columns:1fr;gap:30px}.auto .contact h2{font-size:47px;letter-spacing:-2px}.footer{align-items:flex-start;flex-direction:column;gap:10px;padding:25px 0}.evidence{font-size:9px}.contact-links .phone{font-size:34px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}`;
export function renderEvidenceDemo(
  m: Mission,
  assets: DemoAssets = { photos: [] },
  options: {
    customer?: boolean;
    personal?: boolean;
    theme?: number;
    area?: string;
    editor?: boolean;
    headline?: string;
    tagline?: string;
    seoTitle?: string;
    seoDescription?: string;
    branding?: boolean;
  } = {},
) {
  if (!m.scan) throw new Error("No source scan available");
  const problems = options.customer ? [] : sourceProblems(m.scan);
  if (problems.length) throw new Error(`Demo blocked: ${problems.join("; ")}`);
  const pages = m.scan.pages.filter((p) => !p.blocked);
  const services = options.customer
    ? pages.flatMap((p) => p.services)
    : [
        ...new Map(
          pages
            .flatMap((p) => p.services)
            .filter((s) => options.customer || isServiceLabel(s))
            .map((s) => [s.toLowerCase(), s]),
        ).values(),
      ].slice(0, options.customer ? undefined : 9);
  const phones = [...new Set(pages.flatMap((p) => p.phones))],
    emails = [...new Set(pages.flatMap((p) => p.emails))];
  const phone = phones[0],
    email = emails[0];
  const garden = /garden|landscap|tree|lawn/i.test(
    [m.name, ...services].join(" "),
  );
  const automotive =
    !options.personal &&
    /motor|auto|vehicle|mechanic|car |brake|tyre|windscreen/i.test(
      [m.name, ...services].join(" "),
    );
  const editorial = !automotive;
  const type = editorial ? "garden" : "auto";
  const personal = !!options.personal;
  const category = garden
    ? "GARDENS & OUTDOOR SPACES"
    : automotive
      ? "AUTOMOTIVE SERVICE & REPAIRS"
      : personal
        ? "SELECTED WORK & IDEAS"
        : "INDEPENDENT BUSINESS";
  const name = e(m.name);
  const action = phone
    ? `tel:${phone.replace(/[^+\d]/g, "")}`
    : email
      ? `mailto:${email}`
      : "#about";
  const summary =
    pages
      .map((p) => p.description)
      .find((s) => s.length > 45 && !/cookie|javascript|captcha/i.test(s)) ||
    pages.map((p) => p.summary).find(Boolean) ||
    "";
  const photo = (index: number, cls: string) => {
    const p = assets.photos[index] || assets.photos[0];
    return `<div class="${cls}${p ? "" : " no-photo"}">${p ? `<img src="${e(p.data)}" alt="${options.customer ? "Website gallery photograph" : garden ? "Garden imagery from the business’s current website" : "Automotive imagery from the business’s current website"}" ${index ? 'loading="lazy"' : 'fetchpriority="high"'}>` : ""}</div>`;
  };
  const serviceCards = services
    .map(
      (s, i) =>
        `<a class="service" href="${e(action)}"><small>${String(i + 1).padStart(2, "0")} / ${garden ? "GARDEN CARE" : automotive ? "WORKSHOP SERVICES" : personal ? "SELECTED WORK" : "SERVICES"}</small><h3>${e(s)}</h3><span class="arrow" aria-hidden="true">↗</span></a>`,
    )
    .join("");
  const links = `<div class="contact-links">${phones.map((p) => `<a class="phone" href="tel:${e(p.replace(/[^+\d]/g, ""))}">${e(displayPhone(p))} ↗</a>`).join("")}${emails.map((v) => `<a class="mail" href="mailto:${e(v)}">${e(v)} ↗</a>`).join("")}</div>`;
  const header = `${options.customer ? "" : `<div class="preview-note">Independent redesign concept · Not the official business website · ${m.mode === "fixture" ? "Development fixture" : "Owner review required"}</div>`}<div class="container"><header class="nav"><a class="brand" href="#top">${name}<small>${category}${options.area ? " / " + e(options.area) : ""}</small></a><nav><a href="#services">Services</a><a href="#about">Our story</a><a class="btn" href="${e(action)}">${garden ? "Let’s talk gardens" : automotive ? "Call the workshop" : "Get in touch"}<span>↗</span></a></nav></header></div>`;
  const footer = options.customer
    ? `<div class="container"><footer class="footer"><strong>© ${new Date().getFullYear()} ${name}</strong><a href="https://rollenswebdesign.space">Website by Rollens Web Design ↗</a></footer></div>`
    : `<div class="container"><footer class="footer"><strong>${name}</strong><a href="${e(m.websiteUrl)}" target="_blank" rel="noopener noreferrer">Visit the current website ↗</a><span>Independent concept by Rollens Web Design</span></footer><details class="evidence"><summary>Concept sources & owner review</summary><p>Business details and photography are drawn from the current source website. This is a design proposal, not an official business website. Photography and copy require owner approval before publication.</p>${pages.map((p, i) => `<a href="${e(p.url)}" target="_blank" rel="noopener noreferrer">Source page ${i + 1}</a>`).join("")}</details></div>`;
  const content = editorial
    ? `<main id="top"><section class="hero">${photo(0, "hero-photo")}<div class="hero-content"><div class="eyebrow">${name} / ${category}</div><h1>${garden ? "A little care.<br>A lot of <em>life.</em>" : personal ? "Your work.<br>Your <em>perspective.</em>" : "Your next project.<br>Starts <em>here.</em>"}</h1><p>${garden ? "A place to unwind. A garden to enjoy.<br>Explore the services that bring your outdoor space together." : e(summary.slice(0, 240))}</p><a class="btn light" href="${e(action)}">${garden ? "Talk about your garden" : "Let’s start a conversation"} <span>↗</span></a></div><div class="hero-foot"><span>${category}</span><a href="#services">EXPLORE WHAT WE DO ↓</a></div></section><div class="container"><div class="intro-strip"><div class="eyebrow">${garden ? "ROOM TO GROW" : personal ? "A PLACE OF YOUR OWN" : "LET’S GET STARTED"}</div><p>${garden ? "Your garden has potential.<br>Let’s find the right care for it." : personal ? "Explore the work.<br>Meet the person behind it." : "A clear idea.<br>A conversation to get it moving."}</p></div><section class="section" id="services"><div class="section-top"><div><div class="eyebrow">${garden ? "A LITTLE HELP OUTSIDE" : personal ? "WORK & INTERESTS" : "WHAT WE DO"}</div><h2 class="section-title">${garden ? "Good gardens.<br>Thoughtfully cared for." : personal ? "A closer look.<br>A different perspective." : "Find the right fit.<br>Take the next step."}</h2></div><p>${garden ? "From regular upkeep to a fresh start, explore the services listed by " + name + "." : "Explore what " + name + " has to offer."}</p></div><div class="services-grid">${serviceCards}</div></section><section class="about" id="about">${photo(1, "about-photo")}<div class="about-copy"><div class="eyebrow">MEET ${name}</div><h2>${garden ? "More time enjoying.<br>Less time tending." : "A little more<br>about " + name + "."}</h2><p>${e(summary)}</p><a class="arrow-link" href="${options.customer ? e(action) : e(m.websiteUrl)}" target="_blank" rel="noopener noreferrer">${options.customer ? "Get in touch" : "Get to know the business"} ↗</a></div></section></div><section class="contact" id="contact"><div class="contact-inner"><div><div class="eyebrow">${garden ? "LET’S MAKE SOMETHING GROW" : "LET’S TALK"}</div><h2>${garden ? "What does your<br>garden need?" : "Good things start<br>with a conversation."}</h2><p>${garden ? "Speak with the team about your outdoor space." : "Get in touch to discuss what you have in mind."}</p></div>${links}</div></section></main>`
    : `<main id="top"><div class="container"><section class="hero"><div class="hero-copy"><div class="eyebrow">${name} / AUTOMOTIVE CARE</div><h1>For the road<br><em>ahead.</em></h1><p>Servicing, repairs and a clear next step for your vehicle. Explore what ${name} can help with.</p><div class="hero-actions"><a class="btn" href="${e(action)}">${phone ? e(displayPhone(phone)) : "Contact the workshop"} <span>↗</span></a><a class="arrow-link" href="#services">Explore services</a></div></div><div class="hero-visual">${photo(0, "hero-photo")}<div class="photo-label"><span>AUTOMOTIVE SERVICE & REPAIRS</span><span>↓</span></div></div></section><div class="quick-services">${services
        .slice(0, 3)
        .map((s) => `<span>${e(s)}</span>`)
        .join(
          "",
        )}</div><section class="section" id="services"><div class="section-top"><div><div class="eyebrow">UNDER THE BONNET</div><h2 class="section-title">The right service.<br>The next step sorted.</h2></div><p>Explore the workshop’s services, then speak with the team about your vehicle.</p></div><div class="services-grid">${serviceCards}</div></section></div><section class="about-band" id="about"><div class="container about-inner">${photo(1, "about-photo")}<div class="about-copy"><div class="eyebrow">MEET ${name}</div><h2 class="section-title">The people behind<br>your next journey.</h2><p>${e(summary)}</p><a class="arrow-link" href="${options.customer ? e(action) : e(m.websiteUrl)}" target="_blank" rel="noopener noreferrer">${options.customer ? "Get in touch" : "More about the workshop"} ↗</a></div></div></section><div class="container"><section class="contact" id="contact"><div><div class="eyebrow">LET’S TALK ABOUT YOUR VEHICLE</div><h2>Good care starts<br>with a <em>conversation.</em></h2></div>${links}</section></div></main>`;
  let html = `<!doctype html><html lang="en-AU"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}${options.customer ? "" : " · Website concept"}</title><meta name="description" content="${e(summary.slice(0, 160))}"><style>${sheet}${options.customer ? `.customer.theme-1{background:#f5ece7;color:#4d2634}.customer.theme-1 .btn,.customer.theme-1 .contact{background:#542f3b}.customer.theme-1 .service{background:#ebdcd2}.customer.theme-2{background:#f1f2f8;color:#222a49}.customer.theme-2 h1,.customer.theme-2 h2,.customer.theme-2 h3,.customer.theme-2 .brand{font-family:Arial,sans-serif;font-weight:700}.customer.theme-2 .btn,.customer.theme-2 .contact{background:#263554}.customer.theme-2 .service{background:#e0e4ef}.customer .photo-gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:65px}.customer .photo-gallery img{aspect-ratio:4/3;border-radius:3px}@media(max-width:700px){.customer .photo-gallery{grid-template-columns:repeat(2,1fr)}}` : ""}</style></head><body class="${type} ${options.customer ? `customer theme-${options.theme || 0}` : ""}">${header}${content}${options.customer && assets.photos.length ? `<section class="container"><div class="photo-gallery">${assets.photos.map((p) => `<img src="${e(p.data)}" alt="${name} — gallery photograph" loading="lazy" referrerpolicy="no-referrer">`).join("")}</div></section>` : ""}${footer}</body></html>`;
  if (options.customer) {
    const $ = cheerio.load(html);
    if (options.headline?.trim()) $("h1").first().text(options.headline);
    if (options.tagline?.trim())
      $(".hero-content>p,.hero-copy>p").first().text(options.tagline);
    if (options.seoTitle?.trim()) $("title").text(options.seoTitle);
    if (options.seoDescription?.trim())
      $('meta[name="description"]').attr("content", options.seoDescription);
    if (options.branding === false) $(".footer a").remove();
    $("head").append(
      "<style>h1{white-space:pre-line}.customer .about-photo.no-photo{display:none}.customer .about:has(.about-photo.no-photo),.customer .about-inner:has(.about-photo.no-photo){grid-template-columns:1fr;gap:0}.customer .about-copy{max-width:780px}</style>",
    );
    if (options.editor) {
      $(".brand").first().attr("data-edit-field", "name");
      $("h1").first().attr("data-edit-field", "headline");
      $(".hero-content>p,.hero-copy>p")
        .first()
        .attr("data-edit-field", "tagline");
      $(".about-copy>p").first().attr("data-edit-field", "brief");
      $(".service h3").each((i, el) => {
        $(el).attr("data-edit-field", `services.${i}`);
      });
      $(".phone").attr("data-edit-field", "phone");
      $(".mail").attr("data-edit-field", "email");
      $(".hero-photo,.photo-gallery img").attr("data-edit-field", "gallery");
    }
    html = $.html();
  }
  return html;
}
