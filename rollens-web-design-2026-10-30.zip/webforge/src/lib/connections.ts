import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
  renameSync,
} from "node:fs";
import path from "node:path";
import { randomBytes, createCipheriv, createDecipheriv } from "node:crypto";
import { ROOT } from "./config";
import { z } from "zod";
const file = path.join(ROOT, "connections.enc");
const keyFile = path.join(ROOT, "connections.key");
export const ConnectionSchema = z.object({
  resendKey: z.string().max(300).optional(),
  stripeKey: z.string().max(300).optional(),
  stripeWebhook: z.string().max(300).optional(),
  publicBase: z.string().max(300).optional(),
  anakinKey: z.string().max(300).optional(),
  braveKey: z.string().max(300).optional(),
});
export type Connections = z.infer<typeof ConnectionSchema>;
export function readConnections(): Connections {
  if (!existsSync(file)) return {};
  const key = readFileSync(keyFile);
  const b = Buffer.from(readFileSync(file, "utf8"), "base64");
  const decipher = createDecipheriv("aes-256-gcm", key, b.subarray(0, 12));
  decipher.setAuthTag(b.subarray(12, 28));
  return JSON.parse(
    Buffer.concat([
      decipher.update(b.subarray(28)),
      decipher.final(),
    ]).toString(),
  );
}
export function writeConnections(input: unknown) {
  const next = ConnectionSchema.parse(input);
  for (const [name, value] of Object.entries(next)) {
    if (!value) delete next[name as keyof Connections];
    else if (/[\r\n]/.test(value))
      throw new Error("Configuration values must be single-line");
  }
  if (next.publicBase) {
    const u = new URL(next.publicBase);
    if (
      u.protocol !== "https:" ||
      u.username ||
      u.password ||
      u.pathname !== "/" ||
      u.search ||
      u.hash
    )
      throw new Error("Public origin must be an HTTPS origin with no path");
    next.publicBase = u.origin;
  }
  if (next.stripeKey && !/^(sk|rk)_(test|live)_/.test(next.stripeKey))
    throw new Error("Use a Stripe secret or restricted API key");
  if (next.stripeWebhook && !next.stripeWebhook.startsWith("whsec_"))
    throw new Error("Use a Stripe webhook signing secret");
  const all = { ...readConnections(), ...next };
  mkdirSync(ROOT, { recursive: true });
  if (!existsSync(keyFile))
    writeFileSync(keyFile, randomBytes(32), { mode: 0o600, flag: "wx" });
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", readFileSync(keyFile), iv);
  const data = Buffer.concat([
    cipher.update(JSON.stringify(all)),
    cipher.final(),
  ]);
  writeFileSync(
    file + ".tmp",
    Buffer.concat([iv, cipher.getAuthTag(), data]).toString("base64"),
    { mode: 0o600 },
  );
  renameSync(file + ".tmp", file);
}
