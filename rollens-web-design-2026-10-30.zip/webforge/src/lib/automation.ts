import {
  campaigns,
  campaign,
  saveCampaign,
  prospects,
  saveProspect,
  importProspect,
  enqueueProspect,
  reconcileProspect,
  outbox,
  saveOutreach,
  automationLog,
} from "./automation-store";
import { getMission } from "./db";
import { validateUrl } from "./security";
import { automationConfig } from "./automation-config";
import { prepareOutreach, dispatchOne } from "./outreach";
import { searchBusinesses } from "./business-search";
import { osmMelbourneLeads } from "./osm-discovery";
export function recoverEmailHandoffs() {
  for (const o of outbox().filter((o) => o.state === "SENDING")) {
    o.state = "UNCERTAIN";
    o.error =
      "Worker restarted during provider handoff. Verify provider status before resending.";
    saveOutreach(o);
  }
}
const excluded = [
  "facebook.com",
  "instagram.com",
  "youtube.com",
  "google.com",
  "yelp.com",
  "yellowpages.com.au",
  "linkedin.com",
  "tripadvisor.com",
  "wikipedia.org",
];
export async function discover(c: ReturnType<typeof campaigns>[number]) {
  if (c.discoverySource === "manual") {
    automationLog(
      c.id,
      "Imported website queue checked; no search provider used",
    );
    return;
  }
  const config = automationConfig();
  const source =
    c.discoverySource === "primary"
      ? config.anakinKey
        ? "anakin"
        : config.braveKey
          ? "brave"
          : "osm"
      : c.discoverySource;
  if (source === "osm") {
    if (
      !/^melbourne(?:, victoria)?$/i.test(c.area.trim()) ||
      !/^(trades and services|trades|services)$/i.test(c.niche.trim())
    )
      throw new Error(
        "Free OpenStreetMap discovery currently supports Melbourne trades and services only",
      );
    const leads = await osmMelbourneLeads();
    let added = 0;
    let rejected = 0;
    for (const lead of leads) {
      try {
        await validateUrl(lead.url);
        if (importProspect(c.id, lead).created) added++;
      } catch {
        rejected++;
      }
    }
    automationLog(
      c.id,
      `OpenStreetMap cached discovery: ${added} new domains, ${rejected} invalid targets skipped. © OpenStreetMap contributors, ODbL: https://www.openstreetmap.org/copyright`,
    );
    return;
  }
  const results = await searchBusinesses(source, c, config);
  let added = 0;
  for (const r of results) {
    try {
      const u = new URL(r.url);
      if (
        excluded.some((d) => u.hostname === d || u.hostname.endsWith("." + d))
      )
        continue;
      await validateUrl(u.href);
      const p = importProspect(c.id, {
        name: String(r.title || u.hostname)
          .split(/\s[|–—]\s/)[0]
          .slice(0, 100),
        url: u.origin,
        discoverySourceUrl: u.href,
      });
      if (p.created) added++;
    } catch {}
  }
  automationLog(
    c.id,
    `${source === "anakin" ? "Anakin" : "Brave"} discovery search finished: ${added} new business domains`,
  );
}
export async function automationTick() {
  for (let c of campaigns()) {
    const due = c.enabled && Date.parse(c.nextRun) <= Date.now();
    if (due) {
      try {
        await discover(c);
        c.lastError = null;
      } catch (e) {
        c.lastError = e instanceof Error ? e.message : "Discovery failed";
        automationLog(c.id, c.lastError, "ERROR");
      }
      const latest = campaign(c.id);
      if (!latest) continue;
      latest.lastError = c.lastError;
      if (!c.lastError) latest.searchPage = ((c.searchPage || 0) + 1) % 10;
      latest.lastRun = new Date().toISOString();
      latest.nextRun = new Date(
        Date.now() + latest.intervalHours * 3600000,
      ).toISOString();
      saveCampaign(latest);
      c = latest;
    }
    if (!c.enabled || !due) continue;
    const day = new Date().toISOString().slice(0, 10);
    let count = prospects(c.id).filter(
      (p) => p.missionId && getMission(p.missionId)?.createdAt.startsWith(day),
    ).length;
    for (const p of prospects(c.id)
      .filter((p) => p.status === "PENDING")
      .reverse()) {
      if (count >= c.dailyScans) break;
      try {
        await validateUrl(p.url);
        const latest = campaign(c.id);
        if (!latest?.enabled) break;
        enqueueProspect(p, latest);
        count++;
        automationLog(c.id, `Queued website scan for ${p.name}`);
      } catch (e) {
        p.status = "FAILED";
        p.error = e instanceof Error ? e.message : "Invalid website";
        saveProspect(p);
      }
    }
  }
  for (const p of prospects().filter((p) => p.missionId)) {
    const m = getMission(p.missionId!);
    if (!m) continue;
    const expected =
      m.status === "COMPLETED"
        ? m.automation?.qualified === false
          ? "FILTERED_OUT"
          : "DEMO_READY"
        : m.status;
    if (p.status !== expected) reconcileProspect(m.id);
    const current = prospects(p.campaignId).find((x) => x.id === p.id)!;
    const c = campaigns().find((c) => c.id === p.campaignId);
    if (c && current.status === "DEMO_READY") await prepareOutreach(current, c);
  }
  for (const o of outbox().filter((o) =>
    ["DRAFT", "READY"].includes(o.state),
  )) {
    if (
      o.attempts > 0 &&
      Date.now() - Date.parse(o.updatedAt) <
        Math.min(3600, 30 * 2 ** o.attempts) * 1000
    )
      continue;
    await dispatchOne(o);
  }
}
