import path from "node:path";
export const ROOT = path.resolve(
  /* turbopackIgnore: true */ process.env.WEBFORGE_DATA_DIR || ".data",
);
export const DEFAULT_WEIGHTS = {
  design: 15,
  mobile: 15,
  conversion: 20,
  trust: 10,
  seo: 15,
  accessibility: 10,
  performance: 15,
};
function bounded(key: string, fallback: number, min: number, max: number) {
  const raw = process.env[key];
  const n = raw === undefined ? fallback : Number(raw);
  if (!Number.isFinite(n)) throw new Error(`${key} must be a finite number`);
  return Math.min(max, Math.max(min, Math.floor(n)));
}
function auditWeights() {
  if (!process.env.AUDIT_WEIGHTS) return DEFAULT_WEIGHTS;
  const input = JSON.parse(process.env.AUDIT_WEIGHTS);
  const values = { ...DEFAULT_WEIGHTS };
  for (const key of Object.keys(values) as (keyof typeof values)[]) {
    if (
      typeof input[key] !== "number" ||
      !Number.isFinite(input[key]) ||
      input[key] < 0
    )
      throw new Error(`AUDIT_WEIGHTS requires nonnegative ${key}`);
    values[key] = input[key];
  }
  if (Object.values(values).reduce((a, b) => a + b, 0) <= 0)
    throw new Error("AUDIT_WEIGHTS must have a positive total");
  return values;
}
export const config = {
  maxPages: bounded("MAX_PAGES", 4, 1, 10),
  timeoutMs: bounded("SCAN_TIMEOUT_MS", 20000, 3000, 60000),
  maxDepth: bounded("MAX_DEPTH", 1, 0, 3),
  maxFixAttempts: bounded("MAX_FIX_ATTEMPTS", 1, 0, 3),
  maxRuntimeMs: bounded("MAX_MISSION_RUNTIME_MS", 180000, 30000, 600000),
  weights: auditWeights(),
  aiProvider: process.env.AI_PROVIDER || "deterministic",
  aiModel: process.env.AI_MODEL || "",
  aiBaseUrl: process.env.AI_BASE_URL || "",
  aiKey: process.env.AI_API_KEY || "",
  agentMode: process.env.AGENT_MODE || "template",
  opencodePath: process.env.OPENCODE_PATH || "",
  opencodeModel: process.env.OPENCODE_MODEL || "",
  token: process.env.WEBFORGE_ACCESS_TOKEN || "",
};
