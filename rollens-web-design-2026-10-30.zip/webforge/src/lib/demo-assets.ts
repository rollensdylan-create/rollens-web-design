import { createHash } from "node:crypto";
import * as cheerio from "cheerio";
import { readFile } from "node:fs/promises";
import { safeFetch } from "./security";
import { workspace, artifact } from "./artifacts";
import type { Mission } from "./types";
export type DemoAssets = {
  photos: { data: string; source: string; alt: string }[];
};
export async function prepareDemoAssets(m: Mission): Promise<DemoAssets> {
  const candidates: { url: string; alt: string; score: number }[] = [];
  for (let i = 0; i < (m.scan?.pages.length || 0); i++) {
    try {
      const html = await readFile(
        `${workspace(m.id)}/scan/page-${i + 1}.html`,
        "utf8",
      );
      const $ = cheerio.load(html);
      $("img").each((_, el) => {
        let src = $(el).attr("data-src") || $(el).attr("src") || "";
        const alt = $(el).attr("alt") || "";
        if (
          !src ||
          /logo|facebook|instagram|captcha|refresh|stars|quote\.png|icon|default-user|badge|banner.*text|top rated|everything|everythign|your.?garden.?needs/i.test(
            src + " " + alt,
          )
        )
          return;
        try {
          let u = new URL(src, m.scan!.pages[i].url);
          if (!["https:", "http:"].includes(u.protocol)) return;
          if (u.hostname === "static.wixstatic.com")
            u = new URL(u.href.split("/v1/")[0]);
          const key = u.href;
          if (candidates.some((c) => c.url === key)) return;
          const score =
            (/\.jpe?g|\.webp/i.test(key) ? 4 : 0) +
            (/garden|landscap|mechanic|workshop|car|header|hero/i.test(
              key + alt,
            )
              ? 5
              : 0) -
            (/untitled|screen.?shot/i.test(key + alt) ? 3 : 0);
          candidates.push({ url: key, alt, score });
        } catch {}
      });
    } catch {}
  }
  const photos: DemoAssets["photos"] = [];
  const hashes = new Set<string>();
  for (const c of candidates.sort((a, b) => b.score - a.score).slice(0, 7)) {
    if (photos.length >= 3) break;
    if(c.score<3)continue;
    try {
      const response = await safeFetch(c.url);
      if (
        !response.ok ||
        !/^image\/(jpeg|png|webp|avif)/i.test(
          response.headers.get("content-type") || "",
        )
      )
        continue;
      const reader = response.body?.getReader();
      if (!reader) continue;
      let size = 0;
      const chunks: Uint8Array[] = [];
      while (true) {
        const r = await reader.read();
        if (r.done) break;
        size += r.value.length;
        if (size > 5000000) {
          await reader.cancel();
          throw new Error("Image exceeds size limit");
        }
        chunks.push(r.value);
      }
      const sharp = (await import("sharp")).default;
      const image = sharp(Buffer.concat(chunks));
      const meta = await image.metadata();
      if ((meta.width || 0) < 450 || (meta.height || 0) < 230) continue;
      const data = await image
        .rotate()
        .resize({
          width: 1600,
          height: 1200,
          fit: "inside",
          withoutEnlargement: true,
        })
        .jpeg({ quality: 85 })
        .toBuffer();
      const hash = createHash("sha256").update(data).digest("hex");
      if (hashes.has(hash)) continue;
      hashes.add(hash);
      photos.push({
        data: `data:image/jpeg;base64,${data.toString("base64")}`,
        source: c.url,
        alt: c.alt,
      });
    } catch {}
  }
  const result = { photos };
  await artifact(m.id, "build/design-assets.json", result);
  return result;
}
