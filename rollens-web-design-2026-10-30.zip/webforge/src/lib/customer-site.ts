import type { CustomerSiteData } from "./selfserve";
import type { Mission, PageData } from "./types";
import { renderEvidenceDemo } from "./demo-design";
export function renderCustomerSite(d: CustomerSiteData, editor = false) {
  const page = {
    url: "https://rollenswebdesign.space",
    title: d.name,
    description: d.brief,
    summary: d.brief,
    text: d.brief,
    services: d.services,
    emails: d.email ? [d.email] : [],
    phones: d.phone ? [d.phone] : [],
    blocked: undefined,
  } as PageData;
  const mission = {
    name: d.name,
    websiteUrl: page.url,
    mode: "live",
    scan: { pages: [page], name: d.name },
  } as Mission;
  return renderEvidenceDemo(
    mission,
    { photos: d.gallery.map((data) => ({ data, source: data, alt: d.name })) },
    {
      customer: true,
      personal: d.personal,
      theme: d.theme,
      area: d.area,
      editor,
      headline: d.headline,
      tagline: d.tagline,
      seoTitle: d.seoTitle,
      seoDescription: d.seoDescription,
      branding: d.branding ?? true,
    },
  );
}
