import Stripe from "stripe";
import { randomUUID, randomBytes } from "node:crypto";
import { db, getMission } from "./db";
import {
  outreachByToken,
  saveOutreach,
  outbox,
  campaign,
} from "./automation-store";
import { automationConfig, publicBaseReady } from "./automation-config";
export function stripeClient() {
  const cfg = automationConfig();
  if (!cfg.stripeKey) throw new Error("Stripe is not configured");
  return new Stripe(cfg.stripeKey, { maxNetworkRetries: 2, timeout: 20000 });
}
export async function checkout(token: string, client = stripeClient()) {
  const o = outreachByToken(token);
  if (!o) throw new Error("Preview not found");
  const m = getMission(o.missionId);
  const c = campaign(o.campaignId);
  if (
    !c ||
    !m?.demo ||
    m.status !== "COMPLETED" ||
    m.qa?.status !== "PASSED" ||
    !m.automation?.qualified
  )
    throw new Error("This offer is unavailable");
  if (
    o.subscriptionStatus === "active" ||
    o.subscriptionStatus === "trialing" ||
    o.subscriptionStatus === "checkout_completed"
  )
    throw new Error("This website already has an active subscription");
  const cfg = automationConfig();
  if (!publicBaseReady(cfg.publicBase) || !cfg.stripeWebhook)
    throw new Error(
      "Public preview origin and Stripe webhooks must be configured",
    );
  const recent = db
    .prepare(
      "SELECT * FROM checkout_attempts WHERE outreach_id=? AND created_at>? ORDER BY id DESC",
    )
    .all(o.id, new Date(Date.now() - 3600000).toISOString()) as any[];
  const previous = recent.find((r) => r.session_id && r.url);
  if (previous) {
    const session = await client.checkout.sessions.retrieve(
      previous.session_id,
    );
    if (session.status === "open" && session.url) return session.url;
    if (session.status === "complete")
      throw new Error("Subscription confirmation pending");
  }
  if (recent.length >= 5)
    throw new Error("Checkout limit reached. Please try again later.");
  const requestId = randomUUID();
  let attempt: number;
  db.exec("BEGIN IMMEDIATE");
  try {
    const pending = db
      .prepare(
        "SELECT id FROM checkout_attempts WHERE outreach_id=? AND session_id IS NULL AND created_at>?",
      )
      .get(o.id, new Date(Date.now() - 120000).toISOString());
    if (pending) throw new Error("Checkout is already being prepared");
    attempt = Number(
      db
        .prepare(
          "INSERT INTO checkout_attempts(outreach_id,created_at) VALUES(?,?)",
        )
        .run(o.id, new Date().toISOString()).lastInsertRowid,
    );
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
  const catalogPriceId = process.env.STRIPE_PRICE_ID ||
    (cfg.stripeKey.includes("_live_") && o.priceCents === 3300
      ? "price_1UR1xwBXvUeu8hwE6gyjm6y3" : "");
  let lineItem: Stripe.Checkout.SessionCreateParams.LineItem;
  if (catalogPriceId) {
    const price = await client.prices.retrieve(catalogPriceId);
    if (!price.active || price.currency !== "aud" || price.unit_amount !== o.priceCents ||
        price.recurring?.interval !== "month" || price.recurring.interval_count !== 1 ||
        price.livemode !== cfg.stripeKey.includes("_live_"))
      throw new Error("Configured Stripe price does not match this offer");
    lineItem = { price: price.id, quantity: 1 };
  } else {
    lineItem = { price_data: { currency: "aud", unit_amount: o.priceCents,
      recurring: { interval: "month" },
      product_data: { name: `WebForge website plan — ${m.name}` } }, quantity: 1 };
  }
  const session = await client.checkout.sessions.create(
    {
      mode: "subscription",
      integration_identifier:
        "webforge_" +
        Buffer.from(randomBytes(8).map((b) => 97 + (b % 26))).toString("ascii"),
      client_reference_id: o.id,
      customer_email: o.recipient,
      line_items: [lineItem],
      metadata: { outreach_id: o.id, mission_id: m.id },
      subscription_data: { metadata: { outreach_id: o.id, mission_id: m.id } },
      success_url: `${cfg.publicBase}/p/${token}?checkout=success`,
      cancel_url: `${cfg.publicBase}/p/${token}?checkout=cancelled`,
    },
    { idempotencyKey: `webforge-checkout-${o.id}-${requestId}` },
  );
  if (!session.url) throw new Error("Stripe did not return a Checkout URL");
  db.prepare("UPDATE checkout_attempts SET session_id=?,url=? WHERE id=?").run(
    session.id,
    session.url,
    attempt,
  );
  return session.url;
}
export function applyStripeEvent(event: Stripe.Event) {
  db.exec("BEGIN IMMEDIATE");
  try {
    if (db.prepare("SELECT id FROM stripe_events WHERE id=?").get(event.id)) {
      db.exec("COMMIT");
      return false;
    }
    const obj = event.data.object as any;
    const id = obj.metadata?.outreach_id || obj.client_reference_id;
    const objectId = (value: any): string | null =>
      typeof value === "string" ? value : value?.id || null;
    const subscriptionId = event.type.startsWith("customer.subscription.")
      ? obj.id
      : objectId(
          obj.parent?.subscription_details?.subscription || obj.subscription,
        );
    const sessionMapping = event.type.startsWith("checkout.session.")
      ? (db
          .prepare(
            "SELECT outreach_id FROM checkout_attempts WHERE session_id=?",
          )
          .get(obj.id) as { outreach_id: string } | undefined)
      : undefined;
    // Resolve Stripe resource ownership first; metadata bootstraps the initial subscription link only.
    const records = outbox();
    const o =
      records.find(
        (o) => subscriptionId && o.subscriptionId === subscriptionId,
      ) ||
      records.find(
        (o) => sessionMapping && o.id === sessionMapping.outreach_id,
      ) ||
      records.find((o) => o.id === id);
    if (o) {
      if (
        [
          "checkout.session.completed",
          "checkout.session.async_payment_succeeded",
          "checkout.session.async_payment_failed",
        ].includes(event.type)
      ) {
        // Checkout success is not a claim that recurring invoices have settled.
        o.customerId =
          typeof obj.customer === "string"
            ? obj.customer
            : obj.customer?.id || null;
        o.subscriptionId =
          typeof obj.subscription === "string"
            ? obj.subscription
            : obj.subscription?.id || null;
        if (!o.subscriptionStatus) o.subscriptionStatus = "checkout_completed";
        if (obj.payment_status === "paid") o.paymentStatus = "paid";
        else if (event.type === "checkout.session.async_payment_failed")
          o.paymentStatus = "failed";
        else if (!o.paymentStatus) o.paymentStatus = "pending";
        saveOutreach(o);
      } else if (
        [
          "customer.subscription.created",
          "customer.subscription.updated",
          "customer.subscription.deleted",
        ].includes(event.type) &&
        event.created >= o.lastStripeEventAt
      ) {
        o.subscriptionStatus =
          event.type === "customer.subscription.deleted"
            ? "canceled"
            : obj.status;
        o.subscriptionId = obj.id;
        o.customerId =
          typeof obj.customer === "string"
            ? obj.customer
            : obj.customer?.id || null;
        o.lastStripeEventAt = event.created;
        saveOutreach(o);
      }
    }
    if (
      o &&
      ["invoice.paid", "invoice.payment_failed"].includes(event.type) &&
      event.created >= (o.lastInvoiceEventAt || 0)
    ) {
      o.paymentStatus = event.type === "invoice.paid" ? "paid" : "failed";
      o.lastInvoiceEventAt = event.created;
      saveOutreach(o);
    }
    db.prepare("INSERT INTO stripe_events VALUES(?,?,?,?)").run(
      event.id,
      event.created,
      event.type,
      new Date().toISOString(),
    );
    db.exec("COMMIT");
    return true;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
