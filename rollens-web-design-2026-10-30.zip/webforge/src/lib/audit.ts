import { DEFAULT_WEIGHTS } from "./config";
import type { Audit, Finding, Scan } from "./types";
export function calculateAudit(scan: Scan, weights = DEFAULT_WEIGHTS): Audit {
  const p = scan.pages[0];
  const findings: Finding[] = [];
  const strengths: string[] = [];
  const scores: Record<string, number> = {
    design: 100,
    mobile: 100,
    conversion: 100,
    trust: 100,
    seo: 100,
    accessibility: 100,
    performance: 100,
  };
  const check = (
    bad: boolean,
    id: string,
    category: string,
    penalty: number,
    severity: Finding["severity"],
    message: string,
    recommendation: string,
    kind: Finding["kind"] = "objective",
  ) => {
    if (bad) {
      scores[category] = Math.max(0, scores[category] - penalty);
      findings.push({ id, category, severity, kind, message, recommendation });
    }
  };
  check(
    !p.title,
    "title",
    "seo",
    35,
    "HIGH",
    "Page title is missing",
    "Add a unique descriptive title",
  );
  check(
    !p.description,
    "description",
    "seo",
    25,
    "MEDIUM",
    "Meta description is missing",
    "Write a concise summary of the business",
  );
  check(
    p.h1Count !== 1,
    "h1",
    "seo",
    20,
    "MEDIUM",
    `Found ${p.h1Count} H1 headings`,
    "Use one clear primary heading",
  );
  check(
    scan.brokenLinks.length > 0,
    "links",
    "seo",
    20,
    "HIGH",
    `${scan.brokenLinks.length} crawled pages failed`,
    "Repair the recorded URLs",
  );
  check(
    !p.hasViewport,
    "viewport",
    "mobile",
    45,
    "HIGH",
    "Viewport metadata is missing",
    "Set width=device-width and initial-scale=1",
  );
  check(
    scan.viewports.some((v) => v.overflow),
    "overflow",
    "mobile",
    40,
    "HIGH",
    "Horizontal overflow at a tested viewport",
    "Constrain layout width and adapt navigation",
  );
  check(
    !p.buttons.length,
    "cta",
    "conversion",
    45,
    "HIGH",
    "No recognisable primary call to action",
    "Add a visible contact, quote or booking action",
    "heuristic",
  );
  check(
    !p.forms,
    "forms",
    "conversion",
    15,
    "LOW",
    "No enquiry form was detected",
    "Consider an enquiry form if appropriate",
    "heuristic",
  );
  check(
    !p.emails.length && !p.phones.length,
    "contact",
    "conversion",
    25,
    "HIGH",
    "No public phone or email detected",
    "Provide an obvious contact method",
    "heuristic",
  );
  check(
    !p.url.startsWith("https:"),
    "https",
    "trust",
    40,
    "HIGH",
    "Website does not use HTTPS",
    "Serve the website over HTTPS",
  );
  check(
    !p.emails.length && !p.phones.length,
    "identity",
    "trust",
    30,
    "MEDIUM",
    "Business contact details were not detected",
    "Include verified business contact information",
    "heuristic",
  );
  check(
    !p.structuredData.length,
    "schema",
    "trust",
    10,
    "LOW",
    "No structured business data detected",
    "Add accurate LocalBusiness structured data",
    "heuristic",
  );
  check(
    p.missingAlt > 0,
    "alt",
    "accessibility",
    Math.min(60, (20 * p.missingAlt) / p.imageCount + 20),
    "MEDIUM",
    `${p.missingAlt} images lack alt attributes`,
    "Provide descriptive alternatives for meaningful images",
  );
  check(
    p.h1Count === 0,
    "a11y-heading",
    "accessibility",
    20,
    "MEDIUM",
    "Primary heading missing",
    "Use semantic heading structure",
  );
  check(
    p.responseMs > 1500,
    "latency",
    "performance",
    30,
    "MEDIUM",
    `HTML fetch took ${p.responseMs} ms`,
    "Review server response time",
  );
  check(
    p.htmlBytes > 200000,
    "size",
    "performance",
    25,
    "MEDIUM",
    `HTML size is ${Math.round(p.htmlBytes / 1024)} KB`,
    "Reduce unnecessary markup",
  );
  check(
    scan.viewports.some((v) => v.errors.length),
    "runtime",
    "performance",
    25,
    "HIGH",
    "Browser runtime errors detected",
    "Inspect scan artifacts and fix runtime errors",
  );
  check(
    !p.headings.length,
    "hierarchy",
    "design",
    35,
    "MEDIUM",
    "No heading hierarchy detected",
    "Create a clear hierarchy",
    "heuristic",
  );
  check(
    !p.buttons.length,
    "design-cta",
    "design",
    20,
    "MEDIUM",
    "Primary action is difficult to identify",
    "Give one primary action visual priority",
    "heuristic",
  );
  check(
    scan.viewports.some((v) => v.overflow),
    "design-overflow",
    "design",
    25,
    "HIGH",
    "Layout exceeds the viewport",
    "Make all sections responsive",
  );
  if (p.title) strengths.push("Page has a descriptive title");
  if (p.hasViewport) strengths.push("Mobile viewport is configured");
  if (p.buttons.length) strengths.push("Contact action detected");
  if (p.url.startsWith("https:")) strengths.push("HTTPS is enabled");
  if (p.missingAlt === 0)
    strengths.push("All detected images include alt attributes");
  const sum = Object.values(weights).reduce((a, b) => a + b, 0);
  if (sum <= 0) throw new Error("Audit weights must sum to more than zero");
  for (const k of Object.keys(scores)) scores[k] = Math.round(scores[k]);
  const overallScore = Math.round(
    Object.entries(weights).reduce(
      (total, [k, w]) => total + (scores[k] ?? 0) * w,
      0,
    ) / sum,
  );
  return {
    overallScore,
    scores,
    weights,
    findings,
    strengths,
    method:
      "Weighted deterministic checks and explicitly labelled heuristics. Design is a structural proxy, not a visual AI assessment. Performance uses response time, payload size and runtime errors; it is not a Lighthouse or Core Web Vitals score.",
  };
}
