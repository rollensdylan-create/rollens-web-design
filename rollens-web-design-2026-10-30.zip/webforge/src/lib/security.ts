import dns from "node:dns/promises";
import net from "node:net";
import http from "node:http";
import https from "node:https";
import { Readable } from "node:stream";
import { createGunzip, createBrotliDecompress, createInflate } from "node:zlib";
import { config } from "./config";
export function publicAddress(address: string): boolean {
  if (net.isIP(address) === 4) {
    const [a, b] = address.split(".").map(Number);
    return !(
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224
    );
  }
  if (net.isIP(address) === 6) {
    const s = address.toLowerCase();
    if (s.startsWith("::ffff:")) return false;
    return s.startsWith("2") || s.startsWith("3");
  }
  return false;
}
export async function validateUrl(input: string) {
  let u: URL;
  try {
    u = new URL(input);
  } catch {
    throw new Error("Enter a valid https:// website URL");
  }
  if (
    !["https:", "http:"].includes(u.protocol) ||
    u.username ||
    u.password ||
    (u.port && !["80", "443"].includes(u.port))
  )
    throw new Error(
      "Only public HTTP/HTTPS websites on standard ports are supported",
    );
  const host = u.hostname.replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal")
  )
    throw new Error("Private network websites are not allowed");
  const ips = net.isIP(host)
    ? [{ address: host }]
    : await dns.lookup(host, { all: true });
  if (!ips.length || ips.some((ip) => !publicAddress(ip.address)))
    throw new Error("URL resolves to a private or unsupported address");
  u.hash = "";
  return u.toString();
}
// Pin each connection to a checked public address, including every redirect hop.
async function fetchOnce(
  url: string,
  timeout = config.timeoutMs,
): Promise<Response> {
  let current = url;
  for (let i = 0; i < 5; i++) {
    await validateUrl(current);
    const u = new URL(current);
    const host = u.hostname.replace(/^\[|\]$/g, "");
    const resolved = net.isIP(host)
      ? { address: host, family: net.isIP(host) }
      : await dns.lookup(host);
    if (!publicAddress(resolved.address))
      throw new Error("Private destination blocked");
    const response = await new Promise<Response>((resolve, reject) => {
      const req = (u.protocol === "https:" ? https : http).request(
        u,
        {
          method: "GET",
          headers: {
            "User-Agent": "WebForgeAudit/1.0 (bounded website analysis)",
          },
          lookup: ((
            _hostname: string,
            options: { all?: boolean },
            callback: (...args: any[]) => void,
          ) =>
            options.all
              ? callback(null, [resolved])
              : callback(null, resolved.address, resolved.family)) as any,
        },
        (res) => {
          const headers = new Headers();
          for (const [key, value] of Object.entries(res.headers)) {
            if (value !== undefined)
              headers.set(key, Array.isArray(value) ? value.join(", ") : value);
          }
          const encoding = headers.get("content-encoding");
          const decoded =
            encoding === "gzip"
              ? res.pipe(createGunzip())
              : encoding === "br"
                ? res.pipe(createBrotliDecompress())
                : encoding === "deflate"
                  ? res.pipe(createInflate())
                  : res;
          if (decoded !== res) {
            headers.delete("content-encoding");
            headers.delete("content-length");
          }
          const body = [204, 205, 304].includes(res.statusCode || 200)
            ? null
            : (Readable.toWeb(decoded) as ReadableStream<Uint8Array>);
          resolve(
            new Response(body, { status: res.statusCode || 500, headers }),
          );
        },
      );
      const deadline = setTimeout(
        () => req.destroy(new Error("Source request timed out")),
        timeout,
      );
      req.on("close", () => clearTimeout(deadline));
      req.on("error", reject);
      req.end();
    });
    if (response.status >= 300 && response.status < 400) {
      const next = response.headers.get("location");
      await response.body?.cancel();
      if (!next) throw new Error("Redirect has no destination");
      current = new URL(next, current).toString();
      continue;
    }
    return response;
  }
  throw new Error("Too many redirects");
}
export async function safeFetch(
  url: string,
  timeout = config.timeoutMs,
): Promise<Response> {
  let last: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await fetchOnce(url, timeout);
    } catch (error) {
      last = error;
      const code = (error as NodeJS.ErrnoException).code;
      if (
        !["ECONNRESET", "ETIMEDOUT", "EAI_AGAIN", "ECONNREFUSED"].includes(
          code || "",
        ) ||
        attempt === 2
      )
        throw error;
      await new Promise((resolve) => setTimeout(resolve, 250 * 2 ** attempt));
    }
  }
  throw last;
}
export async function readLimited(response: Response, max = 2_000_000) {
  const reader = response.body?.getReader();
  if (!reader) return "";
  let size = 0;
  const chunks: Uint8Array[] = [];
  while (true) {
    const r = await reader.read();
    if (r.done) break;
    size += r.value.byteLength;
    if (size > max) {
      await reader.cancel();
      throw new Error("Page exceeds the 2 MB scan limit");
    }
    chunks.push(r.value);
  }
  return Buffer.concat(chunks).toString("utf8");
}
export function authorize(request: Request) {
  const host = request.headers.get("host") || "";
  if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host)) return false;
  const origin = request.headers.get("origin");
  try {
    if (origin && new URL(origin).host !== host) return false;
  } catch {
    return false;
  }
  if (config.token) {
    const cookie = request.headers.get("cookie") || "";
    const token = cookie
      .split(";")
      .map((x) => x.trim())
      .find((x) => x.startsWith("webforge_token="))
      ?.slice(15);
    if (
      token !== config.token &&
      request.headers.get("authorization") !== `Bearer ${config.token}`
    )
      return false;
  }
  return true;
}
export const escapeHtml = (s: string) =>
  s.replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
