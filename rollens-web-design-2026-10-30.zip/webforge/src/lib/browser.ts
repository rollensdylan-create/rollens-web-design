import { chromium, Browser } from "playwright";
import { safeFetch, readLimited } from "./security";
export async function launchBrowser(): Promise<Browser> {
  return chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_EXECUTABLE_PATH || undefined,
    args: ["--disable-background-networking", "--disable-extensions"],
  });
}
export async function publicContext(browser: Browser) {
  const ctx = await browser.newContext({
    serviceWorkers: "block",
    acceptDownloads: false,
    ignoreHTTPSErrors: false,
  });
  await ctx.routeWebSocket("**/*", (ws) => ws.close());
  await ctx.route("**/*", async (route) => {
    try {
      const req = route.request();
      if (req.method() !== "GET") {
        await route.abort();
        return;
      }
      const response = await safeFetch(req.url());
      const type = response.headers.get("content-type") || "";
      if (!response.ok) {
        await route.fulfill({ status: response.status, body: "" });
        return;
      }
      const buf = await readBinary(response, 5_000_000);
      await route.fulfill({
        status: response.status,
        contentType: type,
        body: buf,
        headers: { "access-control-allow-origin": "*" },
      });
    } catch {
      await route.abort().catch(() => {});
    }
  });
  return ctx;
}
async function readBinary(response: Response, max: number) {
  const reader = response.body?.getReader();
  if (!reader) return Buffer.alloc(0);
  let size = 0;
  const chunks: Uint8Array[] = [];
  while (true) {
    const r = await reader.read();
    if (r.done) break;
    size += r.value.byteLength;
    if (size > max) {
      await reader.cancel();
      throw new Error("Resource too large");
    }
    chunks.push(r.value);
  }
  return Buffer.concat(chunks);
}
export { readLimited };
