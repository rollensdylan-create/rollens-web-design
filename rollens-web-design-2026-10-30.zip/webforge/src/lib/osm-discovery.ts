import { readFile } from "node:fs/promises";
import path from "node:path";
import { ROOT } from "./config";
export type OsmLead = { name: string; url: string; discoverySourceUrl: string };
export function parseOsmLeads(input: unknown): OsmLead[] {
  const data = input as {
    elements?: { type?: string; id?: number; tags?: Record<string, string> }[];
  };
  if (!data || !Array.isArray(data.elements))
    throw new Error("Invalid OpenStreetMap response");
  const seen = new Set<string>();
  const leads: OsmLead[] = [];
  for (const item of data.elements) {
    const tags = item.tags || {};
    const raw = tags.website || tags["contact:website"];
    if (
      !raw ||
      !tags.name ||
      !["node", "way", "relation"].includes(item.type || "") ||
      !Number.isSafeInteger(item.id)
    )
      continue;
    try {
      const u = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
      if (
        !["https:", "http:"].includes(u.protocol) ||
        u.username ||
        u.password ||
        u.port
      )
        continue;
      const domain = u.hostname.toLowerCase().replace(/^www\./, "");
      if (seen.has(domain)) continue;
      seen.add(domain);
      leads.push({
        name: tags.name.slice(0, 100),
        url: u.origin,
        discoverySourceUrl: `https://www.openstreetmap.org/${item.type}/${item.id}`,
      });
      if (leads.length >= 200) break;
    } catch {
      /* Ignore malformed map website tags. DNS and public-IP checks run before import. */
    }
  }
  return leads;
}
export async function osmMelbourneLeads(
  file = path.join(ROOT, "osm-melbourne-cache.json"),
): Promise<OsmLead[]> {
  let cache;
  try {
    cache = JSON.parse(await readFile(file, "utf8"));
  } catch {
    throw new Error(
      "Free local discovery dataset is not loaded; check webforge-osm-refresh.service",
    );
  }
  if (
    !Number.isFinite(cache.fetchedAt) ||
    Date.now() - cache.fetchedAt > 14 * 24 * 3600000
  )
    throw new Error(
      "Free local discovery dataset is stale; check webforge-osm-refresh.service",
    );
  return parseOsmLeads(cache);
}
