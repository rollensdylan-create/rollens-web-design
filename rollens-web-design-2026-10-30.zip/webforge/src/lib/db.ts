import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { ROOT } from "./config";
import { Mission, Event, Stage, Status } from "./types";
mkdirSync(ROOT, { recursive: true });
export const db = new DatabaseSync(path.join(ROOT, "webforge.sqlite"));
db.exec(`PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS businesses(id TEXT PRIMARY KEY,name TEXT NOT NULL,url TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS missions(id TEXT PRIMARY KEY,business_id TEXT NOT NULL REFERENCES businesses(id),status TEXT NOT NULL,created_at TEXT NOT NULL,data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS missions_status ON missions(status,created_at);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,mission_id TEXT NOT NULL REFERENCES missions(id),timestamp TEXT NOT NULL,stage TEXT NOT NULL,type TEXT NOT NULL,severity TEXT NOT NULL,message TEXT NOT NULL,metadata TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS events_mission ON events(mission_id,id);
CREATE TABLE IF NOT EXISTS worker_heartbeat(id INTEGER PRIMARY KEY CHECK(id=1),updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stage_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,mission_id TEXT NOT NULL REFERENCES missions(id),stage TEXT NOT NULL,status TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT,error TEXT);
`);
export function listMissions(): Mission[] {
  return (
    db.prepare("SELECT data FROM missions ORDER BY created_at DESC").all() as {
      data: string;
    }[]
  ).map((r) => JSON.parse(r.data));
}
export function getMission(id: string): Mission | null {
  const r = db.prepare("SELECT data FROM missions WHERE id=?").get(id) as
    { data: string } | undefined;
  return r ? JSON.parse(r.data) : null;
}
export function saveMission(m: Mission) {
  const { events: _events, ...data } = m;
  db.prepare("UPDATE missions SET status=?,data=? WHERE id=?").run(
    m.status,
    JSON.stringify(data),
    m.id,
  );
}
export function createMission(
  url: string,
  name: string,
  mode: "live" | "fixture",
): Mission {
  const now = new Date().toISOString();
  let b = db.prepare("SELECT id FROM businesses WHERE url=?").get(url) as
    { id: string } | undefined;
  if (!b) {
    b = { id: randomUUID() };
    db.prepare("INSERT INTO businesses VALUES(?,?,?,?)").run(
      b.id,
      name,
      url,
      now,
    );
  }
  const m: Mission = {
    id: randomUUID(),
    businessId: b.id,
    name,
    websiteUrl: url,
    status: "QUEUED",
    currentStage: "DISCOVERY",
    progress: 0,
    mode,
    createdAt: now,
    startedAt: null,
    completedAt: null,
    failedAt: null,
    error: null,
    nextStage: 0,
    attempts: 0,
    pauseRequested: false,
    usage: {
      durationMs: 0,
      agentExecutions: 0,
      model: "none",
      inputTokens: 0,
      outputTokens: 0,
    },
  };
  db.prepare("INSERT INTO missions VALUES(?,?,?,?,?)").run(
    m.id,
    m.businessId,
    m.status,
    now,
    JSON.stringify(m),
  );
  event(
    m.id,
    "DISCOVERY",
    "QUEUED",
    "INFO",
    mode === "fixture"
      ? "Training fixture queued · simulated source, real pipeline"
      : "Mission queued for local worker",
  );
  return m;
}
export function event(
  missionId: string,
  stage: Stage,
  type: string,
  severity: Event["severity"],
  message: string,
  metadata: Record<string, unknown> = {},
) {
  db.prepare(
    "INSERT INTO events(mission_id,timestamp,stage,type,severity,message,metadata) VALUES(?,?,?,?,?,?,?)",
  ).run(
    missionId,
    new Date().toISOString(),
    stage,
    type,
    severity,
    message,
    JSON.stringify(metadata),
  );
}
export function events(id?: string, after = 0): Event[] {
  const rows = (
    id
      ? db
          .prepare(
            "SELECT * FROM events WHERE mission_id=? AND id>? ORDER BY id DESC LIMIT 300",
          )
          .all(id, after)
      : db
          .prepare("SELECT * FROM events WHERE id>? ORDER BY id DESC LIMIT 300")
          .all(after)
  ) as any[];
  return rows.reverse().map((r) => ({
    id: r.id,
    missionId: r.mission_id,
    timestamp: r.timestamp,
    stage: r.stage,
    type: r.type,
    severity: r.severity,
    message: r.message,
    metadata: JSON.parse(r.metadata),
  }));
}
export function control(id: string, action: string): Mission {
  db.exec("BEGIN IMMEDIATE");
  try {
    const m = getMission(id);
    if (!m) throw new Error("Mission not found");
    const allowed: Record<string, Status[]> = {
      pause: ["QUEUED", "RUNNING"],
      resume: ["PAUSED"],
      cancel: ["QUEUED", "RUNNING", "PAUSED", "FAILED"],
      retry: ["FAILED"],
      qa: ["COMPLETED", "FAILED"],
      rebuild: ["COMPLETED", "FAILED"],
    };
    if (!allowed[action]?.includes(m.status))
      throw new Error(`Cannot ${action} a ${m.status.toLowerCase()} mission`);
    if (action === "pause") {
      if (m.status === "RUNNING") m.pauseRequested = true;
      else m.status = "PAUSED";
    }
    if (action === "resume") {
      m.status = "QUEUED";
      m.pauseRequested = false;
    }
    if (action === "cancel") {
      m.status = "CANCELLED";
      m.pauseRequested = false;
    }
    if (["retry", "qa", "rebuild"].includes(action)) {
      m.status = "QUEUED";
      m.error = null;
      m.failedAt = null;
      m.completedAt = null;
      m.pauseRequested = false;
      if (action === "qa") m.nextStage = 6;
      if (action === "rebuild") m.nextStage = 5;
    }
    saveMission(m);
    event(
      id,
      m.currentStage,
      "CONTROL",
      "INFO",
      action === "pause" && m.status === "RUNNING"
        ? "Pause requested · current stage will finish"
        : `Operator: ${action}`,
    );
    db.exec("COMMIT");
    return m;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
export function claim(): Mission | null {
  db.exec("BEGIN IMMEDIATE");
  try {
    if (
      db.prepare("SELECT id FROM missions WHERE status='RUNNING' LIMIT 1").get()
    ) {
      db.exec("COMMIT");
      return null;
    }
    const row = db
      .prepare(
        "SELECT data FROM missions WHERE status='QUEUED' ORDER BY created_at LIMIT 1",
      )
      .get() as { data: string } | undefined;
    if (!row) {
      db.exec("COMMIT");
      return null;
    }
    const m: Mission = JSON.parse(row.data);
    m.status = "RUNNING";
    m.startedAt ??= new Date().toISOString();
    saveMission(m);
    db.exec("COMMIT");
    return m;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
export function heartbeat() {
  db.prepare(
    "INSERT INTO worker_heartbeat VALUES(1,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at",
  ).run(new Date().toISOString());
}
export function workerStatus() {
  const r = db
    .prepare("SELECT updated_at FROM worker_heartbeat WHERE id=1")
    .get() as { updated_at: string } | undefined;
  return {
    online: !!r && Date.now() - Date.parse(r.updated_at) < 15000,
    lastSeen: r?.updated_at || null,
  };
}
export function recoverInterrupted() {
  for (const m of listMissions().filter((m) => m.status === "RUNNING")) {
    m.status = "FAILED";
    m.error = "Worker interrupted. Retry to resume from the last saved stage.";
    m.failedAt = new Date().toISOString();
    saveMission(m);
    event(m.id, m.currentStage, "INTERRUPTED", "ERROR", m.error);
  }
}
export function stageRun(id: string, stage: Stage) {
  return Number(
    db
      .prepare(
        "INSERT INTO stage_runs(mission_id,stage,status,started_at) VALUES(?,?,'RUNNING',?)",
      )
      .run(id, stage, new Date().toISOString()).lastInsertRowid,
  );
}
export function finishStage(id: number, error?: string) {
  db.prepare(
    "UPDATE stage_runs SET status=?,finished_at=?,error=? WHERE id=?",
  ).run(
    error ? "FAILED" : "COMPLETED",
    new Date().toISOString(),
    error || null,
    id,
  );
}
