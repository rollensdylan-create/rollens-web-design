export const STAGES = [
  "DISCOVERY",
  "SCAN",
  "ANALYSIS",
  "AUDIT",
  "STRATEGY",
  "BUILD",
  "QA",
  "FIX",
  "DEPLOY",
  "COMPLETE",
] as const;
export type Stage = (typeof STAGES)[number];
export type Status =
  "QUEUED" | "RUNNING" | "PAUSED" | "COMPLETED" | "FAILED" | "CANCELLED";
export type Event = {
  id: number;
  missionId: string;
  timestamp: string;
  stage: Stage;
  type: string;
  severity: "INFO" | "SUCCESS" | "WARNING" | "ERROR";
  message: string;
  metadata: Record<string, unknown>;
};
export type Finding = {
  id: string;
  category: string;
  severity: "HIGH" | "MEDIUM" | "LOW";
  kind: "objective" | "heuristic";
  message: string;
  recommendation: string;
};
export type PageData = {
  url: string;
  title: string;
  description: string;
  headings: string[];
  links: { text: string; url: string }[];
  emails: string[];
  phones: string[];
  services: string[];
  forms: number;
  buttons: string[];
  imageCount: number;
  missingAlt: number;
  hasViewport: boolean;
  h1Count: number;
  htmlBytes: number;
  responseMs: number;
  status: number;
  structuredData: unknown[];
  summary?: string;
  text?: string;
  blocked?: string;
};
export type Scan = {
  pages: PageData[];
  screenshots: string[];
  viewports: { width: number; overflow: boolean; errors: string[] }[];
  brokenLinks: string[];
  name: string;
  warnings: string[];
};
export type Audit = {
  overallScore: number;
  scores: Record<string, number>;
  weights: Record<string, number>;
  findings: Finding[];
  strengths: string[];
  method: string;
};
export type Strategy = {
  provider: string;
  summary: string;
  sections: string[];
  priorities: string[];
  generatedAt: string;
};
export type QA = {
  status: "PASSED" | "FAILED";
  checks: {
    width: number;
    overflow: boolean;
    cta: boolean;
    brokenImages: number;
    errors: string[];
  }[];
  issues: string[];
};
export type Mission = {
  id: string;
  businessId: string;
  name: string;
  websiteUrl: string;
  status: Status;
  currentStage: Stage;
  progress: number;
  mode: "live" | "fixture";
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedAt: string | null;
  error: string | null;
  nextStage: number;
  attempts: number;
  pauseRequested: boolean;
  scan?: Scan;
  audit?: Audit;
  strategy?: Strategy;
  qa?: QA;
  demo?: {
    status: string;
    previewUrl: string;
    framework: string;
    buildStatus: string;
  };
  usage: {
    durationMs: number;
    agentExecutions: number;
    model: string;
    inputTokens: number;
    outputTokens: number;
  };
  events?: Event[];
  automation?: {
    campaignId: string;
    prospectId: string;
    threshold: number;
    qualified?: boolean;
  };
};
export type Settings = {
  maxPages: number;
  timeoutMs: number;
  maxDepth: number;
  maxFixAttempts: number;
  maxRuntimeMs: number;
  weights: Record<string, number>;
  aiProvider: string;
  agentMode: string;
  aiConfigured: boolean;
  opencodeAvailable: boolean;
};
