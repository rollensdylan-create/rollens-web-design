import path from "node:path";
import { mkdir, writeFile, readFile, readdir } from "node:fs/promises";
import { ROOT } from "./config";
export const workspace = (id: string) => path.join(ROOT, "missions", id);
export async function artifact(id: string, name: string, value: unknown) {
  const p = path.join(workspace(id), name);
  await mkdir(path.dirname(p), { recursive: true });
  await writeFile(
    p,
    typeof value === "string" ? value : JSON.stringify(value, null, 2),
  );
}
export async function readArtifact(id: string, name: string) {
  const base = workspace(id);
  const p = path.resolve(base, name);
  if (!p.startsWith(base + path.sep)) throw new Error("Invalid artifact");
  return readFile(p);
}
export async function listArtifacts(id: string) {
  const result: string[] = [];
  async function walk(dir: string, prefix = "") {
    try {
      for (const f of await readdir(dir, { withFileTypes: true })) {
        if (f.isSymbolicLink()) continue;
        if (f.isDirectory())
          await walk(path.join(dir, f.name), prefix + f.name + "/");
        else result.push(prefix + f.name);
      }
    } catch {}
  }
  await walk(workspace(id));
  return result.filter(
    (x) => !x.includes("node_modules") && !x.includes(".git"),
  );
}
