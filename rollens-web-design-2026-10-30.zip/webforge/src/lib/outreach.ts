import { safeFetch, readLimited } from "./security";
import { artifact } from "./artifacts";
import { getMission, event } from "./db";
import {
  campaign,
  prospect,
  outbox,
  saveOutreach,
  addOutreach,
  suppressed,
  token,
  automationLog,
  Outbox,
  Campaign,
  Prospect,
} from "./automation-store";
import { automationConfig, publicBaseReady } from "./automation-config";
export const money = (cents: number) =>
  new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD" }).format(
    cents / 100,
  );
export function renderEmail(c: Campaign, p: Prospect, accessToken: string) {
  const m = getMission(p.missionId!);
  const base = automationConfig().publicBase || "https://YOUR-PUBLIC-DOMAIN";
  const vars: Record<string, string> = {
    business_name: p.name,
    website_url: p.url,
    score: String(p.score ?? ""),
    improvements:
      m?.audit?.findings
        .slice(0, 3)
        .map((f) => f.recommendation)
        .join("; ") || "clearer navigation and contact actions",
    preview_url: `${base}/p/${accessToken}`,
    checkout_url: `${base}/p/${accessToken}#subscribe`,
    price: money(c.priceCents),
    sender_name: c.senderName,
    sender_address: c.senderAddress,
    unsubscribe_url: `${base}/api/public/unsubscribe/${accessToken}`,
  };
  const replace = (s: string) =>
    s.replace(/\{\{([a-z_]+)\}\}/g, (_match, key) => {
      if (!(key in vars)) throw new Error(`Unknown template variable: ${key}`);
      return vars[key];
    });
  const subject = replace(c.subject).replace(/[\r\n]/g, " ");
  let text = replace(c.template);
  if (!text.includes(vars.unsubscribe_url))
    text += `\n\nUnsubscribe: ${vars.unsubscribe_url}`;
  if (!text.includes(c.senderAddress) || !c.senderAddress.trim())
    text += `\n\n${c.senderName}\n${c.senderAddress || "[Sender business address required]"}`;
  return { subject, text };
}
export function deliveryBlockers(c: Campaign, p: Prospect, o?: Outbox) {
  const cfg = automationConfig();
  const m = p.missionId ? getMission(p.missionId) : null;
  const issues: string[] = [];
  if (!c.enabled) issues.push("Campaign paused");
  if (!c.sendingEnabled) issues.push("Automatic sending is off");
  if (!p.email) issues.push("Recipient address required");
  if (o && o.recipient !== p.email?.toLowerCase())
    issues.push(
      "Recipient changed after preparation; create a fresh outreach record",
    );
  if (p.permission === "UNKNOWN" || !p.permissionEvidence.trim())
    issues.push(
      "Recorded contact permission required; scraped address is research only",
    );
  if (p.email && suppressed(p.email)) issues.push("Recipient unsubscribed");
  if (
    m?.mode !== "live" ||
    m.status !== "COMPLETED" ||
    m.qa?.status !== "PASSED" ||
    !m.demo ||
    !m.automation?.qualified
  )
    issues.push("A qualified live demo with passing QA is required");
  if (!cfg.resendKey) issues.push("Resend API key required");
  if (!cfg.stripeKey || !cfg.stripeWebhook)
    issues.push("Stripe API key and webhook secret required");
  if (!publicBaseReady(cfg.publicBase))
    issues.push("Public HTTPS preview origin required");
  if (!c.senderEmail || !c.senderAddress.trim() || !c.senderName.trim())
    issues.push("Sender identity, email and business address required");
  if (o && ["SENT", "SENDING", "UNCERTAIN", "SUPPRESSED"].includes(o.state))
    issues.push(`Message is ${o.state.toLowerCase()}`);
  return issues;
}
export async function prepareOutreach(p: Prospect, c: Campaign) {
  if (
    !p.email ||
    outbox().some(
      (o) => o.prospectId === p.id || o.recipient === p.email?.toLowerCase(),
    )
  )
    return;
  const m = getMission(p.missionId!);
  if (
    m?.status !== "COMPLETED" ||
    !m.demo ||
    m.qa?.status !== "PASSED" ||
    !m.automation?.qualified ||
    m.mode !== "live"
  )
    return;
  const t = token();
  const rendered = renderEmail(c, p, t);
  const o = addOutreach(p, rendered.subject, rendered.text, t, c.priceCents);
  await artifact(m.id, "outreach/email.json", {
    subject: o.subject,
    text: o.text,
    recipient: o.recipient,
    deliveryBlockers: deliveryBlockers(c, p, o),
  });
  automationLog(c.id, `Outreach prepared for ${p.name}`);
}
export async function dispatchOne(
  o: Outbox,
  fetcher: typeof fetch = fetch,
  readiness: (o: Outbox) => Promise<boolean> = checkPublicPreview,
) {
  if (!["DRAFT", "READY"].includes(o.state)) return;
  const c = campaign(o.campaignId);
  const p = prospect(o.prospectId);
  if (!c || !p) return;
  const blockers = deliveryBlockers(c, p, o);
  if (blockers.length) {
    o.state = p.email && suppressed(p.email) ? "SUPPRESSED" : "DRAFT";
    o.error = blockers.join("; ");
    saveOutreach(o);
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  const count = outbox().filter(
    (x) =>
      x.campaignId === c.id &&
      ["SENT", "SENDING", "UNCERTAIN"].includes(x.state) &&
      x.updatedAt.startsWith(today),
  ).length;
  if (count >= c.dailyEmails) return;
  if (
    o.attempts > 0 &&
    o.firstAttemptAt &&
    Date.now() - Date.parse(o.firstAttemptAt) > 23 * 3600000
  ) {
    o.state = "UNCERTAIN";
    o.error =
      "Provider idempotency window expired; reconcile the previous attempt before resending.";
    saveOutreach(o);
    return;
  }
  if (o.attempts >= 3) {
    o.state = "FAILED";
    o.error = "Retry limit reached";
    saveOutreach(o);
    return;
  }
  if (!(await readiness(o))) {
    o.state = "DRAFT";
    o.error =
      "Public recipient preview is not reachable. Configure and publish the public routes before sending.";
    saveOutreach(o);
    return;
  }
  // Refresh the text before its first attempt. The frozen offer price is retained after handoff.
  if (!o.attempts) {
    o.priceCents = c.priceCents;
    const text = renderEmail(c, p, o.token);
    o.subject = text.subject;
    o.text = text.text;
  }
  o.firstAttemptAt ??= new Date().toISOString();
  o.state = "SENDING";
  o.attempts++;
  o.error = null;
  saveOutreach(o);
  try {
    const res = await fetcher("https://api.resend.com/emails", {
      method: "POST",
      signal: AbortSignal.timeout(20000),
      headers: {
        Authorization: `Bearer ${automationConfig().resendKey}`,
        "Content-Type": "application/json",
        "Idempotency-Key": `webforge-${o.id}`,
      },
      body: JSON.stringify({
        from: `${c.senderName.replace(/[<>\r\n]/g, "")} <${c.senderEmail}>`,
        to: [o.recipient],
        reply_to: c.replyTo || c.senderEmail,
        subject: o.subject,
        text: o.text,
        headers: {
          "List-Unsubscribe": `<${automationConfig().publicBase}/api/public/unsubscribe/${o.token}>`,
          "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
        },
      }),
    });
    if (!res.ok) {
      o.state =
        res.status === 429
          ? "READY"
          : res.status >= 500
            ? "UNCERTAIN"
            : "FAILED";
      o.error = `Email provider returned HTTP ${res.status}`;
      saveOutreach(o);
      return;
    }
    const body = await res.json();
    if (!body.id) throw new Error("Provider response omitted message ID");
    o.providerId = body.id;
    o.state = "SENT";
    o.sentAt = new Date().toISOString();
    saveOutreach(o);
    event(
      o.missionId,
      "COMPLETE",
      "EMAIL_ACCEPTED",
      "SUCCESS",
      "Outreach accepted by email provider",
    );
    automationLog(c.id, `Email accepted by provider for ${p.name}`);
  } catch {
    o.state = "UNCERTAIN";
    o.error =
      "Delivery outcome unknown. Reconcile the provider message before retrying; automatic resend blocked.";
    saveOutreach(o);
    automationLog(c.id, o.error, "WARNING");
  }
}

export async function checkPublicPreview(o: Outbox) {
  try {
    const r = await safeFetch(
      `${automationConfig().publicBase}/api/public/readiness/${o.token}`,
      5000,
    );
    if (!r.ok) return false;
    const body = JSON.parse(await readLimited(r, 4096));
    return body.ready === true && body.outreachId === o.id;
  } catch {
    return false;
  }
}
