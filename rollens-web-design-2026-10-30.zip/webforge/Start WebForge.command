#!/bin/zsh
set -eu
cd "${0:A:h}"
if ! command -v node >/dev/null 2>&1; then
  runtime_bin="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin"
  if [[ -x "$runtime_bin/node" ]]; then export PATH="$runtime_bin:$PATH"; else print 'Install Node.js 24 to start WebForge.'; exit 1; fi
fi
if [[ ! -d node_modules ]]; then print 'Run pnpm install and pnpm exec playwright install chromium first.'; exit 1; fi
if [[ ! -f .next/BUILD_ID ]]; then node node_modules/next/dist/bin/next build; fi
node --env-file-if-exists=.env.local --import tsx src/worker/main.ts &
webforge_worker_pid=$!
trap 'kill "$webforge_worker_pid" 2>/dev/null || true' EXIT INT TERM
print 'Open http://127.0.0.1:4333 — press Control-C to stop.'
node node_modules/next/dist/bin/next start --hostname 127.0.0.1 --port 4333
