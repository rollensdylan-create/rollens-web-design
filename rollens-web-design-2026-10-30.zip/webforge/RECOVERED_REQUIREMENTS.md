# Recovered WebForge requirements

Source: [Automated Website Rating System](https://chatgpt.com/c/6a87d6a0-93f0-83ec-9bf1-dacf2a3646a1), 21 August 2026, 2:45 pm as displayed in the original chat.
Prompt title: **AATLAS WebForge Mission Control — Master OpenCode Build Prompt**.

This is a requirements digest of the recovered prompt, not a verbatim transcript.

## Product

An AI-assisted website analysis and recreation platform. A business URL becomes a mission that progresses visibly through discovery, scan, analysis, audit, strategy, build, QA, optional fix, preview and completion. The operator sees live events, findings, artifacts, resource usage and previews.

## Original technical direction

Next.js App Router, TypeScript, Tailwind, PostgreSQL with a typed ORM, separate worker services and SSE/WebSocket events. Avoid infrastructure that prevents the frontend from booting before external services are configured. Build a runnable MVP before adding distributed services.

## Required data

Business identity, public contact details and source URL; mission status/stage/progress/timestamps; structured events; weighted audit category scores; issues, strengths and recommendations; strategies, demos, jobs, errors and cost metadata. Mission states: QUEUED, RUNNING, PAUSED, COMPLETED, FAILED and CANCELLED.

## Source collection

Bounded crawl with configurable page/depth/time limits. Extract HTML, titles, metadata, headings, links, navigation, forms, buttons, CTAs, public contact information, service headings and structured data. Capture desktop 1440px, tablet 768px and mobile 390px screenshots. Check HTTPS, title, description, viewport, failed internal links, image alternatives, contact information, CTAs, horizontal overflow, browser errors and performance signals.

## Audit

Use deterministic weighted scores, not an arbitrary AI number. Default weights: design 15%, mobile 15%, conversion 20%, trust 10%, SEO 15%, accessibility 10%, performance 15%. Distinguish objective findings, heuristics and AI recommendations. Make findings inspectable.

## AI and build workers

Provider abstraction and dedicated prompts. Mock/development outputs must be labelled. OpenCode runs as a controlled worker in a mission workspace, reading factual context files, generating a demo and emitting task-level progress. Do not expose private reasoning or claim real OpenCode execution without testing it.

Generated business websites should be original, modern and responsive, guided by the strategy. Use public facts; avoid copying source code, substantial prose or unauthorised assets. Do not invent testimonials, qualifications or other business claims.

## QA, fixes and resource control

Test at all three widths. Detect failed builds, runtime errors, navigation/link failures, broken images, form problems, overflow, overlaps, off-screen buttons, missing CTAs and accessibility issues where practical. Save structured QA artifacts. Optional fix loop receives specific findings and has bounded attempts, time and budget. Track usage without inventing exact costs.

## Mission control experience

Dark, restrained, technical command centre. Mission queue on the left, pipeline and activity in the centre, useful preview on the right. Overview, mission list/detail, businesses, demos and settings routes. Provide create/start, pause/resume, cancel, retry, rerun QA, rebuild, artifact inspection and open-preview controls. Queue-level pause semantics are acceptable if clearly explained.

## Isolation and deployment

Treat source sites and generated code as untrusted. Prevent private-network scans. Keep agent execution outside the operator application. Isolate previews and never expose secrets to generated code. Begin with screenshot preview; production live hosting remains a separately configured capability.

## Development sequence

1. Foundation: models, persistence, events and mission UI.
2. Orchestration: state transitions, retries, errors and progress.
3. Bounded source scanning and screenshots.
4. Weighted audit and inspection UI.
5. AI interface and labelled fallback.
6. Demo workspace, original template and screenshot preview.
7. Real OpenCode adapter where configured.
8. Deterministic QA and bounded fixes.
9. Preview/deployment interfaces.

Maintain IMPLEMENTATION_STATUS.md, run lint/typecheck/build, test critical flows and record incomplete integrations. The original prompt explicitly prioritises functional infrastructure over a visually impressive mockup and permits completion of later phases as realistically implementable and testable in the available environment.
