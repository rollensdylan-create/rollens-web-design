# WebForge Autopilot

Open http://127.0.0.1:4333/automation.

## Campaign setup

1. Choose **New campaign**. Configure niche, area, source-score cutoff, daily scan/email limits, sender identity/address, price and email template. Defaults are below 60/100 and A$33/month; every campaign can change them.
2. Save it. Under **Pipeline**, import business URLs, or configure Brave Search so the worker can discover business domains automatically on a schedule. Search results rotate through pages and domains are deduplicated per campaign. Discovery is a lead source, not a guarantee of niche/area fit.
3. Under **Connections**, save the Resend API key, Stripe secret key, Stripe webhook signing secret, optional Brave Search key and public HTTPS preview origin. Keys are write-only in the UI, encrypted locally with AES-GCM and file permissions 0600. Environment variables take precedence.
4. Verify the sender domain in Resend. Set Stripe to test mode first. A ChatGPT Stripe connection is separate from an unattended application's API credentials; the worker needs its own server-side key.
5. Host the public recipient routes at your preview origin. The app checks that each token's public readiness endpoint responds correctly before a provider handoff. Localhost links are not emailed as usable public previews. The supplied `deploy/public-preview.nginx.conf` is a route-restricted reverse proxy example; DNS, TLS and hosting are not deployed by this change.
6. Record a recipient and contact permission/evidence for each contact, or import existing permissioned contact data in JSON. Public addresses extracted during scanning are research evidence and do not automatically confer permission. There is no per-email approval once recipient eligibility and campaign automation are configured.
7. Enable automatic sending in the campaign, then choose **Start campaign**.

## Automated flow

Scheduled search / imported URLs → bounded scan → weighted audit → score gate → strategy → original redesign → viewport QA → recipient email preparation → eligibility and public-preview checks → Resend acceptance → recipient preview → Stripe subscription Checkout → signed subscription events.

Websites scoring at or above the campaign cutoff stop after the audit. They do not consume build/agent resources or produce outreach. The threshold comparison is strict: a cutoff of 60 means scores 0–59 qualify.

The current build engine remains the original HTML/CSS template, or the separately configured OpenCode adapter. Autopilot does not falsely label template output as an AI-designed website.

## Recipient data

Each prospect retains extracted emails with source URLs. A chosen recipient has a separate permission state and evidence note. JSON import can include:

```json
[
  {
    "name": "Business with existing permission",
    "url": "https://business.example",
    "email": "owner@business.example",
    "permission": "EXPRESS",
    "permissionEvidence": "Recorded request for a website proposal on DATE; source RECORD"
  }
]
```

Permission is never inferred solely from a scraped address. Suppressions take precedence and apply across campaigns. ACMA guidance requires consent, sender identification and unsubscribe facilities for Australian commercial messages, and restricts harvested address lists: https://www.acma.gov.au/avoid-sending-spam . Assess any other claimed basis before recording it; the app cannot determine legal permission from page text.

## Email lifecycle

DRAFT → READY/SENDING → SENT (provider accepted), FAILED, UNCERTAIN or SUPPRESSED.

- One initial outreach record per recipient across campaigns prevents duplicate pitches.
- Resend requests use a stable idempotency key.
- Explicit retryable HTTP failures use capped retries/backoff. Unknown outcomes or crashes during handoff become UNCERTAIN and are never automatically resent.
- The email provider accepting a request is not proof of inbox delivery. Bounce/delivery webhook synchronisation is not included.
- Unsubscribe GET shows a confirmation page; POST suppresses future messages immediately. List-Unsubscribe and one-click POST headers are included.
- Daily limits use UTC calendar days. Pausing a campaign prevents further provider handoffs; an already in-flight request cannot be recalled.
- Failed/uncertain handoffs are visible for provider reconciliation. There is no automated follow-up sequence.

## Stripe

The email links to a persistent, random-token recipient preview instead of a short-lived checkout session. The preview shows the frozen recurring AUD price and a Stripe subscribe button. Clicking it creates or reuses a server-side Checkout Session in subscription mode. The customer enters payment information on Stripe. The application never charges someone just because an email was sent.

Configure a webhook endpoint at:

```
https://YOUR-PREVIEW-DOMAIN/api/stripe/webhook
```

Listen for:

- checkout.session.completed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted
- checkout.session.async_payment_succeeded
- checkout.session.async_payment_failed
- invoice.paid
- invoice.payment_failed

The handler verifies Stripe's signature against the raw request body, deduplicates event IDs and ignores stale subscription events. Checkout return URLs do not mark an account paid. Checkout completion and subscription state are stored separately from claims of settled revenue. Public order forms cannot set the price. No production charges were made during implementation/testing.

A paid subscription records the sale and customer/subscription IDs. Automatic DNS/domain transfer, customer revisions and launching the purchased website are separate fulfilment work and are not represented as completed here.

## Runtime configuration

Use the UI's Connections tab, or set:

```
RESEND_API_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
BRAVE_SEARCH_API_KEY=
PUBLIC_BASE_URL=https://preview.YOUR-DOMAIN.example
```

Credentials saved through the UI are read dynamically by the worker. For environment changes, restart both processes. Campaign settings are database-backed and take effect without restarting.

## Verification

`pnpm test` covers permission gates, template variables, deduplication, provider handoff idempotency, uncertain outcomes, suppression, Stripe recurring price/session reuse, webhook replay/order, encrypted configuration and public preview readiness, plus the existing mission tests.

`pnpm verify:automation` runs isolated real scan/build/filter integration tests and verifies public previews, unsubscribe, configuration redaction and signed Stripe webhook handling. Email handoffs and Checkout creation are tested against local provider doubles; real Resend delivery, Brave results and Stripe account billing require your configured credentials. See AUTOMATION_VALIDATION.json.

## Sources

Stripe Checkout: https://docs.stripe.com/checkout/quickstart
Stripe webhooks: https://docs.stripe.com/events/manage-webhook-endpoints
Resend sending: https://resend.com/docs/api-reference/emails/send-email
Resend idempotency: https://resend.com/docs/dashboard/emails/idempotency-keys
Brave Search: https://api-dashboard.search.brave.com/app/documentation/web-search/get-started

## Stripe environment selection

The connected ChatGPT Stripe account is CansCo in live mode. No account-specific changes have been made. Development should use a separate sandbox unless the operator explicitly selects the live account. Prefer a restricted API key for the worker; do not commit it or paste it into chat. GST/tax collection is not enabled automatically: confirm registration and applicable settings before enabling Stripe Tax.

## CansCo live Stripe catalog

Created with the connected Stripe account on 16 October 2026:
- Account: `acct_1SebLIBXvUeu8hwE` (CansCo, live)
- Product: `prod_VRvptFMvXh97kQ` — WebForge Website Plan
- Price: `price_1UR1xwBXvUeu8hwE6gyjm6y3` — AUD 33.00 per month

Live A$33 offers use this catalog price. Checkout verifies that it remains active and matches the frozen offer amount, currency, billing interval, and environment. `STRIPE_PRICE_ID` overrides it. Other amounts and test mode use inline prices unless overridden. This catalog creation did not charge anyone.

The Stripe connector does not provide unattended server credentials. Save a CansCo live restricted key and webhook signing secret in Connections, then configure a public HTTPS origin and sender credentials. The account's existing merchant profile describes a different business; update it to accurately describe WebForge before launching sales. No account profile was changed.
