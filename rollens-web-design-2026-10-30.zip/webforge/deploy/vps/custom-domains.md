# Customer custom domains

All existing paid plans can connect domains without a plan-price change. Each customer site can map up to five hostnames, including a root domain and www. Customers manage these from My account → website → Custom domains, including after a Starter/Plus content lock.

The service requires an A record pointing to the VPS IPv4 address, no competing AAAA record, DNS-only hosting when using Cloudflare, and a per-claim TXT challenge at `_rollens-verification.<hostname>`. Keep the TXT record. Registration, renewal and DNS administration remain with the domain owner. A CNAME is also accepted when its final A records all point to the VPS.

Domain verification is available for a saved draft. Routing and certificate approval require a verified hostname, the owning site's publication, and an active paid account. Custom-domain routing stops immediately after unpublication, loss of paid entitlement, or disconnection. DNS proof is rechecked after an hour when a domain is used; failed ownership/routing checks disable the mapping. Temporary resolver outages return a retryable failure and recover without manual reconnection.

Pending claims do not reserve a hostname. Another account can take over a previously mapped hostname only after proving control with its own fresh DNS TXT token. Tokens are unique per claim, including after disconnect/reconnect. Rollens and Offerflow hostnames, IP addresses, local names, wildcards, URLs and ports cannot be registered by customers.

Caddy uses its existing certificate storage and on-demand TLS. Merge the global `on_demand_tls` ask configuration from Caddyfile at the top of the existing combined config. Preserve the exact AATLAS, Offerflow and Rollens blocks and append the HTTPS fallback. `caddy validate` must pass before reloading. The ask endpoint returns success only for eligible verified published sites. Arbitrary hostnames cannot trigger certificates.

The fallback accepts only the site's root path and rewrites it to a dedicated loopback-only rendering route. It overwrites the routing/Host headers and strips cookies and authorization. It does not expose account, billing, operator APIs, or filesystem artifacts on custom domains. Uploaded images continue using their absolute Rollens URLs. Existing Rollens site addresses keep working.

`CUSTOM_DOMAIN_IPV4` can override the default VPS address of 85.208.48.9 after an infrastructure move; update customers' DNS and reverify. The domain schema and verification state live in the existing SQLite backup.

Deploy source and a matching production build before enabling the Caddy fallback. Build in a staged checkout against temporary data. When using a symlink to the existing node_modules, the staged Turbopack root must include both the staging directory and /opt/webforge, for example /opt. Production services continue using /opt/webforge. Take protected source/data/Caddy backups first and retain the old .next output for rollback.

Verification covers hostname normalization, ownership proof, IPv4/IPv6 constraints, valid and refused certificate authorization, public endpoint isolation, cross-account modification, DNS-proven takeover, unpublication/billing suspension, removal and temporary DNS outages. A real customer domain's DNS and certificate cannot be verified until its owner connects it.

Primary references: https://caddyserver.com/docs/automatic-https#on-demand-tls and https://caddyserver.com/docs/caddyfile/options#on-demand-tls.
