#!/usr/bin/python3
"""Refresh free local Melbourne trade listings from Geofabrik's Victoria extract."""
import datetime, hashlib, json, os, pathlib, subprocess, tempfile, time, urllib.request
import osmium
os.umask(0o077)
root = pathlib.Path('/var/lib/webforge')
cache = pathlib.Path('/var/cache/webforge-osm')
cache.mkdir(parents=True, exist_ok=True)
out = root / 'osm-melbourne-cache.json'
try:
    previous = json.loads(out.read_text())
    if time.time()*1000-previous['fetchedAt'] < 6*86400000:
        print('Local discovery dataset remains fresh'); raise SystemExit(0)
except (OSError, ValueError, KeyError): pass
url = 'https://download.geofabrik.de/australia-oceania/australia/victoria-latest.osm.pbf'
pbf = cache/'victoria-latest.osm.pbf'
if not pbf.exists() or time.time()-pbf.stat().st_mtime > 86400:
    with tempfile.TemporaryDirectory(dir=cache) as tmp:
        download=pathlib.Path(tmp)/'victoria.osm.pbf'
        subprocess.run(['curl','-4','--fail','--location','--silent','--show-error','--connect-timeout','15','--max-time','600',url,'-o',str(download)],check=True)
        subprocess.run(['osmium','fileinfo',str(download)],check=True,stdout=subprocess.DEVNULL)
        os.replace(download,pbf)
trades={'plumber','electrician','carpenter','painter','roofer','hvac','builder','handyman','gardener','landscaper','locksmith','cleaning'}
class Listings(osmium.SimpleHandler):
    def __init__(self): super().__init__(); self.elements=[]
    def record(self,obj,kind,lat,lon):
        tags=dict(obj.tags)
        if not (-38.2<=lat<=-37.5 and 144.5<=lon<=145.5): return
        if tags.get('craft') not in trades and tags.get('shop')!='car_repair': return
        if not tags.get('name') or not (tags.get('website') or tags.get('contact:website')): return
        self.elements.append({'type':kind,'id':obj.id,'tags':{k:v for k,v in tags.items() if k in ['name','website','contact:website','craft','shop']}})
    def node(self,n):
        if n.location.valid(): self.record(n,'node',n.location.lat,n.location.lon)
    def way(self,w):
        points=[n.location for n in w.nodes if n.location.valid()]
        if points: self.record(w,'way',sum(p.lat for p in points)/len(points),sum(p.lon for p in points)/len(points))
with tempfile.TemporaryDirectory(dir=cache) as tmp:
    filtered=pathlib.Path(tmp)/'trades.osm.pbf'
    subprocess.run(['osmium','tags-filter',str(pbf),'nwr/craft','nwr/shop=car_repair','-o',str(filtered)],check=True)
    handler=Listings();handler.apply_file(str(filtered),locations=True)
    data={'fetchedAt':int(time.time()*1000),'source':url,'attribution':'© OpenStreetMap contributors; ODbL https://www.openstreetmap.org/copyright','elements':handler.elements}
    atomic=out.with_suffix('.tmp');atomic.write_text(json.dumps(data));os.chmod(atomic,0o600);os.replace(atomic,out)
    print('Melbourne mapped trade listings with websites:',len(handler.elements))
