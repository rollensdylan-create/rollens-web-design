# WebForge Mission Control

A runnable local website production system built from the recovered **AATLAS WebForge Mission Control — Master OpenCode Build Prompt** in [Automated Website Rating System](https://chatgpt.com/c/6a87d6a0-93f0-83ec-9bf1-dacf2a3646a1), 21 August 2026.

## Run

Requires Node.js 24 and pnpm. The supplied `Start WebForge.command` also locates the Codex bundled Node runtime on this Mac.

```sh
pnpm install
pnpm exec playwright install chromium
pnpm build
pnpm start
```

In a second terminal, in the same directory:

```sh
pnpm worker
```

Open **http://127.0.0.1:4333**. The UI reports worker connectivity. Both processes must use the same environment and data directory. `.env.local` is read by Next.js and the worker command. To stop, press Ctrl-C in each terminal. Alternatively double-click `Start WebForge.command` to run both together after installation/build.

## Automated business pipeline

Use **Autopilot** at `/automation` for scheduled business discovery/imports, threshold filtering, automatic demo builds and QA, templated permission-based outreach and Stripe subscription checkout. Campaign targets, limits, sender, price, template and encrypted connection settings are managed in the UI. See [AUTOPILOT.md](AUTOPILOT.md) for setup, lifecycle and validation limits.

## First mission

Choose **New mission**, enter a business name and public HTTP(S) website URL, and launch. The worker performs bounded discovery, captures the homepage at 1440/768/390px, extracts public facts, calculates a weighted audit, creates a strategy, builds an original static redesign, runs viewport QA and saves a local preview.

**Training fixture** uses explicitly simulated source data for Northline Electrical. Its template generation, browser QA and demo screenshots are real. No fixture source screenshot is fabricated. You can distinguish fixtures in the mission header, event history and generated preview.

## What is real

- SQLite persistence with WAL, relational businesses/missions/stage runs/events and transactional queue claims.
- Separate worker, heartbeat, process lock, restart recovery and stage checkpoints.
- Real URL validation, public IP checks, pinned DNS connections, redirect validation and bounded HTTP fetches.
- Public browser scan with network interception, service workers blocked and no WebSockets.
- Crawl bounds: max pages, depth, timeout and response size. Source snapshots and extracted JSON are retained.
- Real screenshots and horizontal overflow/runtime checks at three viewports.
- Weighted deterministic audit, labelled structural heuristics, real findings and explicit methodology.
- Deterministic strategy and original factual demo template by default. No AI expense in this mode.
- Optional schema-validated OpenAI-compatible strategy adapter.
- Optional controlled OpenCode subprocess adapter, timeout and bounded QA fix loop.
- QA of generated markup at three widths: runtime errors, broken images, section navigation, primary contact actions and overflow.
- SSE activity, queue list, overview, mission detail, audit, strategy, source facts, artifacts, business directory, demo library and configuration.
- Real pause/resume/cancel/retry/rebuild/rerun-QA controls.

## Control semantics

Pause and cancel are **stage boundary controls**. A running browser fetch or configured agent process finishes or times out before the worker stops. The UI explicitly labels pending pause. Cancelled missions cannot be resumed. Retrying a failed stage resumes from the last successful checkpoint; rebuilding resumes at BUILD; rerun-QA resumes at QA.

One worker processes one mission at a time. A lock prevents duplicate workers. On restart, an interrupted mission is marked failed with an inspection/retry message; it is not silently restarted. HTTP requests retry transient connection failures with bounded backoff; mission failures remain visible and require operator retry.

## Local data

`.data/webforge.sqlite` is the persistent database. Each mission has a directory under `.data/missions/<id>/` with:

```
input/mission.json
scan/site-data.json, metrics.json, page-N.html
screenshots/source-{1440,768,390}.png
screenshots/demo-{1440,768,390}.png
audit/audit.json
strategy/strategy.json
build/index.html, build-result.json
qa/qa-results.json
```

Do not delete `.data` if you want to retain mission history. Back it up while both processes are stopped. Artifacts are served with a sandbox CSP: scripts, external resources, forms and base tags are disabled. The dashboard does not embed untrusted HTML with the operator origin.

## Optional AI strategy

Set `AI_PROVIDER=compatible`, `AI_BASE_URL`, `AI_MODEL`, and `AI_API_KEY` in `.env.local`; restart UI and worker. The provider uses `/chat/completions`, validates returned JSON and records reported token counts. Model pricing is deliberately not guessed. The dedicated prompt treats source content as untrusted data. This provider changes strategy only; template generation remains deterministic unless an agent is configured.

## Optional OpenCode build worker

The adapter invokes:

```
<OPENCODE_PATH> run --standalone --format json --model <OPENCODE_MODEL> <focused task>
```

It passes only a minimal environment, an isolated HOME, restricted OpenCode permissions and factual workspace files. No secret values or general operator environment are passed. Raw output is withheld because it can contain private reasoning; the event log records task-level status and exit metadata.

For enabled execution, set `AGENT_MODE=opencode`, `OPENCODE_PATH`, `OPENCODE_MODEL`, `ALLOW_LOCAL_AGENT=1` and optionally `WEBFORGE_AGENT_HOME`. Use a wrapper that runs the CLI in an OS/container sandbox exposing **only the current build directory**. Permission prompts are not a substitute for OS isolation. OpenCode credentials must be supplied deliberately within the isolated agent environment. The default build does not run OpenCode and never claims to. CLI argument compatibility was checked against the installed app; actual model-driven execution has not been validated or enabled.

The worker constrains the generated contract to a single self-contained HTML file. A framework build agent with arbitrary package installation would need stronger isolation and a separate preview server manager.

## Scope and limits

This is the prompt's runnable local MVP. It uses SQLite rather than requiring PostgreSQL just to boot; `db/postgres-reference.sql` records the production relational migration target. It is not a PostgreSQL-backed production deployment. The Next frontend is TypeScript/App Router with plain CSS; generated demos are static HTML/CSS, avoiding a dependency installation and server per prospect.

The audit's visual/design category is a structural heuristic, not a subjective visual AI review. Performance checks use fetch time and markup size, not Lighthouse or Core Web Vitals. It does not submit source forms or book appointments. The optional configured Autopilot sends permissioned outreach through Resend and creates Stripe subscription Checkout sessions. Public demo hosting and purchased-site fulfilment require deployment configuration. Source content can be incomplete on blocked or heavily dynamic sites. Source browser screenshots may fail on anti-bot websites; this is recorded as failure rather than invented success.

The local UI binds to loopback and checks host/origin on operator APIs. It is intended for a trusted user on this computer; the optional bearer token adds API protection but there is no login UI. Before network/public hosting, add authenticated sessions, roles, rate limiting, isolated worker hosts, storage access controls and production egress enforcement. Do not expose this server through a tunnel.

## Validation

```sh
pnpm test
pnpm typecheck
pnpm lint
pnpm build
```

Integration validation exercises a training mission and public live scan, browser-generated previews, API controls and failure handling. See `IMPLEMENTATION_STATUS.md` for results.
