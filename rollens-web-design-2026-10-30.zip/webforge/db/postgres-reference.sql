-- Production migration target; local runtime uses node:sqlite, not this file.
CREATE TABLE businesses(id UUID PRIMARY KEY,name TEXT NOT NULL,url TEXT NOT NULL UNIQUE,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE missions(id UUID PRIMARY KEY,business_id UUID NOT NULL REFERENCES businesses(id),status TEXT NOT NULL CHECK(status IN ('QUEUED','RUNNING','PAUSED','COMPLETED','FAILED','CANCELLED')),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),data JSONB NOT NULL);
CREATE INDEX missions_queue_idx ON missions(status,created_at);
CREATE TABLE events(id BIGSERIAL PRIMARY KEY,mission_id UUID NOT NULL REFERENCES missions(id),timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),stage TEXT NOT NULL,type TEXT NOT NULL,severity TEXT NOT NULL,message TEXT NOT NULL,metadata JSONB NOT NULL DEFAULT '{}');
CREATE INDEX events_mission_idx ON events(mission_id,id);
CREATE TABLE stage_runs(id BIGSERIAL PRIMARY KEY,mission_id UUID NOT NULL REFERENCES missions(id),stage TEXT NOT NULL,status TEXT NOT NULL,started_at TIMESTAMPTZ NOT NULL,finished_at TIMESTAMPTZ,error TEXT);
-- Use SELECT ... FOR UPDATE SKIP LOCKED for distributed queue claims.
-- Migrate the JSON audit/strategy/demo payloads into dedicated typed tables when multi-user reporting requires it.
