import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type Stripe from "stripe";
process.env.WEBFORGE_DATA_DIR = await mkdtemp(
  path.join(os.tmpdir(), "rollens-selfserve-"),
);
process.env.SELF_SERVE_PAYMENTS_ENABLED = "true";
process.env.PUBLIC_BASE_URL = "https://rollens.example.test";
process.env.STRIPE_SECRET_KEY = "rk_test_fixture";
process.env.STRIPE_WEBHOOK_SECRET = "whsec_fixture";
const { db } = await import("../src/lib/db");
const {
  authenticate,
  sessionFor,
  userFor,
  logout,
  saveSite,
  publish,
  liveSite,
  sitesFor,
  createCheckout,
  applySiteBillingEvent,
  resetPassword,
  SiteData,
  portal,
} = await import("../src/lib/selfserve");
const { renderCustomerSite } = await import("../src/lib/customer-site");
const { POST } = await import("../src/app/api/public/account/route");
const userId = authenticate("owner@example.test", "a-long-test-password", true);
const getUser = () =>
  db.prepare("SELECT * FROM site_users WHERE id=?").get(userId) as any;
const data = {
  name: "A real business",
  brief: "Honest services for local customers.",
  email: "owner@example.test",
  phone: "0400 123 456",
  area: "Melbourne",
  services: ["Repairs"],
  theme: 0,
  personal: false,
  gallery: [],
};
let siteId = "";
let status = "active";
let invoiceStatus = "paid";
let sessionStatus = "open";
let sessionPlan = "starter";
let creates = 0;
const client = {
  products: { create: async () => ({ id: "prod_starter" }) },
  prices: {
    create: async (params: any) => {
      assert.equal(params.unit_amount, 1999);
      return { id: "price_starter" };
    },
  },
  checkout: {
    sessions: {
      create: async (params: any) => {
        creates++;
        sessionPlan = params.metadata.plan;
        assert.equal(params.line_items[0].price, "price_starter");
        assert.equal(params.mode, "subscription");
        assert.equal(params.payment_method_types, undefined);
        return { id: "cs_fixture", url: "https://checkout.stripe.com/test" };
      },
      retrieve: async () => ({
        id: "cs_fixture",
        status: sessionStatus,
        payment_status: sessionStatus === "complete" ? "paid" : "unpaid",
        metadata: { plan: sessionPlan },
        subscription: "sub_fixture",
        customer: "cus_fixture",
        url: "https://checkout.stripe.com/test",
      }),
      expire: async () => ({}),
    },
  },
  subscriptions: {
    retrieve: async () => ({
      id: "sub_fixture",
      status,
      items: { data: [{ price: { id: "price_starter" } }] },
      latest_invoice: { status: invoiceStatus },
    }),
  },
} as unknown as Stripe;
const event = (id: string, type: string, obj: any) =>
  ({
    id,
    type,
    created: Date.now() / 1000,
    data: { object: obj },
  }) as Stripe.Event;
test("account passwords are hashed, sessions expire and logout revokes access", () => {
  assert.equal(
    authenticate("owner@example.test", "a-long-test-password"),
    userId,
  );
  assert.throws(() =>
    authenticate("owner@example.test", "incorrect-long-password"),
  );
  assert.notEqual(getUser().password, "a-long-test-password");
  const token = sessionFor(userId);
  const req = new Request("https://rollens.example.test", {
    headers: { cookie: `rollens_session=${token}` },
  });
  assert.equal(userFor(req)?.id, userId);
  logout(req);
  assert.equal(userFor(req), undefined);
});
test("unpaid sites stay private, ownership is enforced and Starter limits are real", () => {
  siteId = saveSite(getUser(), data);
  const site = sitesFor(userId)[0];
  assert.equal(liveSite(site.slug), null);
  assert.throws(() => publish(getUser(), siteId, true));
  assert.throws(() => saveSite(getUser(), data));
  assert.throws(() =>
    saveSite({ ...getUser(), id: "another-user" }, data, siteId),
  );
  saveSite(
    getUser(),
    { ...data, gallery: ["https://images.example.test/photo.jpg"] },
    siteId,
  );
  assert.equal(sitesFor(userId)[0].data.gallery.length, 1);
  saveSite(getUser(), data, siteId);
});
test("checkout uses server prices, reuses sessions and prevents overlapping checkout", async () => {
  const u = getUser();
  assert.equal(
    await createCheckout(u, "starter", client),
    "https://checkout.stripe.com/test",
  );
  assert.equal(
    await createCheckout(getUser(), "starter", client),
    "https://checkout.stripe.com/test",
  );
  assert.equal(creates, 1);
  db.prepare("INSERT INTO site_checkout_locks VALUES(?,?)").run(
    userId,
    Date.now(),
  );
  await assert.rejects(
    createCheckout(getUser(), "plus", client),
    /already being prepared/,
  );
  db.prepare("DELETE FROM site_checkout_locks").run();
});
test("only verified paid checkout publishes; duplicate fulfillment never republishes a manually hidden site", async () => {
  await applySiteBillingEvent(
    event("evt_unpaid", "checkout.session.completed", { id: "cs_fixture" }),
    client,
  );
  assert.equal(getUser().enabled, 0);
  saveSite(getUser(), { ...data, name: "Unapproved later draft" }, siteId);
  sessionStatus = "complete";
  await applySiteBillingEvent(
    event("evt_paid", "checkout.session.completed", { id: "cs_fixture" }),
    client,
  );
  assert.equal(getUser().enabled, 1);
  const site = sitesFor(userId)[0];
  assert.ok(liveSite(site.slug));
  assert.equal(site.data.name, data.name);
  assert.throws(
    () =>
      saveSite(
        getUser(),
        { ...data, brief: "A changed introduction." },
        siteId,
      ),
    /draft editing only/,
  );
  publish(getUser(), siteId, false);
  assert.throws(() => saveSite(getUser(), data, siteId), /draft editing only/);
  await applySiteBillingEvent(
    event("evt_paid_again", "checkout.session.async_payment_succeeded", {
      id: "cs_fixture",
    }),
    client,
  );
  assert.equal(liveSite(site.slug), null);
  await assert.rejects(
    createCheckout(getUser(), "plus", client),
    /existing subscription/,
  );
});
test("failed recurring payment suspends publication, recovery restores access, cancellation ends hosting", async () => {
  publish(getUser(), siteId, true);
  invoiceStatus = "open";
  status = "past_due";
  await applySiteBillingEvent(
    event("evt_failed", "invoice.payment_failed", {
      parent: { subscription_details: { subscription: "sub_fixture" } },
    }),
    client,
  );
  assert.equal(getUser().enabled, 0);
  assert.equal(liveSite(sitesFor(userId)[0].slug), null);
  invoiceStatus = "paid";
  status = "active";
  await applySiteBillingEvent(
    event("evt_recovered", "invoice.paid", {
      parent: { subscription_details: { subscription: "sub_fixture" } },
    }),
    client,
  );
  assert.equal(getUser().enabled, 1);
  status = "canceled";
  await applySiteBillingEvent(
    event("evt_cancelled", "customer.subscription.deleted", {
      id: "sub_fixture",
    }),
    client,
  );
  assert.equal(getUser().enabled, 0);
  assert.equal(getUser().subscription, null);
});
test("Plus and Pro enforce distinct website and gallery capacities", () => {
  const plus = authenticate("plus@example.test", "a-long-test-password", true);
  db.prepare("UPDATE site_users SET plan='plus',enabled=1 WHERE id=?").run(
    plus,
  );
  const u = db.prepare("SELECT * FROM site_users WHERE id=?").get(plus) as any;
  const plusSite = saveSite(u, {
    ...data,
    gallery: Array(40).fill("https://images.example.test/work.jpg"),
    services: Array(80).fill("Service"),
  });
  assert.throws(() => saveSite(u, data));
  publish(u, plusSite, true);
  assert.throws(() => saveSite(u, data, plusSite), /draft editing only/);
  publish(u, plusSite, false);
  assert.throws(() => saveSite(u, data, plusSite), /draft editing only/);
  const pro = authenticate("pro@example.test", "a-long-test-password", true);
  db.prepare("UPDATE site_users SET plan='pro',enabled=1 WHERE id=?").run(pro);
  const p = db.prepare("SELECT * FROM site_users WHERE id=?").get(pro) as any;
  for (let i = 0; i < 10; i++)
    saveSite(p, {
      ...data,
      gallery: Array(18).fill("https://images.example.test/work.jpg"),
      services: Array(24).fill("Service"),
    });
  assert.throws(() => saveSite(p, data));
  const site = sitesFor(pro)[0];
  publish(p, site.id, true);
  saveSite(p, { ...data, name: "Updated live" }, site.id);
  assert.equal(liveSite(site.slug)?.name, "Updated live");
});
test("public HTML escapes content and refuses script image URLs", () => {
  const html = renderCustomerSite({
    ...data,
    name: "<script>alert(1)</script>",
    brief: "<img src=x onerror=alert(1)>",
  });
  assert.ok(!html.includes("<script>"));
  assert.ok(html.includes("&lt;script&gt;"));
  assert.throws(() =>
    SiteData.parse({ ...data, gallery: ["javascript:alert(1)"] }),
  );
  assert.throws(() => resetPassword("unknown", "a-long-test-password"));
});
test("account API rejects foreign-origin writes and unauthenticated publishing", async () => {
  let response = await POST(
    new Request("https://rollens.example.test/api/public/account", {
      method: "POST",
      headers: { origin: "https://evil.example.test" },
      body: JSON.stringify({ action: "publish", id: siteId, published: true }),
    }),
  );
  assert.equal(response.status, 403);
  response = await POST(
    new Request("https://rollens.example.test/api/public/account", {
      method: "POST",
      headers: { origin: process.env.PUBLIC_BASE_URL! },
      body: JSON.stringify({ action: "publish", id: siteId, published: true }),
    }),
  );
  assert.equal(response.status, 401);
});

test("middle plan allows full draft editing but locks on publication at the requested prices", async () => {
  const { SITE_PLANS } = await import("../src/lib/site-plans");
  assert.equal(SITE_PLANS.starter.cents, 1999);
  assert.equal(SITE_PLANS.plus.cents, 3300);
  assert.equal(SITE_PLANS.pro.cents, 9900);
  const id = authenticate(
    "editable@example.test",
    "a-long-test-password",
    true,
  );
  db.prepare("UPDATE site_users SET plan='plus',enabled=1 WHERE id=?").run(id);
  const u = db.prepare("SELECT * FROM site_users WHERE id=?").get(id) as any;
  const site = saveSite(u, data);
  saveSite(
    u,
    { ...data, brief: "A fresh introduction before publication." },
    site,
  );
  publish(u, site, true);
  assert.throws(() => saveSite(u, data, site), /draft editing only/);
  assert.equal(
    sitesFor(id)[0].data.brief,
    "A fresh introduction before publication.",
  );
});
test("private Stripe setup endpoint rejects public hosts without exposing secrets", async () => {
  const { GET } = await import("../src/app/api/connections/route");
  const r = await GET(
    new Request("https://rollens.example.test/api/connections", {
      headers: { host: "rollens.example.test" },
    }),
  );
  assert.equal(r.status, 403);
});

test("editor rendering preserves long content, selection targets and custom SEO without scripts", () => {
  const html = renderCustomerSite(
    {
      ...data,
      services: Array.from({ length: 40 }, (_, i) => `Service ${i}`),
      headline: "A custom headline",
      seoTitle: "A custom search title",
      branding: false,
    },
    true,
  );
  assert.ok(html.includes("Service 39"));
  assert.ok(html.includes('data-edit-field="services.39"'));
  assert.ok(html.includes("A custom headline"));
  assert.ok(html.includes("<title>A custom search title</title>"));
  assert.ok(!html.includes("<script>"));
  assert.ok(!html.includes('href="https://rollenswebdesign.space"'));
});
test("paid Starter cannot bypass image, SEO or footer entitlements", () => {
  const id = authenticate(
    "starterlimited@example.test",
    "a-long-test-password",
    true,
  );
  db.prepare("UPDATE site_users SET plan='starter',enabled=1 WHERE id=?").run(
    id,
  );
  const u = db.prepare("SELECT * FROM site_users WHERE id=?").get(id) as any;
  for (const extra of [
    { gallery: ["https://images.example.test/work.jpg"] },
    { seoTitle: "Custom" },
    { branding: false },
  ])
    assert.throws(() => saveSite(u, { ...data, ...extra }));
});
test("photo uploads require ownership session and safely resize real images", async () => {
  const { POST: upload } =
    await import("../src/app/api/public/site-image/route");
  const { GET: image } =
    await import("../src/app/api/public/site-image/[id]/route");
  const sharp = (await import("sharp")).default;
  const png = await sharp({
    create: { width: 3000, height: 100, channels: 3, background: "#ff8800" },
  })
    .png()
    .toBuffer();
  const form = () => {
    const f = new FormData();
    f.set("image", new File([png], "test.png", { type: "image/png" }));
    return f;
  };
  const unauth = await upload(
    new Request(process.env.PUBLIC_BASE_URL + "/api/public/site-image", {
      method: "POST",
      headers: { origin: process.env.PUBLIC_BASE_URL! },
      body: form(),
    }),
  );
  assert.equal(unauth.status, 401);
  const token = sessionFor(userId);
  const response = await upload(
    new Request(process.env.PUBLIC_BASE_URL + "/api/public/site-image", {
      method: "POST",
      headers: {
        origin: process.env.PUBLIC_BASE_URL!,
        cookie: `rollens_session=${token}`,
      },
      body: form(),
    }),
  );
  assert.equal(response.status, 200);
  const result = await response.json();
  const id = result.url.split("/").at(-1);
  const file = await image(new Request(result.url), {
    params: Promise.resolve({ id }),
  });
  assert.equal(file.status, 200);
  const meta = await sharp(Buffer.from(await file.arrayBuffer())).metadata();
  assert.equal(meta.format, "jpeg");
  assert.equal(meta.width, 2400);
  const bad = await image(new Request(result.url), {
    params: Promise.resolve({ id: ".." }),
  });
  assert.equal(bad.status, 404);
});

test("billing portal offers upgrades without lower-tier downgrades", async () => {
  const id = authenticate("portal@example.test", "a-long-test-password", true);
  db.prepare(
    "UPDATE site_users SET plan='plus',customer='cus_portal',enabled=1 WHERE id=?",
  ).run(id);
  db.prepare(
    "INSERT OR REPLACE INTO site_catalog VALUES('plus','price_plus','prod_plus','test'),('pro','price_pro','prod_pro','test')",
  ).run();
  let config: any;
  const mock = {
    prices: {
      retrieve: async (id: string) => ({
        active: true,
        unit_amount: id === "price_plus" ? 3300 : 9900,
        currency: "aud",
        recurring: { interval: "month" },
      }),
    },
    billingPortal: {
      configurations: {
        create: async (p: any) => {
          config = p;
          return { id: "bpc_fixture" };
        },
      },
      sessions: {
        create: async () => ({ url: "https://billing.stripe.com/fixture" }),
      },
    },
  } as unknown as Stripe;
  const u = db.prepare("SELECT * FROM site_users WHERE id=?").get(id) as any;
  assert.equal(await portal(u, mock), "https://billing.stripe.com/fixture");
  assert.deepEqual(
    config.features.subscription_update.products.map((p: any) => p.product),
    ["prod_plus", "prod_pro"],
  );
  assert.equal(
    config.features.subscription_update.proration_behavior,
    "always_invoice",
  );
});
