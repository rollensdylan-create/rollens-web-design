import { test } from "node:test";
import assert from "node:assert/strict";
import { parsePage, normalizePhone, fixtureScan } from "../src/lib/scanner";
import { sourceProblems } from "../src/lib/source-quality";
import { renderDemo } from "../src/lib/demo";
import type { Mission } from "../src/lib/types";
test("Australian contacts normalize tel links and structured data without swallowing extra digits", () => {
  const p = parsePage(
    `<html><body><h1>Local workshop</h1><p>Servicing local vehicles with repairs, inspections and maintenance. Find the workshop and get in touch.</p><a href="tel:+61%203%209000%201234">Call</a><script type="application/ld+json">{"@type":"AutoRepair","telephone":"+61 412 345 678","email":"workshop@example.test"}</script><p>Malformed 07394704039 and 03969042830</p></body></html>`,
    "https://example.test",
  );
  assert.deepEqual(p.phones, ["0390001234", "0412345678"]);
  assert.ok(p.emails.includes("workshop@example.test"));
  assert.equal(normalizePhone("03969042830"), null);
  assert.equal(normalizePhone("1300 123 456"), "1300123456");
});
test("challenge responses and consent shells cannot qualify as demos", () => {
  for (const html of [
    '<meta http-equiv="refresh" content="0;url=/.well-known/sgcaptcha">',
    '<body><div id="app"></div><script src="app.js"></script></body>',
  ]) {
    const page = parsePage(html, "https://example.test", 202);
    assert.ok(page.blocked);
    const scan = { ...fixtureScan(), pages: [page] };
    assert.ok(sourceProblems(scan).length);
    assert.throws(
      () =>
        renderDemo({
          name: "Bad source",
          websiteUrl: page.url,
          scan,
          mode: "live",
        } as Mission),
      /Demo blocked/,
    );
  }
});
test("demo uses contacts and services from contact pages, not only the homepage", () => {
  const scan = fixtureScan();
  scan.pages[0].emails = [];
  scan.pages[0].phones = [];
  scan.pages.push(
    parsePage(
      '<body><h1>Contact</h1><p>For our electrical repair and maintenance services, please contact our Melbourne office to discuss your requirements.</p><a href="mailto:office@example.test">Email us</a><a href="tel:0395551234">Call</a><h2>Emergency repairs</h2></body>',
      "https://northline.example.test/contact",
    ),
  );
  const html = renderDemo({
    name: "Northline Electrical",
    websiteUrl: scan.pages[0].url,
    scan,
    mode: "live",
  } as Mission);
  assert.ok(html.includes("office@example.test"));
  assert.ok(html.includes("0395551234"));
  assert.ok(html.includes("Emergency repairs"));
  assert.ok(!html.includes("Here to help."));
  assert.ok(!html.includes("Licensed and insured"));
});

test("normal Wix captcha asset names do not turn real business content into a challenge", () => {
  const p = parsePage(
    '<script>window.assets=["captcha"]</script><body><h1>Local mechanics</h1><h2>Vehicle repairs</h2><p>Our Melbourne workshop provides maintenance and vehicle repairs. Contact our team to discuss your vehicle requirements.</p><a href="tel:0390001234">Call us</a></body>',
    "https://example.test",
  );
  assert.equal(p.blocked, undefined);
});

test("service extraction rejects marketing headings and finds concrete service navigation", () => {
  const p = parsePage(
    '<body><h2>Get a FREE Quote</h2><h2>Make use of the span of gardening services we offer</h2><h2>See what else does Gardeners Melbourne give you</h2><a href="/hedge-trimming">Hedge trimming</a><a href="/garden-maintenance">Garden maintenance</a></body>',
    "https://example.test",
  );
  assert.deepEqual(p.services, ["Hedge trimming", "Garden maintenance"]);
});

test("local phone numbers are retained as published without inventing an area code", () => {
  const p = parsePage(
    "<body><h1>Workshop</h1><h2>Vehicle repairs</h2><p>Our workshop provides vehicle maintenance and repairs for local customers. Contact Us 9470 4039</p></body>",
    "https://example.test/contact",
  );
  assert.ok(p.phones.includes("94704039"));
  assert.ok(!p.phones.includes("0394704039"));
});

test("Wix service labels inside paragraphs are extracted without testimonial headings", () => {
  const p = parsePage(
    "<title>Gilbert Road Motors</title><body><h2>Great customer service</h2><p><span>LOGBOOK SERVICING</span></p><p><span>EXHAUST SERVICES</span></p><p>Our team provides vehicle maintenance and repairs. Contact Us 9470 4039</p></body>",
    "https://example.test",
  );
  assert.ok(p.services.includes("LOGBOOK SERVICING"));
  assert.ok(p.services.includes("EXHAUST SERVICES"));
  assert.ok(!p.services.includes("Great customer service"));
});

test("nested service menus yield individual labels rather than merged parent text", () => {
  const p = parsePage(
    "<body><ul><li><span>Garden Maintenance</span><span>Lawn Mowing</span><span>Hedge Trimming</span></li></ul><span>Gardeners Melbourne</span></body>",
    "https://gardeners-melbourne.com.au",
  );
  assert.deepEqual(p.services, [
    "Garden Maintenance",
    "Lawn Mowing",
    "Hedge Trimming",
  ]);
});
