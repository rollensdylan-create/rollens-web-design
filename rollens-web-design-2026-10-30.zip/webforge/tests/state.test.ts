import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
const dir = await mkdtemp(path.join(os.tmpdir(), "webforge-test-"));
process.env.WEBFORGE_DATA_DIR = dir;
const { createMission, getMission, claim, control, saveMission, events } =
  await import("../src/lib/db");
test("durable queue validates controls and resumes at last saved stage", () => {
  const m = createMission("https://example.test", "Example", "fixture");
  assert.equal(m.status, "QUEUED");
  control(m.id, "pause");
  assert.equal(claim(), null);
  control(m.id, "resume");
  const running = claim()!;
  assert.equal(running.id, m.id);
  assert.equal(claim(), null);
  control(m.id, "pause");
  assert.equal(getMission(m.id)!.pauseRequested, true);
  running.status = "PAUSED";
  running.pauseRequested = false;
  running.nextStage = 3;
  saveMission(running);
  control(m.id, "resume");
  assert.equal(claim()!.nextStage, 3);
  control(m.id, "cancel");
  assert.equal(getMission(m.id)!.status, "CANCELLED");
  assert.throws(() => control(m.id, "resume"));
  assert(events(m.id).length >= 5);
});
test("failed retry preserves stage and rebuild resets build checkpoint", () => {
  const m = createMission("https://another.example.test", "Another", "fixture");
  m.status = "FAILED";
  m.nextStage = 2;
  m.error = "network";
  saveMission(m);
  control(m.id, "retry");
  assert.equal(getMission(m.id)!.nextStage, 2);
  assert.equal(getMission(m.id)!.error, null);
  m.status = "COMPLETED";
  saveMission(m);
  control(m.id, "rebuild");
  assert.equal(getMission(m.id)!.nextStage, 5);
});
process.on("exit", () => {
  rm(dir, { recursive: true, force: true }).catch(() => {});
});
