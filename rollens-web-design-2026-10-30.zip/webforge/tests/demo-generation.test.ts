import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
process.env.WEBFORGE_DATA_DIR = await mkdtemp(
  path.join(os.tmpdir(), "webforge-design-test-"),
);
const { buildDemo } = await import("../src/lib/demo");
const { fixtureScan } = await import("../src/lib/scanner");
const { renderCustomerSite } = await import("../src/lib/customer-site");
const { workspace } = await import("../src/lib/artifacts");
const base = {
  id: "design-test",
  name: "Local Workshop",
  websiteUrl: "https://example.test",
  mode: "live",
  scan: fixtureScan(),
  usage: { agentExecutions: 0 },
} as any;
test("normal automated build uses the photo pipeline and the redesigned renderer", async () => {
  let called = false;
  await buildDemo(
    base,
    () => {},
    async () => {
      called = true;
      return {
        photos: [
          {
            data: "data:image/jpeg;base64,dGVzdA==",
            source: "https://example.test/workshop.jpg",
            alt: "Workshop",
          },
        ],
      };
    },
  );
  assert.equal(called, true);
  const html = await readFile(
    path.join(workspace(base.id), "build/index.html"),
    "utf8",
  );
  assert.ok(html.includes("data:image/jpeg;base64,dGVzdA=="));
  assert.ok(html.includes("services-grid"));
  assert.ok(!html.includes("Original abstract geometric illustration"));
});
test("automated live builds with no suitable photography are held for review", async () => {
  await assert.rejects(
    buildDemo(
      { ...base, id: "no-photo" },
      () => {},
      async () => ({ photos: [] }),
    ),
    /no suitable source photography/,
  );
});
test("self-service publication uses the shared design without prospect disclaimers", () => {
  const html = renderCustomerSite({
    name: "My Garden Business",
    brief: "Garden maintenance for local customers.",
    email: "hello@example.test",
    phone: "0390001234",
    area: "Melbourne",
    services: ["Lawn mowing"],
    theme: 1,
    personal: false,
    gallery: ["https://example.test/garden.jpg"],
  });
  assert.ok(html.includes("customer theme-1"));
  assert.ok(html.includes("https://example.test/garden.jpg"));
  assert.ok(html.includes("Melbourne"));
  assert.ok(html.includes("Lawn mowing"));
  assert.ok(!html.includes('class="preview-note"'));
  assert.ok(!html.includes("Independent redesign concept"));
});
test("personal websites retain their own work labels and avoid automotive copy", () => {
  const html = renderCustomerSite({
    name: "Alex",
    brief: "Photography and creative projects from Melbourne.",
    email: "alex@example.test",
    phone: "",
    area: "Melbourne",
    services: ["Portraits", "Editorial work"],
    theme: 2,
    personal: true,
    gallery: [],
  });
  assert.ok(html.includes("Portraits"));
  assert.ok(html.includes("Your work."));
  assert.ok(!html.includes("Call the workshop"));
});
