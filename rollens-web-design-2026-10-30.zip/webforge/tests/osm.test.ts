import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
process.env.WEBFORGE_DATA_DIR = await mkdtemp(
  path.join(os.tmpdir(), "webforge-osm-"),
);
const { parseOsmLeads, osmMelbourneLeads } =
  await import("../src/lib/osm-discovery");
test("map listings retain source evidence, deduplicate domains and do not import recipient permission", () => {
  const leads = parseOsmLeads({
    elements: [
      {
        type: "node",
        id: 1,
        tags: {
          name: "Trade",
          website: "https://www.trade.example/contact",
          email: "owner@trade.example",
        },
      },
      {
        type: "way",
        id: 2,
        tags: { name: "Duplicate", website: "https://trade.example" },
      },
      {
        type: "node",
        id: 3,
        tags: { name: "Other", "contact:website": "other.example" },
      },
      {
        type: "node",
        id: 4,
        tags: { name: "Bad", website: "https://user:password@bad.example" },
      },
      { type: "node", id: 5, tags: { name: "No website" } },
    ],
  });
  assert.equal(leads.length, 2);
  assert.equal(
    leads[0].discoverySourceUrl,
    "https://www.openstreetmap.org/node/1",
  );
  assert.equal(leads[1].url, "https://other.example");
  assert.equal("email" in leads[0], false);
  assert.equal("permission" in leads[0], false);
});
test("free discovery uses a local dataset without a network connection or API key", async () => {
  const file = path.join(process.env.WEBFORGE_DATA_DIR!, "dataset.json");
  await writeFile(
    file,
    JSON.stringify({
      fetchedAt: Date.now(),
      elements: [
        {
          type: "node",
          id: 7,
          tags: { name: "Trade", website: "https://trade.example" },
        },
      ],
    }),
  );
  assert.equal((await osmMelbourneLeads(file)).length, 1);
  assert.equal((await osmMelbourneLeads(file)).length, 1);
  await writeFile(
    file,
    JSON.stringify({ fetchedAt: Date.now() - 15 * 24 * 3600000, elements: [] }),
  );
  await assert.rejects(osmMelbourneLeads(file), /stale/);
  await assert.rejects(osmMelbourneLeads(file + ".missing"), /not loaded/);
});
