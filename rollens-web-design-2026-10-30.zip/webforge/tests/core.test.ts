import { test } from "node:test";
import assert from "node:assert/strict";
import {
  publicAddress,
  validateUrl,
  escapeHtml,
  authorize,
} from "../src/lib/security";
import { fixtureScan, parsePage } from "../src/lib/scanner";
import { calculateAudit } from "../src/lib/audit";
import { renderDemo } from "../src/lib/demo";
import type { Mission } from "../src/lib/types";
test("private, metadata, mapped IPv6 and loopback targets are blocked", async () => {
  for (const ip of [
    "127.0.0.1",
    "10.1.2.3",
    "169.254.169.254",
    "192.168.1.1",
    "172.31.1.1",
    "100.64.0.1",
    "::1",
    "fe80::1",
    "fc00::1",
    "::ffff:127.0.0.1",
  ])
    assert.equal(publicAddress(ip), false, ip);
  assert.equal(publicAddress("1.1.1.1"), true);
  for (const url of [
    "http://localhost",
    "http://127.0.0.1",
    "file:///etc/passwd",
    "https://user:pass@example.com",
    "http://example.com:4333",
  ])
    await assert.rejects(validateUrl(url));
});
test("operator endpoints enforce local host and same-origin mutations", () => {
  assert.equal(
    authorize(
      new Request("http://localhost:4333/api/missions", {
        headers: { host: "localhost:4333", origin: "https://evil.test" },
      }),
    ),
    false,
  );
  assert.equal(
    authorize(
      new Request("http://localhost:4333/api/missions", {
        headers: { host: "evil.test" },
      }),
    ),
    false,
  );
  assert.equal(
    authorize(
      new Request("http://localhost:4333/api/missions", {
        headers: { host: "localhost:4333" },
      }),
    ),
    true,
  );
});
test("parser extracts actual website facts and ignores script text", () => {
  const p = parsePage(
    '<title>Test</title><body><h1>Business</h1><h2>Repairs</h2><script>fake@example.test</script><p>real@example.test</p><img src="a"><a href="/contact">Contact</a></body>',
    "https://example.com",
  );
  assert.deepEqual(p.emails, ["real@example.test"]);
  assert.equal(p.missingAlt, 1);
  assert.equal(p.links[0].url, "https://example.com/contact");
  assert.deepEqual(p.services, ["Repairs"]);
});
test("weighted audit is reproducible and responsive failures lower scores", () => {
  const scan = fixtureScan();
  const audit = calculateAudit(scan);
  assert.equal(audit.overallScore, calculateAudit(scan).overallScore);
  assert(audit.findings.some((f) => f.id === "overflow"));
  const baseline = audit.scores.mobile;
  scan.pages[0].hasViewport = true;
  scan.viewports.forEach((v) => (v.overflow = false));
  assert(calculateAudit(scan).scores.mobile > baseline);
  assert(Object.values(audit.scores).every((x) => x >= 0 && x <= 100));
  assert.throws(() =>
    calculateAudit(scan, {
      design: 0,
      mobile: 0,
      conversion: 0,
      trust: 0,
      seo: 0,
      accessibility: 0,
      performance: 0,
    }),
  );
});
test("demo escapes untrusted business names and includes factual contacts", () => {
  const m = {
    name: "<script>alert(1)</script>",
    websiteUrl: "https://example.com",
    mode: "fixture",
    scan: fixtureScan(),
  } as Mission;
  const html = renderDemo(m);
  assert(!html.includes("<script>"));
  assert(html.includes("&lt;script&gt;"));
  assert(html.includes("hello@example.test"));
  assert(html.includes("Development fixture"));
  assert.equal(escapeHtml('"<>&'), "&quot;&lt;&gt;&amp;");
});
test("contact scraping extracts mailto-only addresses with source-page context", () => {
  const p = parsePage(
    '<body><h1>Business</h1><a href="mailto:owner%40example.test?subject=Hello">Email our team</a></body>',
    "https://example.com/contact",
  );
  assert.deepEqual(p.emails, ["owner@example.test"]);
  assert.equal(p.url, "https://example.com/contact");
});
