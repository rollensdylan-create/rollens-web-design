import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import Stripe from "stripe";
process.env.WEBFORGE_DATA_DIR = await mkdtemp(
  path.join(os.tmpdir(), "webforge-autotest-"),
);
process.env.RESEND_API_KEY = "re_test_fixture";
process.env.STRIPE_SECRET_KEY = "sk_test_fixture";
process.env.STRIPE_WEBHOOK_SECRET = "whsec_fixture";
process.env.PUBLIC_BASE_URL = "https://preview.example.test";
const {
  createCampaign,
  importProspect,
  enqueueProspect,
  reconcileProspect,
  prospect,
  campaign,
  saveCampaign,
  outbox,
  outreach,
  suppress,
} = await import("../src/lib/automation-store");
const { saveMission } = await import("../src/lib/db");
const { renderEmail, prepareOutreach, deliveryBlockers, dispatchOne } =
  await import("../src/lib/outreach");
const { checkout, applyStripeEvent } = await import("../src/lib/billing");
const { writeConnections, readConnections } =
  await import("../src/lib/connections");
const c = createCampaign({
  name: "Permitted automation test",
  threshold: 80,
  enabled: true,
  sendingEnabled: true,
  senderEmail: "hello@example.test",
  senderName: "Fixture sender",
  senderAddress: "Business address fixture",
});
function ready(name: string, domain: string, email: string) {
  const p = importProspect(c.id, {
    name,
    url: `https://${domain}`,
    email,
    permission: "EXPRESS",
    permissionEvidence: "Test fixture: explicit permission record",
  }).prospect;
  const m = enqueueProspect(p, c);
  m.status = "COMPLETED";
  m.automation!.qualified = true;
  m.audit = {
    overallScore: 45,
    scores: {},
    weights: {},
    findings: [],
    strengths: [],
    method: "Fixture",
  };
  m.scan = {
    name,
    pages: [],
    screenshots: [],
    viewports: [],
    brokenLinks: [],
    warnings: [],
  };
  m.qa = { status: "PASSED", checks: [], issues: [] };
  m.demo = {
    status: "PREVIEW_READY",
    previewUrl: "/fixture",
    framework: "fixture",
    buildStatus: "PASSED",
  };
  saveMission(m);
  reconcileProspect(m.id);
  return prospect(p.id)!;
}
const p = ready("Example business", "example.test", "owner@example.test");
test("domain deduplication does not create repeated scans", () => {
  assert.equal(
    importProspect(c.id, {
      name: "Duplicate",
      url: "https://www.example.test/contact",
    }).created,
    false,
  );
});
test("template variables resolve and always include unsubscribe", () => {
  const r = renderEmail(
    {
      ...c,
      template: "Hello {{business_name}}. {{price}}. Preview: {{preview_url}}",
    },
    p,
    "abc",
  );
  assert(r.text.includes("Hello Example business"));
  assert(r.text.includes("$33.00"));
  assert(r.text.includes("/api/public/unsubscribe/abc"));
  assert.throws(() =>
    renderEmail({ ...c, template: "{{unsupported_variable}}" }, p, "abc"),
  );
});
test("scraped contacts and missing permission cannot trigger sending", () => {
  const unknown = {
    ...p,
    permission: "UNKNOWN" as const,
    permissionEvidence: "",
  };
  assert(deliveryBlockers(c, unknown).some((s) => s.includes("permission")));
});
test("prepared emails send once, with stable idempotency and recipient links", async () => {
  await prepareOutreach(p, c);
  const o = outbox().find((o) => o.prospectId === p.id)!;
  let calls = 0;
  await dispatchOne(
    o,
    async (_url, options) => {
      calls++;
      assert.equal(
        new Headers(options?.headers).get("Idempotency-Key"),
        `webforge-${o.id}`,
      );
      const b = JSON.parse(options!.body as string);
      assert.equal(b.to[0], p.email);
      assert(b.headers["List-Unsubscribe"]);
      return Response.json({ id: "provider_fixture" });
    },
    async () => true,
  );
  assert.equal(outreach(o.id)!.state, "SENT");
  await dispatchOne(outreach(o.id)!, async () => {
    calls++;
    return Response.json({ id: "duplicate" });
  });
  assert.equal(calls, 1);
  assert.equal(outreach(o.id)!.state, "SENT");
});
test("timeouts become uncertain and never trigger automatic resend", async () => {
  const second = ready("Second", "second.example.test", "second@example.test");
  await prepareOutreach(second, c);
  const o = outbox().find((o) => o.prospectId === second.id)!;
  await dispatchOne(
    o,
    async () => {
      throw new Error("timeout");
    },
    async () => true,
  );
  assert.equal(outreach(o.id)!.state, "UNCERTAIN");
  let calls = 0;
  await dispatchOne(outreach(o.id)!, async () => {
    calls++;
    return Response.json({ id: "wrong" });
  });
  assert.equal(calls, 0);
  assert.equal(outreach(o.id)!.state, "UNCERTAIN");
});
test("suppressed recipient is blocked even with a ready demo and permission", () => {
  suppress(p.email!);
  assert(deliveryBlockers(c, p).includes("Recipient unsubscribed"));
});
test("checkout uses server-owned recurring AUD price and reuses open session", async () => {
  const o = outbox().find((o) => o.prospectId === p.id)!;
  let creates = 0;
  const fake = {
    checkout: {
      sessions: {
        create: async (params: any) => {
          creates++;
          assert.equal(params.mode, "subscription");
          assert.equal(params.line_items[0].price_data.unit_amount, 3300);
          assert.equal(params.line_items[0].price_data.currency, "aud");
          return {
            id: "cs_fixture",
            url: "https://checkout.stripe.com/fixture",
          };
        },
        retrieve: async () => ({
          status: "open",
          url: "https://checkout.stripe.com/fixture",
        }),
      },
    },
  } as unknown as Stripe;
  assert.equal(
    await checkout(o.token, fake),
    "https://checkout.stripe.com/fixture",
  );
  assert.equal(
    await checkout(o.token, fake),
    "https://checkout.stripe.com/fixture",
  );
  assert.equal(creates, 1);
});
test("webhook events are idempotent and stale subscription events cannot undo cancellation", () => {
  const o = outbox().find((o) => o.prospectId === p.id)!;
  const newer = {
    id: "evt_new",
    type: "customer.subscription.deleted",
    created: 200,
    data: {
      object: {
        id: "sub_fixture",
        metadata: { outreach_id: o.id },
        customer: "cus_fixture",
        status: "canceled",
      },
    },
  } as unknown as Stripe.Event;
  assert(applyStripeEvent(newer));
  assert.equal(applyStripeEvent(newer), false);
  const older = {
    ...newer,
    id: "evt_old",
    created: 100,
    type: "customer.subscription.updated",
    data: { object: { ...newer.data.object, status: "active" } },
  } as unknown as Stripe.Event;
  applyStripeEvent(older);
  assert.equal(outreach(o.id)!.subscriptionStatus, "canceled");
});
test("connection values are encrypted and remain readable by the worker", () => {
  writeConnections({ braveKey: "brave_fixture" });
  assert.equal(readConnections().braveKey, "brave_fixture");
});
test("paused campaign never passes delivery eligibility", () => {
  const paused = { ...campaign(c.id)!, enabled: false };
  saveCampaign(paused);
  assert(deliveryBlockers(paused, p).includes("Campaign paused"));
});
test("unreachable public preview blocks provider handoff without consuming a send attempt", async () => {
  const active = { ...campaign(c.id)!, enabled: true };
  saveCampaign(active);
  const third = ready("Third", "third.example.test", "third@example.test");
  await prepareOutreach(third, active);
  const o = outbox().find((o) => o.prospectId === third.id)!;
  let calls = 0;
  await dispatchOne(
    o,
    async () => {
      calls++;
      return Response.json({ id: "should-not-send" });
    },
    async () => false,
  );
  assert.equal(calls, 0);
  assert.equal(outreach(o.id)!.attempts, 0);
  assert.equal(outreach(o.id)!.state, "DRAFT");
  assert(outreach(o.id)!.error?.includes("not reachable"));
});
test("ambiguous provider server failures remain uncertain instead of retrying blindly", async () => {
  const active = { ...campaign(c.id)!, enabled: true };
  saveCampaign(active);
  const p = ready("Fourth", "fourth.example.test", "fourth@example.test");
  await prepareOutreach(p, active);
  const o = outbox().find((o) => o.prospectId === p.id)!;
  await dispatchOne(
    o,
    async () => new Response("Server failure", { status: 500 }),
    async () => true,
  );
  assert.equal(outreach(o.id)!.state, "UNCERTAIN");
});
test("invoice payment events resolve by subscription ID and ignore stale failures", () => {
  const o = outbox().find((o) => o.prospectId === p.id)!;
  const paid = {
    id: "evt_invoice_paid",
    type: "invoice.paid",
    created: 400,
    data: {
      object: {
        id: "in_fixture",
        parent: { subscription_details: { subscription: "sub_fixture" } },
      },
    },
  } as unknown as Stripe.Event;
  applyStripeEvent(paid);
  assert.equal(outreach(o.id)!.paymentStatus, "paid");
  applyStripeEvent({
    ...paid,
    id: "evt_invoice_old_failure",
    type: "invoice.payment_failed",
    created: 300,
  } as Stripe.Event);
  assert.equal(outreach(o.id)!.paymentStatus, "paid");
  applyStripeEvent({
    ...paid,
    id: "evt_invoice_new_failure",
    type: "invoice.payment_failed",
    created: 500,
  } as Stripe.Event);
  assert.equal(outreach(o.id)!.paymentStatus, "failed");
});

test("half-hour campaigns persist without enabling scanning or sending", () => {
  const halfHour = createCampaign({
    name: "Half-hour setup",
    intervalHours: 0.5,
  });
  assert.equal(campaign(halfHour.id)?.intervalHours, 0.5);
  assert.equal(halfHour.enabled, false);
  assert.equal(halfHour.sendingEnabled, false);
  assert.throws(() =>
    createCampaign({ name: "Too frequent", intervalHours: 0.25 }),
  );
});
