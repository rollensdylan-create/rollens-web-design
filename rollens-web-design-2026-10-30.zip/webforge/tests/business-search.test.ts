import { test, mock } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, statSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import dns from "node:dns/promises";
process.env.WEBFORGE_DATA_DIR = mkdtempSync(
  path.join(os.tmpdir(), "webforge-search-test-"),
);
const { searchBusinesses, businessQuery } =
  await import("../src/lib/business-search");
const { createCampaign, prospects } =
  await import("../src/lib/automation-store");
const { discover } = await import("../src/lib/automation");
const { writeConnections, readConnections } =
  await import("../src/lib/connections");
const { connectionStatus } = await import("../src/lib/automation-config");
const keys = {
  anakinKey: "anakin_fixture_secret",
  braveKey: "brave_fixture_secret",
};
const target = {
  niche: "trades and services",
  area: "Melbourne",
  searchPage: 0,
};

test("Anakin uses documented auth/body, rotates niches, and bounds results", async () => {
  const fetchMock = mock.method(
    globalThis,
    "fetch",
    async (url: string | URL | Request, opts?: RequestInit) => {
      assert(opts);
      assert.equal(url, "https://api.anakin.io/v1/search");
      assert.equal(opts.method, "POST");
      assert.equal(new Headers(opts.headers).get("X-API-Key"), keys.anakinKey);
      assert.equal(opts.redirect, "error");
      assert.deepEqual(JSON.parse(String(opts.body)), {
        prompt: businessQuery(target),
        limit: 20,
      });
      return Response.json({
        results: Array.from({ length: 25 }, (_, i) => ({
          url: `https://business${i}.com`,
          title: "Business",
        })),
      });
    },
  );
  try {
    assert.equal((await searchBusinesses("anakin", target, keys)).length, 20);
    assert.match(businessQuery(target), /electricians Melbourne/);
    assert.match(
      businessQuery({ ...target, searchPage: 1 }),
      /plumbers Melbourne/,
    );
    assert.match(
      businessQuery({ ...target, niche: "wedding photographer" }),
      /wedding photographer Melbourne/,
    );
  } finally {
    fetchMock.mock.restore();
  }
});

test("provider failures are actionable, sanitized, and do not silently fall back", async () => {
  for (const code of [401, 402, 429, 500]) {
    const m = mock.method(
      globalThis,
      "fetch",
      async () => new Response(keys.anakinKey, { status: code }),
    );
    try {
      await assert.rejects(searchBusinesses("anakin", target, keys), (e) => {
        assert.match(
          String(e),
          new RegExp(`Anakin Search returned HTTP ${code}`),
        );
        assert(!String(e).includes(keys.anakinKey));
        return true;
      });
      assert.equal(m.mock.callCount(), 1);
    } finally {
      m.mock.restore();
    }
  }
  await assert.rejects(
    searchBusinesses("anakin", target, { ...keys, anakinKey: "" }),
    /Connections/,
  );
  const m = mock.method(globalThis, "fetch", async () =>
    Response.json({ error: keys.anakinKey }),
  );
  try {
    await assert.rejects(
      searchBusinesses("anakin", target, keys),
      /invalid or oversized/,
    );
  } finally {
    m.mock.restore();
  }
});

test("primary campaigns use encrypted Anakin connection and retain URL/contact gates", async () => {
  writeConnections({ anakinKey: keys.anakinKey });
  assert.equal(readConnections().anakinKey, keys.anakinKey);
  assert.equal(connectionStatus().searchProvider, "anakin");
  assert(!JSON.stringify(connectionStatus()).includes(keys.anakinKey));
  const encrypted = path.join(
    process.env.WEBFORGE_DATA_DIR!,
    "connections.enc",
  );
  assert(!readFileSync(encrypted, "utf8").includes(keys.anakinKey));
  assert.equal(statSync(encrypted).mode & 0o777, 0o600);
  const campaign = createCampaign({
    name: "Primary fixture",
    niche: "wedding photographer",
    area: "Melbourne",
  });
  assert.equal(campaign.discoverySource, "primary");
  const lookup = mock.method(dns, "lookup", async (host: string) => [
    {
      address: host === "private.invalid" ? "127.0.0.1" : "93.184.216.34",
      family: 4,
    },
  ]);
  const request = mock.method(
    globalThis,
    "fetch",
    async (url: string | URL | Request) => {
      assert.equal(url, "https://api.anakin.io/v1/search");
      return Response.json({
        results: [
          {
            url: "https://fixture-business.com/contact",
            title: "Fixture Business | Contact",
            snippet: "invented@example.com",
          },
          { url: "https://www.fixture-business.com/", title: "Duplicate" },
          { url: "https://facebook.com/fixture", title: "Directory" },
          { url: "https://private.invalid/", title: "Private" },
          { url: "https://user:pass@unsafe.com/", title: "Credentials" },
        ],
      });
    },
  );
  try {
    await discover(campaign);
    const leads = prospects(campaign.id);
    assert.equal(leads.length, 1);
    assert.equal(
      leads[0].discoverySourceUrl,
      "https://fixture-business.com/contact",
    );
    assert.equal(leads[0].email, null);
    assert.deepEqual(leads[0].contacts, []);
    assert.equal(leads[0].permission, "UNKNOWN");
    assert.equal(campaign.sendingEnabled, false);
  } finally {
    lookup.mock.restore();
    request.mock.restore();
  }
});

test("deployment migration preserves schedules, scan caps, manual queues and sending settings", async () => {
  const { execFileSync } = await import("node:child_process");
  const { campaign } = await import("../src/lib/automation-store");
  const automated = createCampaign({
    name: "Existing OSM",
    discoverySource: "osm",
    enabled: true,
    sendingEnabled: false,
    intervalHours: 0.5,
    dailyScans: 10,
  });
  const manual = createCampaign({
    name: "Manual queue",
    discoverySource: "manual",
  });
  const output = execFileSync(
    process.execPath,
    ["--import", "tsx", "scripts/configure-anakin.mjs"],
    {
      input: keys.anakinKey,
      encoding: "utf8",
      env: { ...process.env, ANAKIN_API_KEY: "" },
    },
  );
  assert.equal(JSON.parse(output).provider, "anakin");
  assert(!output.includes(keys.anakinKey));
  const updated = campaign(automated.id)!;
  assert.equal(updated.discoverySource, "primary");
  assert.deepEqual({ ...updated, discoverySource: "osm" }, automated);
  assert.deepEqual(campaign(manual.id), manual);
});
