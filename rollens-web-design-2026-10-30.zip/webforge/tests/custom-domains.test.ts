import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
process.env.WEBFORGE_DATA_DIR = await mkdtemp(
  path.join(os.tmpdir(), "rollens-domains-"),
);
process.env.PUBLIC_BASE_URL = "https://rollenswebdesign.space";
const { db } = await import("../src/lib/db");
const { authenticate, saveSite, publish, sessionFor } =
  await import("../src/lib/selfserve");
const {
  normalizeDomain,
  addDomain,
  verifyDomain,
  domainSite,
  domainsFor,
  removeDomain,
  domainIpv4,
} = await import("../src/lib/custom-domains");
const { GET: authorize } =
  await import("../src/app/api/internal/domain-authorize/route");
const { GET: serve } =
  await import("../src/app/api/internal/domain-site/route");
const { POST } = await import("../src/app/api/public/domains/route");
const id = authenticate("domains@example.test", "a-long-test-password", true);
const user = () =>
  db.prepare("SELECT * FROM site_users WHERE id=?").get(id) as any;
const site = saveSite(user(), {
  name: "Domain owner",
  brief: "A genuine business website draft.",
  email: "owner@example.test",
  phone: "",
  area: "Melbourne",
  services: [],
  theme: 0,
  personal: false,
  gallery: [],
});
const row = (id: string) =>
  db.prepare("SELECT * FROM site_domains WHERE id=?").get(id) as any;
function dns(token: string, ipv4 = [domainIpv4()], ipv6: string[] = []) {
  return {
    resolveTxt: async () => [[`rollens-verification=${token}`]],
    resolve4: async () => ipv4,
    resolve6: async () => ipv6,
  };
}
test("hostnames normalize and reserved, private or malformed inputs are rejected", () => {
  assert.equal(normalizeDomain("WWW.Example.COM."), "www.example.com");
  assert.equal(normalizeDomain("münich.com"), "xn--mnich-kva.com");
  for (const input of [
    "localhost",
    "127.0.0.1",
    "https://example.com",
    "example.com/path",
    "example.com:443",
    "*.example.com",
    "-x.com",
    "x..com",
    "x.local",
    "rollenswebdesign.space",
    "www.rollenswebdesign.space",
    "aatlas.offerflow.lol",
  ])
    assert.throws(() => normalizeDomain(input));
});
test("unverified domains cannot serve or trigger certificates, including spoofed public requests", async () => {
  addDomain(user(), site, "pending.example.com");
  assert.equal(await domainSite("pending.example.com"), null);
  const response = await authorize(
    new Request(
      "http://127.0.0.1:4333/api/internal/domain-authorize?domain=pending.example.com",
      { headers: { host: "127.0.0.1:4333" } },
    ),
  );
  assert.equal(response.status, 403);
  const publicRequest = await serve(
    new Request("https://example.com/api/internal/domain-site", {
      headers: {
        host: "example.com",
        "x-rollens-domain": "pending.example.com",
      },
    }),
  );
  assert.equal(publicRequest.status, 404);
});
test("ownership TXT, exact IPv4 and no competing IPv6 are all required", async () => {
  const domain = addDomain(user(), site, "example.com");
  await assert.rejects(
    verifyDomain(user(), domain, dns("wrong")),
    /Ownership TXT/,
  );
  await assert.rejects(
    verifyDomain(user(), domain, dns(row(domain).token, ["1.1.1.1"])),
    /Point this hostname/,
  );
  await assert.rejects(
    verifyDomain(
      user(),
      domain,
      dns(row(domain).token, [domainIpv4()], ["2001:db8::1"]),
    ),
    /AAAA/,
  );
  assert.equal(row(domain).status, "pending");
  await verifyDomain(user(), domain, dns(row(domain).token));
  assert.equal(row(domain).status, "verified");
  assert.equal(await domainSite("example.com"), null);
  db.prepare("UPDATE site_users SET plan='starter',enabled=1 WHERE id=?").run(
    id,
  );
  publish(user(), site, true);
  assert.equal((await domainSite("example.com"))?.name, "Domain owner");
  const allowed = await authorize(
    new Request(
      "http://127.0.0.1:4333/api/internal/domain-authorize?domain=example.com",
      { headers: { host: "127.0.0.1:4333" } },
    ),
  );
  assert.equal(allowed.status, 200);
});
test("verified sites render only the published document, and cancellation/unpublishing stops routing", async () => {
  const response = await serve(
    new Request("http://127.0.0.1:4333/api/internal/domain-site", {
      headers: { host: "127.0.0.1:4333", "x-rollens-domain": "example.com" },
    }),
  );
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.ok(html.includes("Domain owner"));
  assert.ok(html.includes("mailto:owner@example.test"));
  assert.ok(response.headers.get("cache-control")?.includes("no-transform"));
  db.prepare("UPDATE site_users SET enabled=0 WHERE id=?").run(id);
  assert.equal(await domainSite("example.com"), null);
  db.prepare("UPDATE site_users SET enabled=1 WHERE id=?").run(id);
  publish(user(), site, false);
  assert.equal(await domainSite("example.com"), null);
  publish(user(), site, true);
});
test("another account cannot modify a mapping; pending claims do not prevent fresh DNS-proven ownership", async () => {
  const otherId = authenticate(
    "other@example.test",
    "a-long-test-password",
    true,
  );
  const other = db
    .prepare("SELECT * FROM site_users WHERE id=?")
    .get(otherId) as any;
  const otherSite = saveSite(other, {
    name: "Other",
    brief: "Another business website.",
    email: "",
    phone: "",
    area: "",
    services: [],
    theme: 0,
    personal: false,
    gallery: [],
  });
  const old = domainsFor(user(), site).find(
    (d) => d.hostname === "example.com",
  )!;
  assert.throws(() => removeDomain(other, old.id));
  await assert.rejects(
    verifyDomain(other, old.id, dns(old.token)),
    /Domain not found/,
  );
  const fresh = addDomain(other, otherSite, "example.com");
  await assert.rejects(
    verifyDomain(other, fresh, dns(old.token)),
    /Ownership TXT/,
  );
  assert.equal(row(old.id).status, "verified");
  await verifyDomain(other, fresh, dns(row(fresh).token));
  assert.equal(row(old.id).status, "pending");
  assert.equal(row(fresh).status, "verified");
  assert.equal(await domainSite("example.com"), null);
});
test("DNS is periodically rechecked and disconnected records cannot issue certificates", async () => {
  const domain = addDomain(user(), site, "www.example.com");
  await verifyDomain(user(), domain, dns(row(domain).token));
  db.prepare("UPDATE site_domains SET checked_at=0 WHERE id=?").run(domain);
  assert.equal(await domainSite("www.example.com", dns("gone")), null);
  assert.equal(row(domain).status, "pending");
  await verifyDomain(user(), domain, dns(row(domain).token));
  removeDomain(user(), domain);
  assert.equal(await domainSite("www.example.com"), null);
});
test("domain API requires login, same-origin writes, and the owning site", async () => {
  const request = (origin: string, cookie = "") =>
    new Request("https://rollenswebdesign.space/api/public/domains", {
      method: "POST",
      headers: { origin, cookie },
      body: JSON.stringify({
        action: "add",
        site,
        hostname: "api.example.com",
      }),
    });
  assert.equal((await POST(request("https://evil.example"))).status, 403);
  assert.equal((await POST(request(process.env.PUBLIC_BASE_URL!))).status, 401);
  const token = sessionFor(id);
  assert.equal(
    (
      await POST(
        request(process.env.PUBLIC_BASE_URL!, `rollens_session=${token}`),
      )
    ).status,
    200,
  );
});

test("temporary resolver outages fail closed and recover without manual reconnection", async () => {
  const domain = addDomain(user(), site, "recovery.example.com");
  await verifyDomain(user(), domain, dns(row(domain).token));
  db.prepare("UPDATE site_domains SET checked_at=0 WHERE id=?").run(domain);
  const unavailable = {
    ...dns(row(domain).token),
    resolveTxt: async () => {
      throw Object.assign(new Error("timeout"), { code: "ETIMEOUT" });
    },
  };
  await assert.rejects(
    domainSite("recovery.example.com", unavailable),
    /DNS lookup/,
  );
  assert.equal(row(domain).status, "verified");
  assert.equal(
    (await domainSite("recovery.example.com", dns(row(domain).token)))?.name,
    "Domain owner",
  );
});
