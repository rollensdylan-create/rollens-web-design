# WebForge implementation status

Built from **AATLAS WebForge Mission Control — Master OpenCode Build Prompt**, recovered from [Automated Website Rating System](https://chatgpt.com/c/6a87d6a0-93f0-83ec-9bf1-dacf2a3646a1), 21 August 2026. See RECOVERED_REQUIREMENTS.md for the requirements digest.

## Delivered

- Next.js App Router / TypeScript operator application, responsive dark interface and all six requested views.
- Relational SQLite database with WAL, businesses, mission state, stage runs and persistent events.
- Separate worker with transactional claims, single-worker lock, heartbeat, stage checkpoints, interruption recovery and explicit failures.
- Real controls for new mission, stage-boundary pause/resume/cancel, retry, rebuild and QA reruns.
- Public URL validation, pinned public DNS connections, checked redirects, response-size limits, bounded transient retries and crawl limits.
- Source parsing, original HTML snapshots and desktop/tablet/mobile screenshots.
- Weighted audit across seven categories, configurable weights, objective/heuristic distinction and inspectable findings.
- Deterministic strategy provider and optional validated OpenAI-compatible strategy integration.
- Original self-contained local-business template using public facts, with clear independent-preview labelling.
- Browser QA at 1440/768/390px, screenshot previews and sandboxed artifact access.
- Optional OpenCode adapter and bounded fix flow, isolated environment contract and focused prompts.
- SSE event stream, mission queue, business directory, demo library, artifact browser and resource metadata.
- Startup launcher, environment example, setup guide, requirements digest and PostgreSQL reference migration schema.

## Validated on 16 October 2026

- 7 unit/state tests passed: private IP blocking, local host/origin checks, source parsing, weighted scoring, HTML escaping, durable state transitions and retry checkpoints.
- 10 integration checks passed in an isolated validation database: rejected private/cross-origin targets; pause persistence; cancellation; resumed training pipeline; sandboxed preview/screenshot artifacts; QA rerun; rebuild; real public website scan; explicit HTTP failure and retry/cancel; SSE stream.
- Training fixture and live https://example.com missions completed with audit, strategy, generated demo and screenshots. Both demos passed QA at all three widths with no runtime errors, broken images or horizontal overflow.
- Browser inspection verified mission detail, audit and preview; mobile operator UI measured 390px document width in a 390px viewport.
- Type checking, ESLint and production build passed. VALIDATION_RESULTS.json records integration outcomes.

## Deliberate local MVP choices

- SQLite instead of a required PostgreSQL service. PostgreSQL reference schema is not wired into the application.
- Plain component CSS instead of Tailwind. Original static HTML/CSS demo instead of installing/running Next.js per prospect.
- Local screenshot + sandboxed HTML preview instead of public deployment.
- No AI work is simulated. The labelled training fixture simulates source measurements only; its build and QA really execute.
- Design score is a structural proxy. Performance is fetch/payload/runtime analysis, not Lighthouse or Core Web Vitals.
- Source business name is operator-supplied; service headings/contact details are extracted facts. Rich facts like locations/testimonials are not invented.

## Configurable but not validated against a real model

- OpenAI-compatible strategy provider needs AI_PROVIDER=compatible, AI_BASE_URL, AI_MODEL, AI_API_KEY.
- OpenCode CLI argument compatibility was inspected from the installed executable. Actual agent execution is disabled by default and needs a configured sandbox wrapper, isolated credentials, explicit model and ALLOW_LOCAL_AGENT=1.
- The fix loop requires that configured agent and only runs when QA fails. No unlimited repair loops.

## Remaining production work

- Authenticated multi-user sessions, roles and production rate limits.
- OS/container isolation for coding workers and production egress policy.
- PostgreSQL adapter/migrations, remote artifact storage and distributed queue support.
- Richer extraction, visual AI audit, Lighthouse, full accessibility audits and interaction/form testing.
- Framework-based generated projects, deployment providers, durable preview servers and public site lifecycle.
- Per-stage rerun UI beyond QA/rebuild; expanded provider methods for AI audits and visual review.

## Configuration and operation

See README.md and .env.example. Run `pnpm start` and `pnpm worker`, or double-click Start WebForge.command. The server binds to 127.0.0.1:4333. Pause/cancel finish the current bounded stage first. No prospect outreach, payment transactions or public publishing occur.


## Autopilot extension — 16 October 2026

Added database-backed campaigns, scheduled Brave discovery/import queue, domain deduplication, scan quotas and pre-build score filtering. Qualified missions continue through the original build/QA pipeline, then prepare templated outreach automatically. The operator UI includes recipient permission/evidence, suppression, outreach previews, daily email limits, encrypted write-only connection setup and activity.

Resend delivery uses stable idempotency, bounded backoff and an explicit UNCERTAIN state for ambiguous handoffs. Public recipient pages expose sandboxed demos, recurring AUD pricing and server-created Stripe Checkout. Public readiness is checked before email handoff. Signed Stripe webhook events are deduplicated and update subscription status. Unsubscribe immediately suppresses future outreach.

Live Resend delivery, Brave discovery and real Stripe account transactions have not been exercised; tests use provider doubles and signed local webhook fixtures. No prospect outreach or charges were issued. DNS/TLS/public hosting and purchased-site fulfilment are not deployed. See AUTOPILOT.md and AUTOMATION_VALIDATION.json.


### Autopilot final verification
20 unit/state tests pass, including mailto extraction, permission gates, public-preview readiness and ambiguous email provider failures. Nine isolated automation integration checks pass, and the original ten mission regression checks pass. TypeScript, ESLint and the production build pass. A paused starter campaign named Website acquisition is saved in the local workspace; no target, sender identity or service credentials were invented. Live sending stays disabled pending configuration.

Stripe connection follow-up: confirmed CansCo is exposed in live mode; no account writes made pending environment selection. Added invoice.paid / invoice.payment_failed and asynchronous checkout payment state tracking, Stripe object-ID ownership mapping, and a Checkout integration identifier. 21 tests pass.
